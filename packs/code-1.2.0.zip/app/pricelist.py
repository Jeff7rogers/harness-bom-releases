"""
pricelist.py — price a spreadsheet of part numbers.

WHY THIS IS SEPARATE FROM A PROJECT
-----------------------------------
Half the pricing work in a shop has no drawing behind it: a customer sends a
parts list in a spreadsheet, a buyer wants a refresh on fifty stock lines, a
quote needs checking against last year's numbers. Making someone build a
project and a harness to price forty part numbers is the kind of friction that
sends the job back to opening forty browser tabs.

So this takes a sheet, finds the part numbers in it however they are laid out,
prices them through exactly the same path a drawing's parts list goes through,
and hands back the sheet with prices on it.

READING SOMEONE ELSE'S SPREADSHEET
----------------------------------
There is no agreeing on a template - a column is called PART NUMBER or Part No.
or MFG P/N or just Part, and the header is on row 1, or row 5, or after a title
block. So: look through the first fifteen rows for the one that looks most like
a header, score each column by name, and if no name matches, fall back to the
column whose cells most look like part numbers. Whatever it decides is shown on
the screen before anything is priced, because a wrong column should be visible
in two seconds rather than after forty lookups.

Everything priced lands in the parts master as well, so the next drawing that
calls out one of these parts already has a price against it.
"""
import csv
import io
import os
import re

from . import db, partnum, pricing

# What a part-number column tends to be called. Ordered: a header matching an
# earlier entry wins over a later one.
PN_HEADERS = [
    r"^\s*(mfg|mfr|manufacturer)?\s*part\s*(number|no\.?|#)\s*$",
    r"^\s*(mfg|mfr|manufacturer)\s*p/?n\s*$",
    r"^\s*p/?n\s*$",
    r"^\s*part\s*$",
    r"^\s*(component|item)\s*(number|no\.?|#)\s*$",
    r"^\s*(identifying|catalog(ue)?)\s*number\s*$",
]
QTY_HEADERS = [r"^\s*(qty|quantity|qty\s*reqd|req'?d|ext\s*qty)\s*$"]
# Deliberately no "item": on a parts list that is the line number, and taking it
# as the description puts "1, 2, 3" in the description column of the workbook.
DESC_HEADERS = [r"^\s*(description|nomenclature|desc|part\s*name)\s*$"]

MAX_ROWS = 5000
SCAN_ROWS = 15


class SheetError(RuntimeError):
    pass


# ---------------------------------------------------------------------------
# Reading the file
# ---------------------------------------------------------------------------
def read_table(data: bytes, filename: str) -> list:
    """Any supported spreadsheet -> a list of rows of strings."""
    name = (filename or "").lower()
    if name.endswith((".csv", ".txt", ".tsv")):
        return _read_csv(data)
    if name.endswith((".xlsx", ".xlsm")):
        return _read_xlsx(data)
    raise SheetError("That is not a spreadsheet this can read. Save it as .xlsx or .csv "
                     "and try again — an .xls from an old Excel needs saving as .xlsx first.")


def _read_csv(data: bytes) -> list:
    text = data.decode("utf-8-sig", "replace")
    try:
        dialect = csv.Sniffer().sniff(text[:4096], delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel
    rows = []
    for row in csv.reader(io.StringIO(text), dialect):
        rows.append([(c or "").strip() for c in row])
        if len(rows) > MAX_ROWS:
            break
    return rows


def _read_xlsx(data: bytes) -> list:
    try:
        from openpyxl import load_workbook
    except ImportError:                                       # pragma: no cover
        raise SheetError("This copy of the program cannot read .xlsx files. Save as .csv.")
    wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = []
    for row in ws.iter_rows(values_only=True):
        rows.append(["" if c is None else str(c).strip() for c in row])
        if len(rows) > MAX_ROWS:
            break
    wb.close()
    return rows


# ---------------------------------------------------------------------------
# Working out which column is which
# ---------------------------------------------------------------------------
def _header_score(cells, patterns):
    for col, cell in enumerate(cells):
        for rank, pat in enumerate(patterns):
            if re.match(pat, (cell or "").lower()):
                return col, rank
    return None, 99


def _looks_like_pn(text):
    t = (text or "").strip()
    if len(t) < 4 or len(t) > 40 or " " in t.strip():
        return False
    if not any(c.isdigit() for c in t):
        return False
    return bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9\-/.]{2,}", t))


def find_columns(rows: list) -> dict:
    """
    Which row is the header and which columns hold what.

    Returns {"header_row", "pn", "qty", "desc", "how"}. `how` says in plain words
    how it decided, because that sentence on the screen is what stops someone
    pricing the wrong column.
    """
    best = {"header_row": None, "pn": None, "qty": None, "desc": None, "how": ""}
    best_rank = 99
    for i, row in enumerate(rows[:SCAN_ROWS]):
        col, rank = _header_score(row, PN_HEADERS)
        if col is not None and rank < best_rank:
            qty, _ = _header_score(row, QTY_HEADERS)
            desc, _ = _header_score(row, DESC_HEADERS)
            best = {"header_row": i, "pn": col, "qty": qty, "desc": desc,
                    "how": f'Row {i + 1} looks like the header; part numbers are in '
                           f'column {_letter(col)} ("{row[col]}")'}
            best_rank = rank
    if best["pn"] is not None:
        return best

    # No header matched. Pick the column that most looks like part numbers.
    width = max((len(r) for r in rows[:200]), default=0)
    counts = []
    for col in range(width):
        hits = sum(1 for r in rows[:200] if col < len(r) and _looks_like_pn(r[col]))
        counts.append(hits)
    if not counts or max(counts) < 2:
        raise SheetError(
            "No column in that sheet looks like part numbers. The program looks for a "
            "heading such as PART NUMBER, MFG P/N or P/N in the first fifteen rows, and "
            "failing that for a column of part-number-looking values. Add a heading to "
            "the column and upload it again.")
    col = counts.index(max(counts))
    return {"header_row": None, "pn": col, "qty": None, "desc": None,
            "how": f"No heading matched, so column {_letter(col)} was used — "
                   f"{max(counts)} of its cells look like part numbers"}


def _letter(idx):
    out = ""
    idx += 1
    while idx:
        idx, rem = divmod(idx - 1, 26)
        out = chr(65 + rem) + out
    return out


def collect(rows: list, cols: dict) -> list:
    """The part numbers to price, in sheet order, deduplicated but keeping the
    row each came from so the output can be written back against it."""
    start = (cols["header_row"] + 1) if cols["header_row"] is not None else 0
    seen, out = set(), []
    for i, row in enumerate(rows[start:], start=start):
        pn = (row[cols["pn"]] if cols["pn"] < len(row) else "").strip()
        if not pn or not _looks_like_pn(pn):
            continue
        key = partnum.despace(pn).upper()
        entry = {"row": i, "pn": pn.strip(), "key": key,
                 "qty": _num(row[cols["qty"]]) if cols["qty"] is not None
                        and cols["qty"] < len(row) else None,
                 "desc": row[cols["desc"]] if cols["desc"] is not None
                         and cols["desc"] < len(row) else ""}
        if key in seen:
            entry["duplicate"] = True
        seen.add(key)
        out.append(entry)
    return out


def _num(text):
    try:
        return float(re.sub(r"[^0-9.]", "", str(text or "")) or 0) or None
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# Pricing and writing it back
# ---------------------------------------------------------------------------
def price(conn, entries, qty=1, force=False, progress=None) -> dict:
    """Price the collected part numbers. Returns the report plus per-row results."""
    pricing.assert_allowed(controlled=False)
    unique = []
    for e in entries:
        if not e.get("duplicate"):
            unique.append(e["key"])
    report = pricing.fetch_pns(conn, unique, qty=qty, force=force, progress=progress)

    # Everything the sheet asked about, priced or not, read back out of the
    # parts master so a part that was already known shows its price too.
    prices = {}
    for row in conn.execute(
            "SELECT pn, last_price, last_source, lead_wk, is_estimate, description, uom"
            "  FROM partsmaster"):
        prices[row["pn"].upper()] = dict(row)
    for e in entries:
        e["priced"] = prices.get(e["key"])
    report["entries"] = entries
    return report


def workbook(entries, report, title="Priced parts") -> bytes:
    """
    The sheet back, with prices on it, and a tab of what nobody could price.

    That second tab is the point of the whole feature for a buyer: it is the
    list to send out for a real RFQ, already filtered down to the parts a
    catalogue could not answer.
    """
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    head = Font(bold=True, color="FFFFFF", size=10)
    fill = PatternFill("solid", fgColor="1F3864")
    money = '"$"#,##0.0000'

    wb = Workbook()
    ws = wb.active
    ws.title = "Priced"
    cols = ["Part number", "Description", "Qty on sheet", "Unit price", "Source",
            "Lead time (wk)", "Estimate?", "Extended", "Note"]
    ws.append(cols)
    for i, _ in enumerate(cols, start=1):
        c = ws.cell(row=1, column=i)
        c.font, c.fill = head, fill
        c.alignment = Alignment(horizontal="center", wrap_text=True)

    r = 1
    for e in entries:
        if e.get("duplicate"):
            continue
        r += 1
        p = e.get("priced") or {}
        price_v = p.get("last_price")
        qty_v = e.get("qty")
        ws.cell(row=r, column=1, value=e["pn"])
        ws.cell(row=r, column=2, value=e.get("desc") or p.get("description") or "")
        ws.cell(row=r, column=3, value=qty_v)
        ws.cell(row=r, column=4, value=price_v).number_format = money
        ws.cell(row=r, column=5, value=p.get("last_source") or "")
        ws.cell(row=r, column=6, value=p.get("lead_wk"))
        ws.cell(row=r, column=7, value="estimate" if p.get("is_estimate") else "")
        if price_v is not None and qty_v:
            ws.cell(row=r, column=8, value=f"=C{r}*D{r}").number_format = money
        ws.cell(row=r, column=9,
                value="" if price_v is not None else "no catalogue price — send to RFQ")

    ws.freeze_panes = "A2"
    for i, width in enumerate([26, 44, 13, 13, 22, 14, 11, 13, 30], start=1):
        ws.column_dimensions[get_column_letter(i)].width = width

    # --- the RFQ list ------------------------------------------------------
    missing = [e for e in entries
               if not e.get("duplicate") and not (e.get("priced") or {}).get("last_price")]
    ws2 = wb.create_sheet("Send to RFQ")
    ws2.append(["Part number", "Description", "Qty on sheet"])
    for i in range(1, 4):
        c = ws2.cell(row=1, column=i)
        c.font, c.fill = head, fill
    for i, e in enumerate(missing, start=2):
        ws2.cell(row=i, column=1, value=e["pn"])
        ws2.cell(row=i, column=2, value=e.get("desc") or "")
        ws2.cell(row=i, column=3, value=e.get("qty"))
    for i, width in enumerate([26, 44, 13], start=1):
        ws2.column_dimensions[get_column_letter(i)].width = width
    ws2.freeze_panes = "A2"

    # --- what actually happened -------------------------------------------
    ws3 = wb.create_sheet("How this was priced")
    for line in [
        (title,),
        (f"Priced on {db.now()}",),
        (f"Quantity asked at: {report.get('qty')}",),
        (f"Part numbers in the sheet: {report.get('asked', 0) + sum(1 for e in entries if e.get('duplicate'))}",),
        (f"Looked up now: {report.get('asked', 0)}",),
        (f"Priced: {report.get('priced', 0)}",),
        (f"Already priced recently, left alone: {report.get('cached', 0)}",),
        (f"No catalogue price found: {report.get('missed', 0)}",),
        (f"Distributors asked: {', '.join(report.get('providers') or []) or 'none'}",),
        ("",),
        ("These are catalogue list prices from a named seller on the date above.",),
        ("They are not quotes: no commitment, no contract pricing, and often well",),
        ("above what a franchised distributor will do on a real purchase order.",),
    ]:
        ws3.append(list(line))
    ws3.column_dimensions["A"].width = 95
    if report.get("error"):
        ws3.append([""])
        ws3.append([f"A distributor stopped answering part way through: {report['error']}"])

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def save(data: bytes, stem="priced-parts") -> str:
    """Write the workbook where the other exports go, and return the path."""
    out = os.environ.get("HARNESSBOM_EXPORTS") or os.path.join(db.data_dir(), "exports")
    os.makedirs(out, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", stem)[:60] or "priced-parts"
    path = os.path.join(out, f"{safe}-{db.now().replace(':', '').replace('-', '')}.xlsx")
    with open(path, "wb") as fh:
        fh.write(data)
    return path


# ---------------------------------------------------------------------------
# Running it in the background
# ---------------------------------------------------------------------------
# Forty part numbers is a minute of waiting, and a browser staring at a white
# page for a minute is indistinguishable from a broken program. Same shape as
# the drawing batch: one job at a time, progress readable while it runs.
import threading                                             # noqa: E402

_JOB = {"state": "idle", "done": 0, "total": 0, "pn": "", "report": None,
        "path": "", "error": "", "name": ""}
_LOCK = threading.Lock()


def job() -> dict:
    with _LOCK:
        return dict(_JOB)


def start(entries, qty=1, force=False, name="parts") -> str:
    """Begin pricing. Returns '' or why it will not start."""
    try:
        pricing.assert_allowed(controlled=False)
    except (pricing.Refused, pricing.NotConfigured) as exc:
        return str(exc)
    with _LOCK:
        if _JOB["state"] == "running":
            return "A pricing run is already going. Wait for it to finish."
        _JOB.update({"state": "running", "done": 0, "total": len(entries), "pn": "",
                     "report": None, "path": "", "error": "", "name": name})
    threading.Thread(target=_run, args=(entries, qty, force, name),
                     daemon=True, name="harnessbom-pricelist").start()
    return ""


def _run(entries, qty, force, name):
    def progress(done, total, pn):
        with _LOCK:
            _JOB.update({"done": done, "total": total, "pn": pn})

    try:
        conn = db.init()
        report = price(conn, entries, qty=qty, force=force, progress=progress)
        path = save(workbook(entries, report, name), stem=name)
        from . import usage as _usage
        _usage.record(conn, "list priced")
        db.log(conn, "pricelist_run", name,
               f"{report['asked']} asked, {report['priced']} priced, "
               f"{report['missed']} not found")
        conn.commit()
        conn.close()
    except Exception as exc:
        with _LOCK:
            _JOB.update({"state": "failed", "error": f"{exc.__class__.__name__}: {exc}"})
        return
    with _LOCK:
        _JOB.update({"state": "done", "report": report, "path": path,
                     "done": _JOB["total"]})


# The sheet that was read but not yet priced. Held in memory rather than in a
# session cookie: a cookie is a few kilobytes and a parts list can be hundreds
# of rows, and this program serves exactly one person on one machine.
_PENDING = {"entries": [], "name": "", "preview": None}


def stage(entries, name, preview):
    _PENDING.update({"entries": entries, "name": name, "preview": preview})


def staged() -> dict:
    return dict(_PENDING)


def clear_staged():
    _PENDING.update({"entries": [], "name": "", "preview": None})
