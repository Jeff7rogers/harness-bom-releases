"""
usage.py — who is using this program, across the machines it is installed on.

THE PROBLEM
-----------
There is no server. Each copy is a local program with its own database, so
nothing anywhere knows that six people are running it. The tool is meant for a
handful of named people and Jeff wants to see who those people actually are.

HOW
---
Each copy writes one small file to a folder they all already share - a network
drive, a synced folder, whatever is already on the machines. One file per
install, rewritten as the person works:

    HarnessBOM-usage/<machine>-<user>.json

Nothing is ever read from one of those files and acted on. The Who's using it
screen reads every file in that folder and lists them, and that is the whole
mechanism. No internet, so it works with the offline lock engaged, and nothing
about a drawing, a customer or a part number leaves the machine - the file
holds a name, a machine, timestamps, and counts of things done.

WHAT IT RECORDS, AND WHAT IT DELIBERATELY DOES NOT
--------------------------------------------------
Recorded: the Windows or Mac account name and the machine name, when this copy
was first seen and last used, the version it runs, how many projects and
harnesses exist in its database, and a tally of actions by kind (a quote
exported, a drawing read, prices fetched).

Not recorded: project names, customer names, drawing numbers, part numbers,
file paths, or anything typed into the program. A tool for seeing who is using
something should not become a tool for reading over their shoulder, and the
counts answer the question that was actually asked.

Jeff should tell the team this is on. Not a legal opinion - just that software
on a shop floor that reports who ran it is the sort of thing people ought to
hear from their employer rather than discover.
"""
import getpass
import json
import os
import platform
import re
import socket
import time

from . import db, version

_LAST = {"at": 0.0, "path": ""}

ENV_FOLDER = "HARNESSBOM_USAGE_DIR"
SETTING = "usage_dir"
STALE_DAYS = 30


def folder(conn=None) -> str:
    """The shared folder, from the environment or the local settings. '' = off."""
    env = os.environ.get(ENV_FOLDER)
    if env:
        return env
    if conn is None:
        return ""
    row = conn.execute("SELECT value FROM setting WHERE key = ?", (SETTING,)).fetchone()
    return (row["value"] if row else "") or ""


def set_folder(conn, path: str):
    path = (path or "").strip()
    conn.execute("INSERT INTO setting (key, value) VALUES (?,?)"
                 " ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                 (SETTING, path))
    conn.commit()


def who() -> dict:
    """This machine and account, as plainly as the operating system will say."""
    try:
        user = getpass.getuser()
    except Exception:                                         # pragma: no cover
        user = os.environ.get("USERNAME") or os.environ.get("USER") or "unknown"
    try:
        machine = socket.gethostname().split(".")[0]
    except Exception:                                         # pragma: no cover
        machine = "unknown"
    return {"user": user, "machine": machine,
            "platform": f"{platform.system()} {platform.release()}"}


def _slug(text):
    return re.sub(r"[^A-Za-z0-9_.-]+", "-", (text or "unknown"))[:40] or "unknown"


def _path(conn):
    d = folder(conn)
    if not d:
        return ""
    me = who()
    return os.path.join(d, f"{_slug(me['machine'])}-{_slug(me['user'])}.json")


# ---------------------------------------------------------------------------
def record(conn, action: str = "") -> str:
    """
    Note that this copy is in use. Returns the file written, or ''.

    Called on page loads and after the actions worth counting. Never raises:
    a shared drive that is not mounted this morning must not stop someone
    quoting a job, so every failure here is silent to the user and visible only
    on the Who's using it screen, where it belongs.
    """
    path = _path(conn)
    if not path:
        return ""
    # A network share is slow and this gets called from ordinary page loads, so
    # a heartbeat with nothing to say is skipped if one went recently. An action
    # always writes: those are the thing being counted.
    now = time.time()
    if not action and now - _LAST["at"] < 60:
        return _LAST["path"]
    _LAST.update({"at": now, "path": path})
    try:
        d = os.path.dirname(path)
        if not os.path.isdir(d):
            # Create the usage folder itself, but never the path to it. A share
            # that is not mounted this morning leaves an empty mount point, and
            # happily creating a local folder there would mean six PCs each
            # writing to their own private copy while the screen showed one
            # install and nobody could tell why.
            if not os.path.isdir(os.path.dirname(d.rstrip(os.sep)) or os.sep):
                return ""
            os.makedirs(d, exist_ok=True)
        data = _read_one(path) or {}
        me = who()
        counts = data.get("actions") or {}
        if action:
            counts[action] = int(counts.get(action, 0)) + 1
        data.update({
            "user": me["user"],
            "machine": me["machine"],
            "platform": me["platform"],
            "version": version.VERSION,
            "running": _running_version(),
            "first_seen": data.get("first_seen") or db.now(),
            "last_seen": db.now(),
            "projects": _count(conn, "project"),
            "harnesses": _count(conn, "harness"),
            "actions": counts,
        })
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=1)
        os.replace(tmp, path)
        return path
    except Exception:
        return ""


def _running_version():
    try:
        from . import updates
        return updates.running_version()
    except Exception:                                         # pragma: no cover
        return version.VERSION


def _count(conn, table):
    try:
        return int(conn.execute(f"SELECT COUNT(*) AS n FROM {table}").fetchone()["n"])
    except Exception:                                         # pragma: no cover
        return 0


def _read_one(path):
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def everyone(conn) -> dict:
    """
    Every install that has written to the shared folder.

    The files come from other machines, so they are data and nothing else: every
    value is read as text and shown, and nothing in one of them decides what
    this program does.
    """
    d = folder(conn)
    out = {"folder": d, "configured": bool(d), "reachable": False,
           "people": [], "error": "", "mine": ""}
    if not d:
        return out
    try:
        names = sorted(n for n in os.listdir(d) if n.endswith(".json"))
        out["reachable"] = True
    except Exception as exc:
        out["error"] = f"{exc.__class__.__name__}: {exc}"
        return out

    me = _path(conn)
    out["mine"] = os.path.basename(me) if me else ""
    now = time.time()
    for name in names:
        data = _read_one(os.path.join(d, name))
        if not data:
            continue
        try:
            age_days = (now - os.path.getmtime(os.path.join(d, name))) / 86400.0
        except OSError:
            age_days = 0.0
        actions = data.get("actions") or {}
        out["people"].append({
            "file": name,
            "user": str(data.get("user") or "")[:40],
            "machine": str(data.get("machine") or "")[:40],
            "platform": str(data.get("platform") or "")[:40],
            "version": str(data.get("running") or data.get("version") or "")[:20],
            "first_seen": str(data.get("first_seen") or "")[:19],
            "last_seen": str(data.get("last_seen") or "")[:19],
            "projects": _int(data.get("projects")),
            "harnesses": _int(data.get("harnesses")),
            "actions": {str(k)[:24]: _int(v) for k, v in list(actions.items())[:12]},
            "total_actions": sum(_int(v) for v in actions.values()),
            "days_since": round(age_days, 1),
            "stale": age_days > STALE_DAYS,
            "is_me": name == out["mine"],
        })
    out["people"].sort(key=lambda p: p["last_seen"], reverse=True)
    return out


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0
