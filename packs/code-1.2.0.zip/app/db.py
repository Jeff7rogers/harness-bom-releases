"""
db.py — SQLite storage for the Harness BOM tool.

One database file per installation. Plain sqlite3 (no ORM) so the schema is
readable by anyone and packaging with PyInstaller stays simple.

Data model:
    project   -> group -> harness -> part / wire / termination
    partsmaster   normalized part catalogue that accumulates across jobs
    rate          editable labor cycle times, scrap factors, curve settings
    issue         drawing findings raised by the checker
    audit         who did what, when (AS9100D + export recordkeeping)
"""
import os
import sqlite3
import json
import datetime

APP_NAME = "HarnessBOM"


def data_dir() -> str:
    """Per-user writable location. Windows: %LOCALAPPDATA%\\HarnessBOM."""
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    else:
        base = os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")
    d = os.path.join(base, APP_NAME)
    os.makedirs(d, exist_ok=True)
    return d


def db_path() -> str:
    return os.environ.get("HARNESSBOM_DB") or os.path.join(data_dir(), "harnessbom.sqlite3")


SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS project (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL,
    customer        TEXT DEFAULT '',
    rfp_number      TEXT DEFAULT '',
    cage_code       TEXT DEFAULT '',
    standard        TEXT DEFAULT 'IPC/WHMA-A-620 Class 3',
    labor_plan      TEXT DEFAULT '2 technicians in parallel, 8 hr shift',
    qty_low         INTEGER DEFAULT 1,
    qty_high        INTEGER DEFAULT 5,
    -- export control: 'unclassified' | 'review' | 'controlled'
    classification  TEXT NOT NULL DEFAULT 'review',
    class_note      TEXT DEFAULT '',
    bom_scope       TEXT DEFAULT 'parts_consumables',
    include_pricing INTEGER NOT NULL DEFAULT 1,
    -- Archived projects are hidden from the list and left otherwise untouched.
    -- Reversible on purpose: the common case is a quote that went quiet, not a
    -- mistake, and a year later someone wants to see what was bid.
    archived_at     TEXT DEFAULT '',
    created_at      TEXT NOT NULL,
    UNIQUE(name)
);

CREATE TABLE IF NOT EXISTS grp (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER NOT NULL REFERENCES project(id) ON DELETE CASCADE,
    name        TEXT NOT NULL,
    sort_order  INTEGER DEFAULT 0,
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS harness (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id     INTEGER NOT NULL REFERENCES grp(id) ON DELETE CASCADE,
    name         TEXT NOT NULL,
    drawing_no   TEXT DEFAULT '',
    revision     TEXT DEFAULT '',
    title        TEXT DEFAULT '',
    dwg_date     TEXT DEFAULT '',
    author       TEXT DEFAULT '',
    accent       TEXT DEFAULT 'blue',
    sheets       INTEGER DEFAULT 1,
    notes        TEXT DEFAULT '',
    sort_order   INTEGER DEFAULT 0,
    created_at   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS part (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    harness_id  INTEGER NOT NULL REFERENCES harness(id) ON DELETE CASCADE,
    category    TEXT NOT NULL DEFAULT 'Connector',
    tag         TEXT DEFAULT '',
    pn          TEXT NOT NULL,
    mfg         TEXT DEFAULT '',
    description TEXT DEFAULT '',
    uom         TEXT DEFAULT 'EA',
    qty         REAL NOT NULL DEFAULT 1,
    scrap_pct   REAL NOT NULL DEFAULT 3,
    sort_order  INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS wire (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    harness_id  INTEGER NOT NULL REFERENCES harness(id) ON DELETE CASCADE,
    wire_no     INTEGER NOT NULL DEFAULT 1,
    signal      TEXT DEFAULT '',
    awg         TEXT DEFAULT '',
    color       TEXT DEFAULT '-',
    cable       TEXT DEFAULT '',
    run_ref     TEXT DEFAULT '',
    from_end    TEXT DEFAULT '',
    from_pin    TEXT DEFAULT '',
    to_end      TEXT DEFAULT '',
    to_pin      TEXT DEFAULT '',
    term_source TEXT DEFAULT '',
    term_dest   TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS termination (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    harness_id  INTEGER NOT NULL REFERENCES harness(id) ON DELETE CASCADE,
    term_type   TEXT NOT NULL,
    location    TEXT DEFAULT '',
    qty         INTEGER NOT NULL DEFAULT 0,
    tool        TEXT DEFAULT '',
    die         TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS partsmaster (
    pn            TEXT PRIMARY KEY,
    mfg           TEXT DEFAULT '',
    description   TEXT DEFAULT '',
    uom           TEXT DEFAULT 'EA',
    category      TEXT DEFAULT '',
    last_price    REAL,
    last_source   TEXT DEFAULT '',
    last_url      TEXT DEFAULT '',
    lead_wk       INTEGER,
    is_estimate   INTEGER NOT NULL DEFAULT 0,
    notes         TEXT DEFAULT '',
    approved      INTEGER NOT NULL DEFAULT 0,
    times_seen    INTEGER NOT NULL DEFAULT 1,
    last_checked  TEXT
);

-- One row per distributor per part: what that seller quoted, when, at which
-- price break. partsmaster keeps the single number the workbook prices from;
-- this keeps the evidence behind it, so a buyer can see three sellers side by
-- side and a stale number is visibly stale.
CREATE TABLE IF NOT EXISTS quote (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    pn          TEXT NOT NULL,
    provider    TEXT NOT NULL,            -- 'digikey' | 'nexar' | 'manual'
    source      TEXT NOT NULL,            -- the seller's name as shown
    unit_price  REAL,
    currency    TEXT DEFAULT 'USD',
    break_qty   REAL,                     -- the price break this price is for
    moq         INTEGER,
    stock       INTEGER,
    lead_wk     INTEGER,
    url         TEXT DEFAULT '',
    note        TEXT DEFAULT '',
    fetched_at  TEXT NOT NULL,
    UNIQUE(pn, provider, source)
);

CREATE TABLE IF NOT EXISTS rate (
    key         TEXT PRIMARY KEY,
    label       TEXT NOT NULL,
    value       REAL NOT NULL,
    unit        TEXT DEFAULT 'min',
    grp         TEXT DEFAULT 'cycle',
    notes       TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS issue (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER NOT NULL REFERENCES project(id) ON DELETE CASCADE,
    harness_id  INTEGER REFERENCES harness(id) ON DELETE CASCADE,
    code        TEXT DEFAULT '',
    severity    TEXT NOT NULL DEFAULT 'info',
    category    TEXT DEFAULT '',
    message     TEXT NOT NULL,
    resolved    INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS extraction (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    harness_id  INTEGER NOT NULL REFERENCES harness(id) ON DELETE CASCADE,
    filename    TEXT DEFAULT '',
    pdf_path    TEXT DEFAULT '',
    verdict     TEXT DEFAULT '',
    method      TEXT DEFAULT '',
    payload     TEXT NOT NULL,          -- JSON: meta, parts, wires, notes, scan
    usage_note  TEXT DEFAULT '',
    applied     INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL
);

-- A batch upload: several drawings dropped in at once, read in the background.
-- Progress lives in the database rather than in memory so the progress page is
-- just a query, survives a refresh, and can still be read after the fact - the
-- finished batch IS the useful summary of a twelve-drawing program.
CREATE TABLE IF NOT EXISTS batch (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id    INTEGER NOT NULL REFERENCES grp(id) ON DELETE CASCADE,
    total       INTEGER NOT NULL DEFAULT 0,
    done        INTEGER NOT NULL DEFAULT 0,
    want_ocr    INTEGER NOT NULL DEFAULT 0,
    want_model  INTEGER NOT NULL DEFAULT 0,
    -- running | finished | interrupted
    state       TEXT NOT NULL DEFAULT 'running',
    created_at  TEXT NOT NULL,
    finished_at TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS batch_item (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id      INTEGER NOT NULL REFERENCES batch(id) ON DELETE CASCADE,
    filename      TEXT DEFAULT '',
    pdf_path      TEXT DEFAULT '',
    harness_id    INTEGER,
    extraction_id INTEGER,
    -- queued | reading | done | error
    state         TEXT NOT NULL DEFAULT 'queued',
    verdict       TEXT DEFAULT '',
    method        TEXT DEFAULT '',
    n_parts       INTEGER NOT NULL DEFAULT 0,
    n_blank_qty   INTEGER NOT NULL DEFAULT 0,
    message       TEXT DEFAULT '',
    sort_order    INTEGER NOT NULL DEFAULT 0
);

-- Small named values that belong to this installation rather than to a project:
-- where the shared usage folder is, and whatever else needs to outlive a run
-- without earning a column somewhere.
CREATE TABLE IF NOT EXISTS setting (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS audit (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          TEXT NOT NULL,
    user        TEXT DEFAULT '',
    action      TEXT NOT NULL,
    subject     TEXT DEFAULT '',
    detail      TEXT DEFAULT ''
);

CREATE INDEX IF NOT EXISTS ix_grp_project     ON grp(project_id);
CREATE INDEX IF NOT EXISTS ix_harness_group   ON harness(group_id);
CREATE INDEX IF NOT EXISTS ix_part_harness    ON part(harness_id);
CREATE INDEX IF NOT EXISTS ix_wire_harness    ON wire(harness_id);
CREATE INDEX IF NOT EXISTS ix_term_harness    ON termination(harness_id);
CREATE INDEX IF NOT EXISTS ix_issue_project   ON issue(project_id);
CREATE INDEX IF NOT EXISTS ix_batchitem_batch ON batch_item(batch_id);
CREATE INDEX IF NOT EXISTS ix_extract_harness ON extraction(harness_id);
"""

# ---------------------------------------------------------------------------
# Default rates. Everything the labor model uses lives here, editable in the UI.
# Source: IPC/WHMA-A-620 Class 3 per-operation cycle times.
# ---------------------------------------------------------------------------
DEFAULT_RATES = [
    ("op_work_order",      "Pull work order, kit verification, drawing review", 3.0,  "min/harness",   "cycle"),
    ("op_cut_label",       "Cut & label wire from cut list",                    0.8,  "min/cable",     "cycle"),
    ("op_strip_prep",      "Strip & prep one end",                              0.5,  "min/end",       "cycle"),
    ("op_breakout",        "Inner-conductor break-out (multi-pair cable)",      3.0,  "min/cable",     "cycle"),
    ("op_shield_prep",     "Shield prep (comb, twist drain, tin)",              2.0,  "min/shield",    "cycle"),
    ("op_crimp",           "Crimp contact (circular, size 20-22)",              1.5,  "min/crimp",     "cycle"),
    ("op_crimp_dsub",      "Crimp D-sub contact",                               2.0,  "min/crimp",     "cycle"),
    ("op_insert_contact",  "Insert contact into connector body",                0.5,  "min/contact",   "cycle"),
    ("op_rj45",            "RJ45 termination (untwist, sequence, crimp, test)", 8.0,  "min/connector", "cycle"),
    ("op_ring_lug",        "Ring-lug crimp",                                    2.0,  "min/crimp",     "cycle"),
    ("op_usb_solder",      "USB solder-cup termination (4 joints)",             6.0,  "min/connector", "cycle"),
    ("op_solder_sleeve",   "Solder-sleeve shield termination",                  4.0,  "min/sleeve",    "cycle"),
    ("op_band_shield",     "Shield termination to backshell (band clamp)",      3.0,  "min/band",      "cycle"),
    ("op_lap_splice",      "Lap splice + heat shrink (IPC-A-620 8.1.4)",        4.0,  "min/splice",    "cycle"),
    ("op_cap_stow",        "Trim, cap & stow one unused conductor/lead",        0.6,  "min/lead",      "cycle"),
    ("op_sleeving",        "Install protective sleeving (per branch/size)",     4.5,  "min/section",   "cycle"),
    ("op_label",           "Install ID label",                                  0.5,  "min/label",     "cycle"),
    ("op_backshell",       "Backshell assembly + tape build-up",                8.0,  "min/connector", "cycle"),
    ("op_tie",             "Lacing / cable tie at transition",                  1.5,  "min/tie",       "cycle"),
    ("op_continuity",      "Continuity test (all conductors)",                 18.0,  "min/harness",   "cycle"),
    ("op_hipot",           "Hi-pot on power circuits",                          6.0,  "min/harness",   "cycle"),
    ("op_visual",          "Class 3 visual inspection (100%)",                 25.0,  "min/harness",   "cycle"),
    ("op_pack",            "Serialize, log, bag & tag, ESD pack",               6.0,  "min/harness",   "cycle"),

    ("scrap_connector",    "Scrap: circular shells, backshells",                3.0,  "%",  "scrap"),
    ("scrap_dsub",         "Scrap: D-sub connectors",                           5.0,  "%",  "scrap"),
    ("scrap_cable",        "Scrap: cable, wire, ring lugs",                    10.0,  "%",  "scrap"),
    ("scrap_contact",      "Scrap: contacts (volume yield)",                   15.0,  "%",  "scrap"),
    ("scrap_consumable",   "Scrap: labels, small consumables",                 20.0,  "%",  "scrap"),
    ("scrap_sleeve",       "Scrap: solder sleeves, spare contacts",            25.0,  "%",  "scrap"),

    ("curve_rate",         "Learning curve (0.90 = 90% curve)",                 0.90, "ratio", "curve"),
    ("curve_enabled",      "Apply learning curve to lot labor (1 = yes)",       0.0,  "flag",  "curve"),
    ("shift_hours",        "Productive hours per technician per shift",         8.0,  "hr",    "curve"),
    ("techs",              "Technicians working in parallel",                   2.0,  "ea",    "curve"),
    ("shop_rate",          "Shop labor rate",                                 105.0,  "$/hr",  "curve"),
]

CATEGORY_SCRAP = {
    "Connector": "scrap_connector",
    "Connector Accessory": "scrap_connector",
    "Contact": "scrap_contact",
    "Terminal": "scrap_contact",
    "Cable": "scrap_cable",
    "Wire": "scrap_cable",
    "Sleeving": "scrap_cable",
    "Heat Shrink": "scrap_consumable",
    "Shield Term": "scrap_sleeve",
    "Solder": "scrap_consumable",
    "Tape": "scrap_consumable",
    "Lacing Tape": "scrap_consumable",
    "Tie Wrap": "scrap_consumable",
    "Boot": "scrap_connector",
    "Label": "scrap_consumable",
    "Marker": "scrap_consumable",
}

CATEGORIES = list(CATEGORY_SCRAP.keys())


def connect(path: str = None) -> sqlite3.Connection:
    conn = sqlite3.connect(path or db_path())
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init(path: str = None) -> sqlite3.Connection:
    conn = connect(path)
    conn.executescript(SCHEMA)
    _migrate(conn)
    cur = conn.execute("SELECT COUNT(*) AS n FROM rate")
    if cur.fetchone()["n"] == 0:
        conn.executemany(
            "INSERT INTO rate (key, label, value, unit, grp) VALUES (?,?,?,?,?)",
            DEFAULT_RATES,
        )
    conn.commit()
    return conn


def _migrate(conn):
    """Additive-only column adds, so an existing installation keeps its data."""
    for table, column, ddl in (("wire", "run_ref", "TEXT DEFAULT ''"),
                               ("batch", "want_model", "INTEGER DEFAULT 0"),
                               ("project", "archived_at", "TEXT DEFAULT ''")):
        cols = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})")}
        if column not in cols:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")


def now() -> str:
    return datetime.datetime.now().isoformat(timespec="seconds")


def log(conn, action, subject="", detail="", user=None):
    """Append-only audit trail. Never deleted by the app."""
    conn.execute(
        "INSERT INTO audit (ts, user, action, subject, detail) VALUES (?,?,?,?,?)",
        (now(), user or os.environ.get("USERNAME") or os.environ.get("USER") or "", action, subject, detail),
    )


def rates(conn) -> dict:
    return {r["key"]: r["value"] for r in conn.execute("SELECT key, value FROM rate")}


def scrap_for(conn, category: str) -> float:
    key = CATEGORY_SCRAP.get(category, "scrap_consumable")
    row = conn.execute("SELECT value FROM rate WHERE key = ?", (key,)).fetchone()
    return float(row["value"]) if row else 10.0


# ---------------------------------------------------------------------------
# Parts master
# ---------------------------------------------------------------------------
def remember_part(conn, pn, mfg="", description="", uom="EA", category=""):
    """
    Upsert into the parts master.

    The merge key is the PART NUMBER ALONE. Manufacturer is informational.
    This is deliberate: during the Vast HAVEN trial the same M85049/128-3 band
    clamp was entered with three different manufacturer strings and split into
    three procurement lines on the combined sheet. Normalizing here is what
    stops that reaching a buyer.
    """
    pn = (pn or "").strip().upper()
    if not pn:
        return None
    row = conn.execute("SELECT * FROM partsmaster WHERE pn = ?", (pn,)).fetchone()
    if row is None:
        conn.execute(
            "INSERT INTO partsmaster (pn, mfg, description, uom, category, times_seen, last_checked)"
            " VALUES (?,?,?,?,?,1,?)",
            (pn, mfg or "", description or "", uom or "EA", category or "", now()),
        )
        return pn
    # keep the richest description we have seen; bump the counter
    desc = row["description"] if len(row["description"] or "") >= len(description or "") else description
    conn.execute(
        "UPDATE partsmaster SET mfg = COALESCE(NULLIF(?,''), mfg), description = ?,"
        " uom = COALESCE(NULLIF(?,''), uom), category = COALESCE(NULLIF(?,''), category),"
        " times_seen = times_seen + 1, last_checked = ? WHERE pn = ?",
        (mfg or "", desc or "", uom or "", category or "", now(), pn),
    )
    return pn


def record_quote(conn, q):
    """Upsert one seller's quote for one part number."""
    pn = (q.get("pn") or "").strip().upper()
    if not pn:
        return
    conn.execute(
        "INSERT INTO quote (pn, provider, source, unit_price, currency, break_qty,"
        " moq, stock, lead_wk, url, note, fetched_at)"
        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
        # Price, stock and break move with every refresh and must overwrite —
        # stock going to zero is news. Lead time and the seller's URL are only
        # sometimes reported, so a refresh that omits them must not erase what
        # an earlier one found: a blank is silence, not an answer.
        " ON CONFLICT(pn, provider, source) DO UPDATE SET"
        "   unit_price=excluded.unit_price, currency=excluded.currency,"
        "   break_qty=excluded.break_qty, moq=COALESCE(excluded.moq, quote.moq),"
        "   stock=excluded.stock,"
        "   lead_wk=COALESCE(excluded.lead_wk, quote.lead_wk),"
        "   url=CASE WHEN TRIM(COALESCE(excluded.url,'')) <> '' THEN excluded.url"
        "            ELSE quote.url END,"
        "   note=excluded.note, fetched_at=excluded.fetched_at",
        (pn, q.get("provider", ""), q.get("source", ""), q.get("unit_price"),
         q.get("currency", "USD"), q.get("break_qty"), q.get("moq"), q.get("stock"),
         q.get("lead_wk"), q.get("url", ""), q.get("note", ""), now()))


def apply_quote_to_master(conn, q):
    """
    Make a fetched quote the price the workbook uses.

    A fetched catalogue price is not an estimate, so is_estimate is cleared —
    that flag means "somebody guessed", and the workbook renders it in red and
    lists it as needing an RFQ. Description and manufacturer are only filled in
    where the part is currently blank: what the drawing calls a part outranks
    what a distributor calls it.
    """
    pn = (q.get("pn") or "").strip().upper()
    if not pn or q.get("unit_price") is None:
        return
    # Create the row if this part number has somehow never been seen, but do not
    # go through remember_part: that bumps times_seen, which counts how often a
    # part appears on a harness. Pricing a part is not seeing it again.
    conn.execute(
        "INSERT OR IGNORE INTO partsmaster (pn, uom, times_seen, last_checked)"
        " VALUES (?,?,0,?)", (pn, q.get("uom") or "EA", now()))
    conn.execute(
        "UPDATE partsmaster SET last_price=?, last_source=?, last_url=?,"
        " lead_wk=COALESCE(?, lead_wk), is_estimate=0,"
        " mfg=CASE WHEN TRIM(COALESCE(mfg,''))='' THEN ? ELSE mfg END,"
        " description=CASE WHEN TRIM(COALESCE(description,''))='' THEN ? ELSE description END,"
        " last_checked=? WHERE pn=?",
        (q["unit_price"], q.get("source", ""), q.get("url", ""), q.get("lead_wk"),
         q.get("mfg", ""), q.get("description", ""), now(), pn))


def quotes_for(conn, pn):
    """Every seller's quote for one part, cheapest first."""
    return conn.execute(
        "SELECT * FROM quote WHERE pn = ? ORDER BY"
        "  CASE WHEN COALESCE(stock,0) > 0 THEN 0 ELSE 1 END,"
        "  unit_price", ((pn or "").strip().upper(),)).fetchall()


def master_lookup(conn, pn):
    return conn.execute("SELECT * FROM partsmaster WHERE pn = ?", ((pn or "").strip().upper(),)).fetchone()


# ---------------------------------------------------------------------------
# Archiving and deleting a project
# ---------------------------------------------------------------------------
def set_archived(conn, pid: int, archived: bool):
    """Hide a project from the list, or bring it back. Nothing else changes."""
    conn.execute("UPDATE project SET archived_at = ? WHERE id = ?",
                 (now() if archived else "", pid))
    conn.commit()


def project_drawings(conn, pid: int) -> list:
    """Every drawing file this project copied into the program's own folder.

    Only those: the originals the person uploaded from live wherever they live,
    and deleting a project has no business touching them.
    """
    paths = []
    for row in conn.execute(
            "SELECT DISTINCT e.pdf_path AS p FROM extraction e"
            "  JOIN harness h ON h.id = e.harness_id"
            "  JOIN grp g     ON g.id = h.group_id"
            " WHERE g.project_id = ? AND TRIM(COALESCE(e.pdf_path,'')) <> ''", (pid,)):
        paths.append(row["p"])
    for row in conn.execute(
            "SELECT DISTINCT bi.pdf_path AS p FROM batch_item bi"
            "  JOIN batch b ON b.id = bi.batch_id"
            "  JOIN grp g   ON g.id = b.group_id"
            " WHERE g.project_id = ? AND TRIM(COALESCE(bi.pdf_path,'')) <> ''", (pid,)):
        paths.append(row["p"])
    root = os.path.realpath(os.path.join(data_dir(), "drawings"))
    out = []
    for path in dict.fromkeys(paths):
        try:
            real = os.path.realpath(path)
        except OSError:                                       # pragma: no cover
            continue
        # Only ever delete inside our own drawings folder. A stored path that
        # points anywhere else is either someone's original or something odd,
        # and in both cases it is not ours to remove.
        if real.startswith(root + os.sep) and os.path.isfile(real):
            out.append(real)
    return out


def delete_project(conn, pid: int, drawings: bool = False) -> dict:
    """
    Remove a project and everything under it. Returns what went.

    The database rows go either way; `drawings` decides whether the PDFs this
    program copied in go with them. For a controlled job that deletion is the
    point - it is how the drawing stops living on that PC.
    """
    row = conn.execute("SELECT name, classification FROM project WHERE id = ?",
                       (pid,)).fetchone()
    if not row:
        return {"name": "", "harnesses": 0, "files": 0, "kept": []}
    files = project_drawings(conn, pid) if drawings else []
    n_harness = conn.execute(
        "SELECT COUNT(*) AS n FROM harness h JOIN grp g ON g.id = h.group_id"
        " WHERE g.project_id = ?", (pid,)).fetchone()["n"]

    removed, kept = 0, []
    for path in files:
        try:
            os.remove(path)
            removed += 1
        except OSError as exc:
            kept.append(f"{os.path.basename(path)} ({exc.strerror or exc})")

    # Foreign keys cascade from project through groups, harnesses, parts, wires,
    # terminations, extractions, batches. Issues and the audit log are not
    # children of it: issues go with the project, the audit log never does.
    conn.execute("DELETE FROM issue WHERE project_id = ?", (pid,))
    conn.execute("DELETE FROM project WHERE id = ?", (pid,))
    log(conn, "project_deleted", row["name"],
        f"{n_harness} harness(es), {removed} drawing file(s) removed, "
        f"classification {row['classification']}"
        + (f", {len(kept)} file(s) could not be removed" if kept else ""))
    conn.commit()
    return {"name": row["name"], "harnesses": n_harness, "files": removed, "kept": kept}
