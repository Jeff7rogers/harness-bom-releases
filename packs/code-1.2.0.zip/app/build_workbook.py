"""
build_workbook.py — Aerospace wire-harness BOM workbook engine.

Public API
----------
    build_workbook(out_path, program, harnesses, pricing=None, include_assumptions=True)

`program` : dict
    title       : str   program name (e.g. "CCH Cables")
    subtitle    : str   one-line context (RFP no., customer, CAGE)
    standard    : str   e.g. "IPC/WHMA-A-620 Class 3"
    quantities  : list[int]  lot sizes to scale to, exactly two, e.g. [50, 100]
    labor_plan  : str   e.g. "2 technicians in parallel, 8 hr shift"
    assumptions : list[(section_title, [(label, body), ...])]   optional; if omitted a
                  sensible default set is generated from `program` + `harnesses`.

`harnesses` : list[dict], each:
    name         : str  tab name (e.g. "J1 Harness")
    accent       : str  "blue" | "teal" | "purple" | "green"
    meta         : list[(label, value)]      drawing info block
    parts        : list[(category, tag, pn, mfg, description, uom, qty_per_harness, scrap_pct)]
    wires        : list[(no, signal, awg, color, cable, from_end, from_pin, to_end, to_pin,
                         term_source, term_dest)]
    terminations : list[(type, location, qty, tool, die)]
    labor_hr     : float  average per-harness labor hours (Class 3)

`pricing` : dict|None  keyed by part number; see references/vendors-and-pricing.md for the schema.

`include_assumptions` : bool  add the Assumptions & Sources tab.

After building, ALWAYS recalc:  python <xlsx-skill>/scripts/recalc.py <out_path> 30
and confirm zero formula errors.
"""
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

FONT = "Arial"
def F(sz=10, b=False, color="000000", it=False):
    return Font(name=FONT, size=sz, bold=b, color=color, italic=it)

TITLE = F(16, True, "FFFFFF")
H1    = F(13, True, "FFFFFF")
H2    = F(11, True, "FFFFFF")
BODY  = F(10)
BOLD  = F(10, True)
SMALL = F(9, False, "595959", it=True)
NOTE  = F(9, False, "404040", it=True)
EST   = F(9, False, "C00000", it=True)

ACCENTS = {
    "blue":   "2E5597",
    "teal":   "2F5F6F",
    "purple": "5F2F6F",
    "green":  "375623",
}
NAVY = "1F3864"
def fill(hex_):  return PatternFill("solid", start_color=hex_)
LIGHT_BLUE = fill("D9E2F3")
LIGHT_GRAY = fill("F2F2F2")
LIGHT_GREEN= fill("E2EFDA")
YELLOW     = fill("FFF2CC")
RED_TINT   = fill("FCE4D6")

thin = Side(border_style="thin", color="808080")
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
CEN = Alignment(horizontal="center", vertical="center", wrap_text=True)
LF  = Alignment(horizontal="left", vertical="center", wrap_text=True)
LT  = Alignment(horizontal="left", vertical="top", wrap_text=True)

CATEGORY_ORDER = ["Connector","Connector Accessory","Contact","Terminal","Cable","Wire",
                  "Sleeving","Heat Shrink","Shield Term","Solder","Tape","Lacing Tape",
                  "Tie Wrap","Boot","Label","Marker"]

MONEY4 = '"$"#,##0.0000;"$"#,##0.0000;-'
MONEY2 = '"$"#,##0.00;"$"#,##0.00;-'


def _widths(ws, ws_list):
    for i, w in enumerate(ws_list, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w

def _hdr(ws, row, ncols, hexfill=NAVY, font=H2):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = fill(hexfill); cell.font = font
        cell.alignment = CEN; cell.border = BORDER

def _banner(ws, row, ncols, text, hexfill=NAVY, font=TITLE, h=28):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=text)
    c.fill = fill(hexfill); c.font = font; c.alignment = CEN
    ws.row_dimensions[row].height = h

def _section(ws, row, ncols, text, hexfill=NAVY):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=text)
    c.fill = fill(hexfill); c.font = F(12, True, "FFFFFF"); c.alignment = CEN
    ws.row_dimensions[row].height = 22

def _body(ws, r1, c1, r2, c2, alt=True):
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            cell = ws.cell(row=r, column=c)
            cell.border = BORDER
            if not cell.font or cell.font.name != FONT:
                cell.font = BODY
        if alt and (r - r1) % 2 == 1:
            for c in range(c1, c2 + 1):
                ws.cell(row=r, column=c).fill = LIGHT_GRAY

def _cat_key(p):
    try: return (CATEGORY_ORDER.index(p[0]), str(p[1]))
    except ValueError: return (99, str(p[1]))


def _render_harness(wb, h, quantities):
    accent = ACCENTS.get(h.get("accent", "blue"), ACCENTS["blue"])
    q1, q2 = quantities[0], quantities[1]
    ws = wb.create_sheet(h["name"])
    ws.sheet_view.showGridLines = False
    NC = 14
    _widths(ws, [6,14,22,22,12,36,8,11,10,11,11,11,11,22])
    _banner(ws, 1, NC, h["name"], hexfill=accent)
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=NC)
    ws.cell(row=2, column=1,
            value=f"Quantities scaled for {q1} and {q2} units").font = SMALL
    ws.cell(row=2, column=1).alignment = CEN

    r = 4
    _section(ws, r, NC, "DRAWING INFO", hexfill=accent); r += 1
    for label, value in h.get("meta", []):
        ws.cell(row=r, column=2, value=label).font = BOLD
        ws.cell(row=r, column=2).fill = LIGHT_BLUE
        ws.cell(row=r, column=2).alignment = LF; ws.cell(row=r, column=2).border = BORDER
        ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=NC)
        ws.cell(row=r, column=3, value=value).font = BODY
        ws.cell(row=r, column=3).alignment = LF; ws.cell(row=r, column=3).border = BORDER
        r += 1

    # Parts BOM
    r += 1
    _section(ws, r, NC, "PARTS BOM (per harness + scaled)", hexfill=accent); r += 1
    heads = ["Item","Tag","Part Number","Manufacturer","Category","Description","UoM",
             "Qty / Harness","Scrap %",f"Qty {q1}",f"Qty {q2}",f"Order {q1}",f"Order {q2}","Notes"]
    for i, hd in enumerate(heads, start=1): ws.cell(row=r, column=i, value=hd)
    _hdr(ws, r, NC, accent); ws.row_dimensions[r].height = 32
    bs = r + 1
    parts = sorted(h.get("parts", []), key=_cat_key)
    for i, p in enumerate(parts):
        rr = bs + i
        ws.cell(row=rr, column=1, value=i+1)
        ws.cell(row=rr, column=2, value=p[1]); ws.cell(row=rr, column=3, value=p[2])
        ws.cell(row=rr, column=4, value=p[3]); ws.cell(row=rr, column=5, value=p[0])
        ws.cell(row=rr, column=6, value=p[4]); ws.cell(row=rr, column=7, value=p[5])
        ws.cell(row=rr, column=8, value=p[6]); ws.cell(row=rr, column=9, value=p[7]/100.0)
        ws.cell(row=rr, column=10, value=f"=H{rr}*{q1}")
        ws.cell(row=rr, column=11, value=f"=H{rr}*{q2}")
        ws.cell(row=rr, column=12, value=f"=CEILING(J{rr}*(1+I{rr}),1)")
        ws.cell(row=rr, column=13, value=f"=CEILING(K{rr}*(1+I{rr}),1)")
    be = bs + len(parts) - 1
    _body(ws, bs, 1, be, NC)
    for rr in range(bs, be+1):
        ws.cell(row=rr, column=9).number_format = "0%"
        for c in (8,10,11,12,13):
            ws.cell(row=rr, column=c).number_format = "#,##0"; ws.cell(row=rr, column=c).alignment = CEN
        ws.cell(row=rr, column=1).alignment = CEN; ws.cell(row=rr, column=7).alignment = CEN
    sub = be + 1
    ws.cell(row=sub, column=2, value="PARTS BOM SUBTOTAL").font = BOLD
    ws.cell(row=sub, column=3, value=f'=COUNTA(C{bs}:C{be}) & " line items"').font = BOLD
    ws.cell(row=sub, column=3).alignment = CEN
    for c in range(1, NC+1):
        ws.cell(row=sub, column=c).fill = YELLOW; ws.cell(row=sub, column=c).border = BORDER
    r = sub + 2

    # Wire list
    _section(ws, r, NC, "WIRE LIST (all conductors, both terminations)", hexfill=accent); r += 1
    wheads = ["Wire #","Signal","AWG","Color","Cable / Stock","From End","Pin","To End","Pin",
              "Term @ Source","Term @ Destination","","",""]
    for i, hd in enumerate(wheads, start=1): ws.cell(row=r, column=i, value=hd)
    _hdr(ws, r, NC, accent); ws.row_dimensions[r].height = 32
    wsr = r + 1
    for i, w in enumerate(h.get("wires", [])):
        rr = wsr + i
        for c, v in enumerate(w, start=1): ws.cell(row=rr, column=c, value=v)
    we = wsr + len(h.get("wires", [])) - 1
    if we >= wsr:
        _body(ws, wsr, 1, we, 11)
        for rr in range(wsr, we+1):
            for c in (1,3,7,9): ws.cell(row=rr, column=c).alignment = CEN
    sub2 = max(we, wsr) + 1
    ws.cell(row=sub2, column=2, value="WIRE LIST SUBTOTAL").font = BOLD
    ws.cell(row=sub2, column=3, value=f'=COUNTA(A{wsr}:A{we}) & " wires"').font = BOLD
    ws.cell(row=sub2, column=3).alignment = CEN
    for c in range(1, NC+1):
        ws.cell(row=sub2, column=c).fill = YELLOW; ws.cell(row=sub2, column=c).border = BORDER
    r = sub2 + 2

    # Terminations
    _section(ws, r, NC, "CRIMPS / TERMINATIONS (scaled)", hexfill=accent); r += 1
    theads = ["#","Termination Type","Location","Per Harness",f"For {q1}",f"For {q2}","Tool","Die","","","","","",""]
    for i, hd in enumerate(theads, start=1): ws.cell(row=r, column=i, value=hd)
    _hdr(ws, r, NC, accent); ws.row_dimensions[r].height = 32
    ts = r + 1
    for i, t in enumerate(h.get("terminations", [])):
        rr = ts + i
        ws.cell(row=rr, column=1, value=i+1)
        ws.cell(row=rr, column=2, value=t[0]); ws.cell(row=rr, column=3, value=t[1])
        ws.cell(row=rr, column=4, value=t[2])
        ws.cell(row=rr, column=5, value=f"=D{rr}*{q1}")
        ws.cell(row=rr, column=6, value=f"=D{rr}*{q2}")
        ws.cell(row=rr, column=7, value=t[3]); ws.cell(row=rr, column=8, value=t[4])
    te = ts + len(h.get("terminations", [])) - 1
    _body(ws, ts, 1, te, 8)
    for rr in range(ts, te+1):
        for c in (1,4,5,6):
            ws.cell(row=rr, column=c).alignment = CEN; ws.cell(row=rr, column=c).number_format = "#,##0"
    sub3 = te + 1
    ws.cell(row=sub3, column=2, value="TOTAL TERMINATIONS").font = BOLD
    ws.cell(row=sub3, column=4, value=f"=SUM(D{ts}:D{te})").font = BOLD
    ws.cell(row=sub3, column=5, value=f"=SUM(E{ts}:E{te})").font = BOLD
    ws.cell(row=sub3, column=6, value=f"=SUM(F{ts}:F{te})").font = BOLD
    for c in (4,5,6):
        ws.cell(row=sub3, column=c).alignment = CEN; ws.cell(row=sub3, column=c).number_format = "#,##0"
    for c in range(1, NC+1):
        ws.cell(row=sub3, column=c).fill = YELLOW; ws.cell(row=sub3, column=c).border = BORDER
    r = sub3 + 2

    # Labor & schedule
    _section(ws, r, NC, "LABOR & SCHEDULE (Class 3, 2 techs, 90% learning curve)", hexfill=accent); r += 1
    lh = h.get("labor_hr", 5.0)
    rows = [
        ("Labor hours per harness (first article)", lh*1.4, "0.0"),
        (f"Labor hours per harness (avg over lot of {q1})", lh*0.65, "0.0"),
        (f"Labor hours per harness (avg over lot of {q2})", lh*0.58, "0.0"),
        (f"Total labor — lot {q1} (hr)", lh*q1*0.65, "#,##0"),
        (f"Total labor — lot {q2} (hr)", lh*q2*0.58, "#,##0"),
        (f"Production days — lot {q1} (2 techs × 8 hr)", lh*q1*0.65/16, "0.0"),
        (f"Production days — lot {q2} (2 techs × 8 hr)", lh*q2*0.58/16, "0.0"),
    ]
    for i, (label, val, fmt) in enumerate(rows):
        rr = r + i
        ws.cell(row=rr, column=2, value=label).font = BOLD
        ws.cell(row=rr, column=2).fill = LIGHT_BLUE
        ws.cell(row=rr, column=2).alignment = LF; ws.cell(row=rr, column=2).border = BORDER
        ws.merge_cells(start_row=rr, start_column=3, end_row=rr, end_column=4)
        ws.cell(row=rr, column=3, value=val).font = BODY
        ws.cell(row=rr, column=3).number_format = fmt; ws.cell(row=rr, column=3).alignment = CEN
        ws.cell(row=rr, column=3).border = BORDER; ws.cell(row=rr, column=4).border = BORDER
    ws.freeze_panes = "A4"


def _merge_parts(harnesses):
    """Merge parts across harnesses keyed by (pn, mfg, uom)."""
    keys = [h["name"].split()[0] for h in harnesses]  # e.g. "J1","J2","J3"
    merged = {}
    for h in harnesses:
        hk = h["name"].split()[0]
        per = {}
        for cat, tag, pn, mfg, desc, uom, qty, scrap in h.get("parts", []):
            k = (str(pn).strip(), str(mfg).strip(), uom)
            if k not in per:
                per[k] = {"cat":cat,"tag":tag,"pn":pn,"mfg":mfg,"desc":desc,"uom":uom,
                          "qty":{kk:0 for kk in keys},"scrap":scrap}
            per[k]["qty"][hk] += qty
            per[k]["scrap"] = max(per[k]["scrap"], scrap)
        for k, v in per.items():
            if k not in merged:
                merged[k] = v
            else:
                for kk in keys:
                    merged[k]["qty"][kk] = max(merged[k]["qty"][kk], v["qty"][kk])
                merged[k]["scrap"] = max(merged[k]["scrap"], v["scrap"])
                if len(v["desc"]) > len(merged[k]["desc"]): merged[k]["desc"] = v["desc"]
    return keys, sorted(merged.values(), key=lambda x: ((CATEGORY_ORDER.index(x["cat"])
                        if x["cat"] in CATEGORY_ORDER else 99), x["pn"]))


def _conv_price(price, src_uom, bom_uom):
    if price is None: return None
    if bom_uom == "IN" and src_uom == "FT": return round(price/12, 4)
    return price


def _render_combined(wb, harnesses, quantities, pricing):
    keys, items = _merge_parts(harnesses)
    q1, q2 = quantities
    cp = wb.create_sheet("Combined Parts")
    cp.sheet_view.showGridLines = False
    n_keys = len(keys)
    base_heads = ["Item","Tag","Part Number","Manufacturer","Category","Description","UoM"]
    qty_heads  = [f"Qty / {k}" for k in keys] + ["Qty / Set","Scrap %",f"Lot {q1}",f"Lot {q2}",f"Order {q1}",f"Order {q2}"]
    price_heads= (["Vendor 1","V1 $/UoM","Vendor 2","V2 $/UoM","Vendor 3","V3 $/UoM",
                   "Best $/UoM",f"Ext Cost Lot {q1}",f"Ext Cost Lot {q2}","Lead (wk)","Source / Notes"]
                  if pricing else [])
    heads = base_heads + qty_heads + price_heads
    NC = len(heads)
    widths = [6,16,22,22,16,40,8] + [9]*n_keys + [9,9,11,11,12,12]
    if pricing: widths += [20,12,20,12,20,12,12,14,14,9,42]
    _widths(cp, widths)

    title = "COMBINED PARTS LIST — ALL HARNESSES" + (" (with pricing)" if pricing else "")
    _banner(cp, 1, NC, title, hexfill="375623")
    cp.merge_cells(start_row=2, start_column=1, end_row=2, end_column=NC)
    note = ("Per-harness counts → per-set → lot totals, scrap-adjusted order quantities."
            + (" Red italic = estimate pending vendor quote." if pricing else ""))
    cp.cell(row=2, column=1, value=note).font = SMALL
    cp.cell(row=2, column=1).alignment = CEN

    for i, hd in enumerate(heads, start=1): cp.cell(row=4, column=i, value=hd)
    _hdr(cp, 4, NC, "375623"); cp.row_dimensions[4].height = 36

    # column index map
    c_uom = 7
    c_qty0 = 8                       # first per-harness qty col
    c_set = c_qty0 + n_keys          # Qty/Set
    c_scrap = c_set + 1
    c_lot1 = c_scrap + 1
    c_lot2 = c_lot1 + 1
    c_ord1 = c_lot2 + 1
    c_ord2 = c_ord1 + 1
    # pricing cols start after order2
    c_v1 = c_ord2 + 1

    ds = 5
    for i, it in enumerate(items):
        rr = ds + i
        cp.cell(row=rr, column=1, value=i+1)
        cp.cell(row=rr, column=2, value=it["tag"]); cp.cell(row=rr, column=3, value=it["pn"])
        cp.cell(row=rr, column=4, value=it["mfg"]); cp.cell(row=rr, column=5, value=it["cat"])
        cp.cell(row=rr, column=6, value=it["desc"]); cp.cell(row=rr, column=7, value=it["uom"])
        for j, k in enumerate(keys):
            cp.cell(row=rr, column=c_qty0+j, value=it["qty"][k])
        set_cells = "+".join(f"{get_column_letter(c_qty0+j)}{rr}" for j in range(n_keys))
        cp.cell(row=rr, column=c_set, value=f"={set_cells}")
        cp.cell(row=rr, column=c_scrap, value=it["scrap"]/100.0)
        cp.cell(row=rr, column=c_lot1, value=f"={get_column_letter(c_set)}{rr}*{q1}")
        cp.cell(row=rr, column=c_lot2, value=f"={get_column_letter(c_set)}{rr}*{q2}")
        cp.cell(row=rr, column=c_ord1,
                value=f"=CEILING({get_column_letter(c_lot1)}{rr}*(1+{get_column_letter(c_scrap)}{rr}),1)")
        cp.cell(row=rr, column=c_ord2,
                value=f"=CEILING({get_column_letter(c_lot2)}{rr}*(1+{get_column_letter(c_scrap)}{rr}),1)")
    de = ds + len(items) - 1
    _body(cp, ds, 1, de, NC)

    # formats + highlight used-in cells
    for i, it in enumerate(items):
        rr = ds + i
        cp.cell(row=rr, column=c_scrap).number_format = "0%"
        for c in [c_qty0+j for j in range(n_keys)] + [c_set, c_lot1, c_lot2, c_ord1, c_ord2]:
            cp.cell(row=rr, column=c).number_format = "#,##0"; cp.cell(row=rr, column=c).alignment = CEN
        cp.cell(row=rr, column=1).alignment = CEN; cp.cell(row=rr, column=7).alignment = CEN
        for j, k in enumerate(keys):
            if it["qty"][k] > 0:
                cp.cell(row=rr, column=c_qty0+j).fill = LIGHT_GREEN

    # pricing
    if pricing:
        for i, it in enumerate(items):
            rr = ds + i
            pn = str(it["pn"]).strip()
            bom_uom = it["uom"]
            pd = pricing.get(pn) or pricing.get(it["pn"])
            if not pd:
                cp.cell(row=rr, column=c_v1, value="Quote required").alignment = LF
                cp.cell(row=rr, column=c_v1+10, value="Not yet researched — buyer to source").font = NOTE
                for c in range(c_v1, c_v1+11): cp.cell(row=rr, column=c).border = BORDER
                continue
            src_uom = pd.get("uom","EA")
            v1 = _conv_price(pd.get("v1_price"), src_uom, bom_uom)
            v2 = _conv_price(pd.get("v2_price"), src_uom, bom_uom)
            v3 = _conv_price(pd.get("v3_price"), src_uom, bom_uom)
            cp.cell(row=rr, column=c_v1,   value=pd.get("v1_name","")).alignment = LF
            cp.cell(row=rr, column=c_v1+1, value=v1)
            cp.cell(row=rr, column=c_v1+2, value=pd.get("v2_name","")).alignment = LF
            cp.cell(row=rr, column=c_v1+3, value=v2)
            cp.cell(row=rr, column=c_v1+4, value=pd.get("v3_name","")).alignment = LF
            cp.cell(row=rr, column=c_v1+5, value=v3)
            reals = [p for p in (v1,v2,v3) if p is not None]
            best_col = c_v1+6
            if reals:
                cp.cell(row=rr, column=best_col, value=min(reals)).font = BOLD
            elif pd.get("is_estimate"):
                est = _conv_price(pd.get("estimate"), src_uom, bom_uom)
                cell = cp.cell(row=rr, column=best_col, value=est)
                cell.font = EST; cell.fill = RED_TINT
            else:
                cp.cell(row=rr, column=best_col, value="Quote req")
            bp = get_column_letter(best_col) + str(rr)
            o1 = get_column_letter(c_ord1) + str(rr)
            o2 = get_column_letter(c_ord2) + str(rr)
            cp.cell(row=rr, column=c_v1+7, value=f'=IF(ISNUMBER({bp}),{bp}*{o1},"")')
            cp.cell(row=rr, column=c_v1+8, value=f'=IF(ISNUMBER({bp}),{bp}*{o2},"")')
            cp.cell(row=rr, column=c_v1+9, value=pd.get("lead_wk"))
            notes = pd.get("notes","")
            if pd.get("is_estimate"): notes = "EST — " + notes
            cp.cell(row=rr, column=c_v1+10, value=notes).font = NOTE
            cp.cell(row=rr, column=c_v1+10).alignment = LF
            for c in (c_v1+1, c_v1+3, c_v1+5, best_col):
                cp.cell(row=rr, column=c).number_format = MONEY4; cp.cell(row=rr, column=c).alignment = CEN
            for c in (c_v1+7, c_v1+8):
                cp.cell(row=rr, column=c).number_format = MONEY2; cp.cell(row=rr, column=c).alignment = CEN
            cp.cell(row=rr, column=c_v1+9).alignment = CEN; cp.cell(row=rr, column=c_v1+9).number_format = "0"
            for c in range(c_v1, c_v1+11): cp.cell(row=rr, column=c).border = BORDER

    # totals row
    tr = de + 1
    cp.cell(row=tr, column=2, value="TOTALS").font = BOLD
    cp.cell(row=tr, column=3, value=f'=COUNTA(C{ds}:C{de}) & " unique P/Ns"').font = BOLD
    cp.cell(row=tr, column=3).alignment = CEN
    for c in range(1, NC+1):
        cp.cell(row=tr, column=c).fill = YELLOW; cp.cell(row=tr, column=c).border = BORDER
    if pricing:
        x = get_column_letter(c_v1+7); y = get_column_letter(c_v1+8)
        cp.cell(row=tr, column=c_v1, value="TOTAL EXTENDED COST →").font = BOLD
        cp.cell(row=tr, column=c_v1).alignment = LF
        cp.cell(row=tr, column=c_v1+7,
                value=f"=SUMPRODUCT(--ISNUMBER({x}{ds}:{x}{de}),{x}{ds}:{x}{de})")
        cp.cell(row=tr, column=c_v1+8,
                value=f"=SUMPRODUCT(--ISNUMBER({y}{ds}:{y}{de}),{y}{ds}:{y}{de})")
        for c in (c_v1+7, c_v1+8):
            cp.cell(row=tr, column=c).font = BOLD; cp.cell(row=tr, column=c).number_format = MONEY2
            cp.cell(row=tr, column=c).alignment = CEN
    cp.freeze_panes = "A5"
    return items  # return for pricing-sources sheet


def _render_pricing_sources(wb, pricing):
    ps = wb.create_sheet("Pricing Sources")
    ps.sheet_view.showGridLines = False
    _widths(ps, [4,22,9,18,12,18,12,18,12,10,50])
    _banner(ps, 2, 11, "PRICING SOURCES — Vendor Lookups", hexfill="375623", h=30)
    ps.merge_cells("B3:K3")
    ps.cell(row=3, column=2, value="Published list price where available; specialty/MIL-spec items require RFQ. 'EST' = typical-range estimate, not binding.").font = SMALL
    ps.cell(row=3, column=2).alignment = CEN
    heads = ["#","Part Number","UoM","Vendor 1","V1 Price","Vendor 2","V2 Price","Vendor 3","V3 Price","Lead (wk)","URL / Notes"]
    for i, hd in enumerate(heads, start=2): ps.cell(row=5, column=i, value=hd)
    _hdr(ps, 5, 11, "375623"); ps.row_dimensions[5].height = 32
    rows = sorted(pricing.items(), key=lambda kv: kv[0])
    for i, (pn, d) in enumerate(rows):
        rr = 6 + i
        ps.cell(row=rr, column=2, value=i+1)
        ps.cell(row=rr, column=3, value=pn)
        ps.cell(row=rr, column=4, value=d.get("uom"))
        ps.cell(row=rr, column=5, value=d.get("v1_name",""))
        ps.cell(row=rr, column=6, value=d.get("v1_price"))
        ps.cell(row=rr, column=7, value=d.get("v2_name",""))
        ps.cell(row=rr, column=8, value=d.get("v2_price"))
        ps.cell(row=rr, column=9, value=d.get("v3_name",""))
        ps.cell(row=rr, column=10, value=d.get("v3_price"))
        ps.cell(row=rr, column=11, value=d.get("lead_wk"))
        # PATCHED (Phase 1): d.get("v1_url","") returns None when the key exists
        # with a None value, and the += below then raises TypeError. Any
        # estimate-only part with no URL killed the whole build.
        url_notes = d.get("v1_url") or ""
        if d.get("is_estimate"):
            url_notes += f"  [EST: ${d.get('estimate')} {d.get('uom')}]"
        url_notes += "  " + (d.get("notes") or "")
        ps.cell(row=rr, column=12, value=url_notes)
        for c in (2,3,4,11): ps.cell(row=rr, column=c).alignment = CEN
        for c in (6,8,10):
            ps.cell(row=rr, column=c).number_format = MONEY4; ps.cell(row=rr, column=c).alignment = CEN
        for c in range(2, 13):
            ps.cell(row=rr, column=c).border = BORDER
            if not ps.cell(row=rr, column=c).font or ps.cell(row=rr, column=c).font.name != FONT:
                ps.cell(row=rr, column=c).font = BODY
        if i % 2 == 1:
            for c in range(2, 13): ps.cell(row=rr, column=c).fill = LIGHT_GRAY
        ps.cell(row=rr, column=12).alignment = LT
        ps.row_dimensions[rr].height = 34
    ps.freeze_panes = "B6"


def _render_cover(wb, program, harnesses, quantities, pricing):
    cov = wb.create_sheet("Cover", 0)
    cov.sheet_view.showGridLines = False
    _widths(cov, [4,28,28,28,28,4])
    _banner(cov, 2, 5, program.get("title","Harness Program"), hexfill=NAVY, font=TITLE, h=30)
    cov.merge_cells("B3:E3")
    cov.cell(row=3, column=2, value=program.get("subtitle","")).font = SMALL
    cov.cell(row=3, column=2).alignment = CEN
    # tiles
    set_terms = sum(sum(t[2] for t in h.get("terminations", [])) for h in harnesses)
    set_wires = sum(len(h.get("wires", [])) for h in harnesses)
    set_labor = sum(h.get("labor_hr",0) for h in harnesses)
    q1, q2 = quantities
    tiles = [
        ("Harnesses per Set", len(harnesses)),
        ("Terminations per Set", set_terms),
        ("Wires per Set", set_wires),
        ("Labor hr per Set", round(set_labor,1)),
        (f"Terminations — Lot {q1}", set_terms*q1),
        (f"Terminations — Lot {q2}", set_terms*q2),
        (f"Labor hr — Lot {q1}", round(set_labor*q1*0.65)),
        (f"Labor hr — Lot {q2}", round(set_labor*q2*0.58)),
    ]
    r = 5
    for i, (k, v) in enumerate(tiles):
        row = r + (i//2)*2; col = 2 + (i%2)*2
        cov.cell(row=row, column=col, value=k).font = F(10, True, "FFFFFF")
        cov.cell(row=row, column=col).fill = fill("2E5597")
        cov.cell(row=row, column=col).alignment = CEN; cov.cell(row=row, column=col).border = BORDER
        cov.merge_cells(start_row=row, start_column=col, end_row=row, end_column=col+1)
        cov.cell(row=row+1, column=col, value=v).font = F(18, True, NAVY)
        cov.cell(row=row+1, column=col).alignment = CEN; cov.cell(row=row+1, column=col).border = BORDER
        cov.cell(row=row+1, column=col).fill = LIGHT_BLUE
        cov.merge_cells(start_row=row+1, start_column=col, end_row=row+1, end_column=col+1)
        cov.row_dimensions[row+1].height = 28
    r = r + (len(tiles)//2)*2 + 2
    _banner(cov, r, 5, "WORKBOOK CONTENTS", hexfill=NAVY, font=H1, h=22); r += 1
    contents = [(h["name"], "; ".join(f"{lbl}: {val}" for lbl, val in h.get("meta", [])[:2])) for h in harnesses]
    contents.append(("Combined Parts", "All components merged across harnesses with per-harness counts and lot totals"))
    if pricing: contents.append(("Pricing Sources", "Vendor lookups with URLs and lead times"))
    contents.append(("Assumptions & Sources", "Standards, quantity/labor/scrap assumptions, open items, sources"))
    for k, v in contents:
        cov.cell(row=r, column=2, value=k).font = BOLD
        cov.cell(row=r, column=2).fill = LIGHT_BLUE; cov.cell(row=r, column=2).alignment = LF
        cov.cell(row=r, column=2).border = BORDER
        cov.merge_cells(start_row=r, start_column=3, end_row=r, end_column=5)
        cov.cell(row=r, column=3, value=v).font = BODY; cov.cell(row=r, column=3).alignment = LF
        cov.cell(row=r, column=3).border = BORDER
        r += 1


def _default_assumptions(program, harnesses):
    names = ", ".join(h["name"] for h in harnesses)
    return [
        ("1.  SOURCE & STANDARD", [
            ("Program", program.get("title","") + " — " + program.get("subtitle","")),
            ("Standard", program.get("standard","IPC/WHMA-A-620 Class 3") + " applied to crimp criteria, solder sleeves, inspection, and pull-test sampling."),
            ("Harnesses", names),
            ("Crimp standard", "All crimps per AS22520 with calibrated dies; weekly GO/NO-GO verification."),
        ]),
        ("2.  QUANTITY & LABOR", [
            ("Quantities", "Scaled to " + " and ".join(str(q) for q in program.get("quantities",[50,100])) + " units."),
            ("Contacts", "All socket/pin contacts ordered separately (used positions + spares)."),
            ("Learning curve", "90% curve; avg factor 0.65 for the smaller lot, 0.58 for the larger."),
            ("Labor", program.get("labor_plan","2 technicians, 8 hr shift") + "; ~7.0 productive hr/shift."),
            ("Scrap", "3% shells, 5% D-subs, 10% cable/wire/lugs, 15% contacts, 20% labels/consumables, 25% solder sleeves/spares."),
        ]),
        ("3.  OPEN ITEMS — CONFIRM BEFORE BID/PRODUCTION", [
            ("Contact size/gender", "Verify M39029 dash number matches connector insert size; D-sub plug needs socket contacts."),
            ("Connector contacts", "Confirm whether circular connectors ship pre-loaded or need separate contacts."),
            ("Vendor-selected wire", "Where a drawing defers wire to vendor, confirm the MIL-DTL-22759 equivalent chosen."),
            ("Drawing vs. datasheet", "Reconcile any AWG/shield callouts that disagree with named-part specs."),
        ]),
    ]


def _render_assumptions(wb, program, harnesses):
    ws = wb.create_sheet("Assumptions & Sources")
    ws.sheet_view.showGridLines = False
    _widths(ws, [4,28,78,4])
    _banner(ws, 2, 3, "ASSUMPTIONS, STANDARDS & SOURCES", hexfill=NAVY, font=TITLE, h=30)
    ws.merge_cells("B3:C3")
    ws.cell(row=3, column=2, value=program.get("subtitle","")).font = SMALL
    ws.cell(row=3, column=2).alignment = CEN
    sections = program.get("assumptions") or _default_assumptions(program, harnesses)
    r = 5
    for title, entries in sections:
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=3)
        c = ws.cell(row=r, column=2, value=title); c.font = H1; c.fill = fill(NAVY); c.alignment = CEN
        ws.row_dimensions[r].height = 24; r += 1
        for label, body in entries:
            ws.cell(row=r, column=2, value=label).font = BOLD
            ws.cell(row=r, column=2).fill = LIGHT_BLUE
            ws.cell(row=r, column=2).alignment = LT; ws.cell(row=r, column=2).border = BORDER
            ws.cell(row=r, column=3, value=body).font = BODY
            ws.cell(row=r, column=3).alignment = LT; ws.cell(row=r, column=3).border = BORDER
            ws.row_dimensions[r].height = 46; r += 1
        r += 1
    ws.freeze_panes = "A4"


def build_workbook(out_path, program, harnesses, pricing=None, include_assumptions=True):
    quantities = program.get("quantities", [50, 100])
    if len(quantities) != 2:
        raise ValueError("program['quantities'] must be exactly two lot sizes, e.g. [50, 100]")
    wb = Workbook(); wb.remove(wb.active)
    for h in harnesses:
        _render_harness(wb, h, quantities)
    _render_combined(wb, harnesses, quantities, pricing)
    if pricing:
        _render_pricing_sources(wb, pricing)
    if include_assumptions:
        _render_assumptions(wb, program, harnesses)
    _render_cover(wb, program, harnesses, quantities, pricing)
    wb.save(out_path)
    return out_path


if __name__ == "__main__":
    # Minimal smoke test
    program = {
        "title": "Demo Program", "subtitle": "Smoke test", "standard": "IPC/WHMA-A-620 Class 3",
        "quantities": [50, 100], "labor_plan": "2 techs",
    }
    harnesses = [{
        "name": "J1 Harness", "accent": "blue",
        "meta": [("Drawing Number", "DEMO-001"), ("Revision", "--")],
        "parts": [("Connector","P1","MS27473E16F99S","Amphenol","Circular plug","EA",1,3),
                  ("Wire","W","M22759/32-18-9","TE","18 AWG","IN",324,10)],
        "wires": [("W01","Sig","18","BLK","M22759","P1","A","END B","1","Socket","D-Sub")],
        "terminations": [("Socket sz20","P1",19,"AFM8","2-08")],
        "labor_hr": 5.5,
    }]
    build_workbook("/tmp/demo_bom.xlsx", program, harnesses, pricing=None)
    print("Wrote /tmp/demo_bom.xlsx")
