"""
main.py — Flask app. Runs on the technician's own machine; opens in her browser.

Flask rather than FastAPI (the runbook's first sketch): fewer dependencies to
bundle into a Windows installer, synchronous request handling that matches a
single-user desktop tool, and templates a non-developer can read and edit.
"""
import os
import io
import csv
import json
import datetime

from flask import (Flask, render_template, request, redirect, url_for,
                   flash, send_file, abort, g)

import time

from . import (db, labor, issues as issues_mod, exporter, scanner, version,
               extract, llm, pricing, offline, ocr, batch as batch_mod,
               render as render_mod, tools, updates, pricelist, usage)

app = Flask(__name__)
app.secret_key = os.environ.get("HARNESSBOM_SECRET", "local-desktop-app")
app.jinja_env.globals.update(CATEGORIES=db.CATEGORIES, APP_VERSION=version.VERSION)

# Checked once per process, never per request, and only when the user has opted
# in with HARNESSBOM_CHECK_UPDATES=1. Returns None on any failure.
_UPDATE = {"at": 0.0, "info": None}


@app.context_processor
def inject_update():
    """
    What the bar at the top shows.

    Checked once an hour rather than once per process, because the program is
    left open all day and a fix pushed at ten should not wait for someone to
    restart. Nothing is ever applied here - this only looks.
    """
    now = time.time()
    if now - _UPDATE["at"] > 3600:
        _UPDATE["at"] = now
        _UPDATE["info"] = updates.check()
    return {"update": _UPDATE["info"], "upd": updates.state()}


def get_db():
    if "db" not in g:
        g.db = db.init()
        # Re-checked on every request rather than at startup, so a drawing that
        # turns a project controlled locks the program on the next page load
        # instead of at the next restart.
        offline.sync(g.db)
    return g.db


@app.context_processor
def inject_offline():
    return {"offline_on": offline.engaged(), "offline_why": offline.status().get("why", "")}


@app.context_processor
def inject_readers():
    """So a screen can warn BEFORE someone ticks a box that will do nothing.
    Both checks are a file test on a hit and cheap on a miss."""
    return {"renderer_ready": render_mod.available(), "ocr_ready": bool(ocr.tool("tesseract"))}


@app.teardown_appcontext
def close_db(_exc):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def export_dir():
    d = os.environ.get("HARNESSBOM_EXPORTS") or os.path.join(db.data_dir(), "exports")
    os.makedirs(d, exist_ok=True)
    return d


def one(conn, sql, args):
    row = conn.execute(sql, args).fetchone()
    if row is None:
        abort(404)
    return row


# ---------------------------------------------------------------------------
# Projects
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    conn = get_db()
    projects = conn.execute(
        "SELECT p.*,"
        " (SELECT COUNT(*) FROM grp WHERE project_id = p.id) AS n_groups,"
        " (SELECT COUNT(*) FROM harness h JOIN grp g ON g.id = h.group_id"
        "   WHERE g.project_id = p.id) AS n_harnesses,"
        " (SELECT COUNT(*) FROM issue WHERE project_id = p.id AND resolved = 0"
        "   AND severity = 'high') AS n_high"
        " FROM project p WHERE COALESCE(p.archived_at,'') = ''"
        " ORDER BY p.created_at DESC").fetchall()
    n_archived = conn.execute(
        "SELECT COUNT(*) AS n FROM project WHERE COALESCE(archived_at,'') <> ''"
    ).fetchone()["n"]
    return render_template("projects.html", projects=projects, n_archived=n_archived,
                           archived=False)


@app.post("/project/new")
def project_new():
    conn = get_db()
    name = (request.form.get("name") or "").strip()
    if not name:
        flash("A project needs a name.", "error")
        return redirect(url_for("index"))
    try:
        cur = conn.execute(
            "INSERT INTO project (name, customer, rfp_number, cage_code, classification,"
            " include_pricing, qty_low, qty_high, created_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (name, request.form.get("customer", "").strip(),
             request.form.get("rfp_number", "").strip(),
             request.form.get("cage_code", "").strip(), "review", 1,
             max(1, request.form.get("qty_low", type=int) or 1),
             max(1, request.form.get("qty_high", type=int) or 5), db.now()))
    except Exception:
        flash(f"A project called {name!r} already exists.", "error")
        return redirect(url_for("index"))
    pid = cur.lastrowid
    conn.execute("INSERT INTO grp (project_id, name, sort_order, created_at) VALUES (?,?,?,?)",
                 (pid, "Group 1", 0, db.now()))
    db.log(conn, "project_create", name)
    conn.commit()
    return redirect(url_for("project", pid=pid))


@app.route("/project/<int:pid>")
def project(pid):
    conn = get_db()
    p = one(conn, "SELECT * FROM project WHERE id = ?", (pid,))
    groups = conn.execute("SELECT * FROM grp WHERE project_id = ? ORDER BY sort_order, id",
                          (pid,)).fetchall()
    data, totals = [], {"harnesses": 0, "conductors": 0, "terminations": 0, "hours": 0.0}
    for grp in groups:
        rows = conn.execute("SELECT * FROM harness WHERE group_id = ? ORDER BY sort_order, id",
                            (grp["id"],)).fetchall()
        hs = []
        for h in rows:
            s = labor.harness_summary(conn, h["id"])
            hs.append({"row": h, "s": s})
            totals["harnesses"] += 1
            totals["conductors"] += s["conductor_count"]
            totals["terminations"] += s["termination_count"]
            totals["hours"] += s["first_unit_hr"]
        data.append({"grp": grp, "harnesses": hs})
    totals["hours"] = round(totals["hours"], 2)

    rates = db.rates(conn)
    lot_lo = labor.lot_labor(rates, totals["hours"], int(p["qty_low"]))
    lot_hi = labor.lot_labor(rates, totals["hours"], int(p["qty_high"]))
    sched = labor.schedule(rates, lot_hi)
    open_issues = conn.execute(
        "SELECT * FROM issue WHERE project_id = ? AND resolved = 0 ORDER BY"
        " CASE severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, id",
        (pid,)).fetchall()
    return render_template("project.html", p=p, data=data, totals=totals,
                           lot_lo=lot_lo, lot_hi=lot_hi, sched=sched,
                           issues=open_issues, rates=rates,
                           model_missing=llm.missing_for(p["classification"]),
                           pricing_ready=pricing.any_configured(),
                           pricing_providers=[n for n, k in
                                              (("DigiKey", "digikey"),
                                               ("Octopart", "nexar"))
                                              if pricing.configured(k)])


@app.post("/project/<int:pid>/settings")
def project_settings(pid):
    conn = get_db()
    one(conn, "SELECT id FROM project WHERE id = ?", (pid,))
    f = request.form
    conn.execute(
        "UPDATE project SET customer=?, rfp_number=?, cage_code=?, standard=?, labor_plan=?,"
        " qty_low=?, qty_high=?, bom_scope=?, include_pricing=? WHERE id=?",
        (f.get("customer", ""), f.get("rfp_number", ""), f.get("cage_code", ""),
         f.get("standard", ""), f.get("labor_plan", ""),
         int(f.get("qty_low") or 1), int(f.get("qty_high") or 5),
         f.get("bom_scope", "parts_consumables"),
         1 if f.get("include_pricing") else 0, pid))
    db.log(conn, "project_settings", str(pid))
    conn.commit()
    flash("Project settings saved.", "ok")
    return redirect(url_for("project", pid=pid))


@app.post("/project/<int:pid>/classify")
def project_classify(pid):
    """
    Clear a REVIEW classification. A CONTROLLED classification cannot be cleared
    here — that is the whole point of the two-tier gate.
    """
    conn = get_db()
    p = one(conn, "SELECT * FROM project WHERE id = ?", (pid,))
    target = request.form.get("classification", "review")
    reviewer = (request.form.get("reviewer") or "").strip()
    if p["classification"] == "controlled":
        flash("This project is EXPORT CONTROLLED. That determination cannot be cleared in the app.",
              "error")
        return redirect(url_for("project", pid=pid))
    if target == "unclassified" and not reviewer:
        flash("Clearing a marking requires a named reviewer.", "error")
        return redirect(url_for("project", pid=pid))
    note = (f"Cleared by {reviewer} on {db.now()}" if target == "unclassified"
            else request.form.get("class_note", ""))
    conn.execute("UPDATE project SET classification=?, class_note=? WHERE id=?",
                 (target, note, pid))
    db.log(conn, "classification_change", p["name"], f"{p['classification']} -> {target}. {note}")
    conn.commit()
    flash(f"Classification set to {target.upper()}.", "ok")
    return redirect(url_for("project", pid=pid))


# ---------------------------------------------------------------------------
# Groups & harnesses
# ---------------------------------------------------------------------------
@app.post("/project/<int:pid>/group/new")
def group_new(pid):
    conn = get_db()
    n = conn.execute("SELECT COUNT(*) AS n FROM grp WHERE project_id = ?", (pid,)).fetchone()["n"]
    conn.execute("INSERT INTO grp (project_id, name, sort_order, created_at) VALUES (?,?,?,?)",
                 (pid, (request.form.get("name") or f"Group {n + 1}").strip(), n, db.now()))
    conn.commit()
    return redirect(url_for("project", pid=pid))


@app.post("/group/<int:gid>/harness/new")
def harness_new(gid):
    conn = get_db()
    grp = one(conn, "SELECT * FROM grp WHERE id = ?", (gid,))
    n = conn.execute("SELECT COUNT(*) AS n FROM harness WHERE group_id = ?", (gid,)).fetchone()["n"]
    f = request.form
    cur = conn.execute(
        "INSERT INTO harness (group_id, name, drawing_no, revision, title, sort_order, created_at)"
        " VALUES (?,?,?,?,?,?,?)",
        (gid, (f.get("name") or f"Harness {n + 1}").strip(), f.get("drawing_no", "").strip(),
         f.get("revision", "").strip(), f.get("title", "").strip(), n, db.now()))
    conn.commit()
    return redirect(url_for("harness", hid=cur.lastrowid))


@app.route("/harness/<int:hid>")
def harness(hid):
    conn = get_db()
    h = one(conn, "SELECT * FROM harness WHERE id = ?", (hid,))
    grp = one(conn, "SELECT * FROM grp WHERE id = ?", (h["group_id"],))
    p = one(conn, "SELECT * FROM project WHERE id = ?", (grp["project_id"],))
    s = labor.harness_summary(conn, hid)
    prices = {r["pn"]: r for r in conn.execute(
        "SELECT pn, last_price, last_source, is_estimate, lead_wk FROM partsmaster"
        " WHERE pn IN (SELECT pn FROM part WHERE harness_id = ?)", (hid,))}
    return render_template(
        "harness.html", h=h, grp=grp, p=p, s=s, prices=prices,
        # what is actually stopping a pin-map read, in words, or "" if nothing is
        vision_missing=llm.missing_for(p["classification"]),
        ocr_ready=ocr.available(),
        ocr_missing=("" if ocr.available() else ocr.MISSING),
        pricing_ready=pricing.any_configured())


@app.post("/harness/<int:hid>/meta")
def harness_meta(hid):
    conn = get_db()
    one(conn, "SELECT id FROM harness WHERE id = ?", (hid,))
    f = request.form
    conn.execute(
        "UPDATE harness SET name=?, drawing_no=?, revision=?, title=?, dwg_date=?, author=?,"
        " sheets=?, notes=? WHERE id=?",
        (f.get("name", ""), f.get("drawing_no", ""), f.get("revision", ""), f.get("title", ""),
         f.get("dwg_date", ""), f.get("author", ""), int(f.get("sheets") or 1),
         f.get("notes", ""), hid))
    conn.commit()
    flash("Drawing details saved.", "ok")
    return redirect(url_for("harness", hid=hid))


@app.post("/harness/<int:hid>/part/add")
def part_add(hid):
    conn = get_db()
    one(conn, "SELECT id FROM harness WHERE id = ?", (hid,))
    f = request.form
    pn = (f.get("pn") or "").strip().upper()
    if not pn:
        flash("A part line needs a part number.", "error")
        return redirect(url_for("harness", hid=hid))
    category = f.get("category") or "Connector"
    mfg, desc, uom = f.get("mfg", "").strip(), f.get("description", "").strip(), f.get("uom", "EA").strip()

    # parts master fills the blanks from what we already know about this PN
    known = db.master_lookup(conn, pn)
    if known:
        mfg = mfg or known["mfg"] or ""
        desc = desc or known["description"] or ""
        uom = uom or known["uom"] or "EA"

    scrap = f.get("scrap_pct")
    scrap = float(scrap) if scrap not in (None, "") else db.scrap_for(conn, category)
    n = conn.execute("SELECT COUNT(*) AS n FROM part WHERE harness_id = ?", (hid,)).fetchone()["n"]
    conn.execute(
        "INSERT INTO part (harness_id, category, tag, pn, mfg, description, uom, qty, scrap_pct, sort_order)"
        " VALUES (?,?,?,?,?,?,?,?,?,?)",
        (hid, category, f.get("tag", "").strip(), pn, mfg, desc, uom,
         float(f.get("qty") or 1), scrap, n))
    db.remember_part(conn, pn, mfg, desc, uom, category)
    conn.commit()
    return redirect(url_for("harness", hid=hid))


@app.post("/part/<int:part_id>/delete")
def part_delete(part_id):
    conn = get_db()
    row = one(conn, "SELECT harness_id FROM part WHERE id = ?", (part_id,))
    conn.execute("DELETE FROM part WHERE id = ?", (part_id,))
    conn.commit()
    return redirect(url_for("harness", hid=row["harness_id"]))


@app.post("/harness/<int:hid>/wire/add")
def wire_add(hid):
    conn = get_db()
    one(conn, "SELECT id FROM harness WHERE id = ?", (hid,))
    f = request.form
    nxt = conn.execute("SELECT COALESCE(MAX(wire_no), 0) + 1 AS n FROM wire WHERE harness_id = ?",
                       (hid,)).fetchone()["n"]
    conn.execute(
        "INSERT INTO wire (harness_id, wire_no, signal, awg, color, cable, run_ref, from_end,"
        " from_pin, to_end, to_pin, term_source, term_dest) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (hid, int(f.get("wire_no") or nxt), f.get("signal", "").strip(), f.get("awg", "").strip(),
         f.get("color", "-").strip() or "-", f.get("cable", "").strip(),
         f.get("run_ref", "").strip(),
         f.get("from_end", "").strip(), f.get("from_pin", "").strip(),
         f.get("to_end", "").strip(), f.get("to_pin", "").strip(),
         f.get("term_source", "").strip(), f.get("term_dest", "").strip()))
    conn.commit()
    return redirect(url_for("harness", hid=hid))


@app.post("/wire/<int:wire_id>/delete")
def wire_delete(wire_id):
    conn = get_db()
    row = one(conn, "SELECT harness_id FROM wire WHERE id = ?", (wire_id,))
    conn.execute("DELETE FROM wire WHERE id = ?", (wire_id,))
    conn.commit()
    return redirect(url_for("harness", hid=row["harness_id"]))


@app.post("/harness/<int:hid>/term/add")
def term_add(hid):
    conn = get_db()
    one(conn, "SELECT id FROM harness WHERE id = ?", (hid,))
    f = request.form
    conn.execute(
        "INSERT INTO termination (harness_id, term_type, location, qty, tool, die)"
        " VALUES (?,?,?,?,?,?)",
        (hid, f.get("term_type", "").strip() or "Crimp", f.get("location", "").strip(),
         int(f.get("qty") or 0), f.get("tool", "").strip(), f.get("die", "").strip()))
    conn.commit()
    return redirect(url_for("harness", hid=hid))


@app.post("/term/<int:term_id>/delete")
def term_delete(term_id):
    conn = get_db()
    row = one(conn, "SELECT harness_id FROM termination WHERE id = ?", (term_id,))
    conn.execute("DELETE FROM termination WHERE id = ?", (term_id,))
    conn.commit()
    return redirect(url_for("harness", hid=row["harness_id"]))


@app.post("/harness/<int:hid>/terms/auto")
def terms_auto(hid):
    """Derive the termination table from the wire list: one per conductor end."""
    conn = get_db()
    one(conn, "SELECT id FROM harness WHERE id = ?", (hid,))
    wires = conn.execute("SELECT * FROM wire WHERE harness_id = ?", (hid,)).fetchall()
    if not wires:
        flash("No wire list to derive terminations from.", "error")
        return redirect(url_for("harness", hid=hid))
    tally = {}
    for w in wires:
        for end, term in ((w["from_end"], w["term_source"]), (w["to_end"], w["term_dest"])):
            end = (end or "").strip() or "unspecified"
            term = (term or "").strip() or "Crimp contact"
            tally[(term, end)] = tally.get((term, end), 0) + 1
    conn.execute("DELETE FROM termination WHERE harness_id = ?", (hid,))
    for (term, end), qty in sorted(tally.items()):
        conn.execute(
            "INSERT INTO termination (harness_id, term_type, location, qty, tool, die)"
            " VALUES (?,?,?,?,?,?)", (hid, term, end, qty, "", ""))
    db.log(conn, "terms_auto", f"harness {hid}", f"{len(tally)} rows")
    conn.commit()
    flash(f"Derived {sum(tally.values())} terminations from {len(wires)} conductors. "
          f"Add shield terminations and cap-and-stow lines by hand.", "ok")
    return redirect(url_for("harness", hid=hid))


# ---------------------------------------------------------------------------
# Issues, rates, exports
# ---------------------------------------------------------------------------
@app.post("/project/<int:pid>/issues/refresh")
def issues_refresh(pid):
    conn = get_db()
    rows = issues_mod.refresh(conn, pid)
    flash(f"Ran the drawing checks: {len(rows)} open item(s).", "ok")
    return redirect(url_for("project", pid=pid))


@app.post("/issue/<int:iid>/resolve")
def issue_resolve(iid):
    conn = get_db()
    row = one(conn, "SELECT project_id FROM issue WHERE id = ?", (iid,))
    conn.execute("UPDATE issue SET resolved = 1 WHERE id = ?", (iid,))
    conn.commit()
    return redirect(url_for("project", pid=row["project_id"]))


@app.route("/rates", methods=["GET", "POST"])
def rates_page():
    conn = get_db()
    if request.method == "POST":
        for key, val in request.form.items():
            if key.startswith("rate__"):
                try:
                    conn.execute("UPDATE rate SET value = ? WHERE key = ?",
                                 (float(val), key[6:]))
                except ValueError:
                    pass
        db.log(conn, "rates_update")
        conn.commit()
        flash("Rates saved. New exports use them immediately.", "ok")
        return redirect(url_for("rates_page"))
    groups = {}
    for r in conn.execute("SELECT * FROM rate ORDER BY grp, key"):
        groups.setdefault(r["grp"], []).append(r)
    return render_template("rates.html", groups=groups)


@app.route("/parts")
def parts_master():
    conn = get_db()
    q = (request.args.get("q") or "").strip().upper()
    if q:
        rows = conn.execute(
            "SELECT * FROM partsmaster WHERE pn LIKE ? OR description LIKE ?"
            " ORDER BY pn", (f"%{q}%", f"%{q}%")).fetchall()
    else:
        rows = conn.execute("SELECT * FROM partsmaster ORDER BY times_seen DESC, pn"
                            " LIMIT 400").fetchall()
    return render_template("parts.html", rows=rows, q=q)


@app.post("/parts/<path:pn>/price")
def parts_price(pn):
    conn = get_db()
    f = request.form
    price = f.get("last_price")
    conn.execute(
        "UPDATE partsmaster SET last_price=?, last_source=?, last_url=?, lead_wk=?,"
        " is_estimate=?, notes=?, last_checked=? WHERE pn=?",
        (float(price) if price else None, f.get("last_source", ""), f.get("last_url", ""),
         int(f.get("lead_wk")) if f.get("lead_wk") else None,
         1 if f.get("is_estimate") else 0, f.get("notes", ""), db.now(), pn.upper()))
    db.log(conn, "price_update", pn)
    conn.commit()
    flash(f"Price saved for {pn}.", "ok")
    return redirect(url_for("parts_master", q=pn))


@app.post("/group/<int:gid>/export")
def export_group_route(gid):
    conn = get_db()
    try:
        res = exporter.export_group(conn, gid, export_dir())
    except Exception as exc:
        flash(f"Export failed: {exc}", "error")
        grp = conn.execute("SELECT project_id FROM grp WHERE id = ?", (gid,)).fetchone()
        return redirect(url_for("project", pid=grp["project_id"]))
    return send_file(res["path"], as_attachment=True,
                     download_name=os.path.basename(res["path"]))


@app.post("/harness/<int:hid>/export")
def export_harness_route(hid):
    conn = get_db()
    try:
        res = exporter.export_harness(conn, hid, export_dir())
    except Exception as exc:
        flash(f"Export failed: {exc}", "error")
        return redirect(url_for("harness", hid=hid))
    return send_file(res["path"], as_attachment=True,
                     download_name=os.path.basename(res["path"]))


@app.post("/project/<int:pid>/export")
def export_master_route(pid):
    conn = get_db()
    gids = [int(x) for x in request.form.getlist("group_id")] or None
    usage.record(conn, "quote exported")
    try:
        res = exporter.export_master(conn, pid, export_dir(), gids)
    except Exception as exc:
        flash(f"Export failed: {exc}", "error")
        return redirect(url_for("project", pid=pid))
    return send_file(res["path"], as_attachment=True,
                     download_name=os.path.basename(res["path"]))


@app.post("/project/<int:pid>/pricing")
def pricing_fetch(pid):
    """
    Price every distinct part number in the project from the distributor APIs.

    Deliberately a POST from a button and never automatic: it spends a metered
    quota and it puts part numbers on the wire, and both of those should happen
    because somebody asked.
    """
    conn = get_db()
    p = one(conn, "SELECT * FROM project WHERE id = ?", (pid,))
    qty = request.form.get("qty", type=int) or int(p["qty_high"] or 1)
    force = bool(request.form.get("force"))
    usage.record(conn, "prices fetched")
    try:
        rep = pricing.fetch_for_project(conn, p, qty=qty, force=force)
    except pricing.Refused as exc:
        flash(str(exc), "error")
        return redirect(url_for("project", pid=pid))
    except pricing.NotConfigured as exc:
        flash(str(exc), "warn")
        return redirect(url_for("settings_pricing"))
    except pricing.PricingError as exc:
        flash(str(exc), "error")
        return redirect(url_for("project", pid=pid))

    db.log(conn, "pricing_fetch", p["name"],
           f"{rep['priced']} priced, {rep['missed']} not found, {rep['cached']} already "
           f"priced, at qty {rep['qty']} via {', '.join(rep['providers']) or 'none'}")
    conn.commit()
    bits = [f"Priced {rep['priced']} of {rep['asked']} part numbers at quantity {rep['qty']}"]
    if rep["cached"]:
        bits.append(f"{rep['cached']} already had a recent price")
    if rep["missed"]:
        bits.append(f"{rep['missed']} not carried by either catalogue — those need a "
                    f"distributor quote or a hand-entered price")
    flash(". ".join(bits) + ".", "ok" if rep["priced"] else "warn")
    if rep["error"]:
        flash(rep["error"], "error")
    return redirect(url_for("project", pid=pid))


@app.route("/settings/pricing", methods=["GET", "POST"])
def settings_pricing():
    conn = get_db()
    if request.method == "POST":
        f = request.form
        saved = []
        if f.get("clear_digikey"):
            for n in ("digikey_client_id", "digikey_client_secret"):
                llm.set_secret(n, "")
            flash("DigiKey credentials removed.", "ok")
        if f.get("clear_nexar"):
            for n in ("nexar_client_id", "nexar_client_secret"):
                llm.set_secret(n, "")
            flash("Nexar credentials removed.", "ok")
        for name in ("digikey_client_id", "digikey_client_secret",
                     "nexar_client_id", "nexar_client_secret"):
            val = (f.get(name) or "").strip()
            if val:
                llm.set_secret(name, val)
                saved.append(name)
        if "digikey_env" in f:
            llm.set_secret("digikey_env", (f.get("digikey_env") or "production").strip())
        if saved:
            db.log(conn, "settings_pricing", "", f"stored {len(saved)} credential(s)")
            conn.commit()
            flash("Saved.", "ok")
        return redirect(url_for("settings_pricing"))
    return render_template(
        "pricing_settings.html",
        digikey=pricing.configured("digikey"),
        nexar=pricing.configured("nexar"),
        digikey_env=pricing.digikey_env())


@app.post("/group/<int:gid>/upload")
def group_upload(gid):
    """
    Several drawings at once. Each becomes a harness in this group.

    The quantities ride along on this form because this is where a person is
    thinking about the job - they used to live only at the foot of the project
    screen, which is why they read as missing.
    """
    conn = get_db()
    grp = one(conn, "SELECT * FROM grp WHERE id = ?", (gid,))
    files = [f for f in request.files.getlist("pdfs") if f and f.filename]
    if not files:
        flash("Choose one or more PDFs first.", "error")
        return redirect(url_for("project", pid=grp["project_id"]))

    lo = request.form.get("qty_low", type=int)
    hi = request.form.get("qty_high", type=int)
    if lo or hi:
        conn.execute("UPDATE project SET qty_low=?, qty_high=? WHERE id=?",
                     (max(1, lo or 1), max(1, hi or 1), grp["project_id"]))
        conn.commit()

    saved, rejected = [], []
    for fs in files:
        if not fs.filename.lower().endswith(".pdf"):
            rejected.append(fs.filename)
            continue
        safe = batch_mod.safe_name(fs.filename)
        path = os.path.join(batch_mod.drawings_dir(),
                            f"g{gid}_{datetime.datetime.now():%Y%m%d%H%M%S%f}_{safe}")
        fs.save(path)
        saved.append((safe, path))

    if rejected:
        flash("Not PDFs, so left out: " + ", ".join(rejected[:8]), "warn")
    if not saved:
        return redirect(url_for("project", pid=grp["project_id"]))

    usage.record(conn, "drawings read")
    bid = batch_mod.start(conn, gid, saved,
                          bool(request.form.get("read_drawing_image")),
                          bool(request.form.get("read_with_model")))
    return redirect(url_for("batch_page", bid=bid))


@app.route("/batch/<int:bid>")
def batch_page(bid):
    conn = get_db()
    data = batch_mod.summary(conn, bid)
    if not data:
        abort(404)
    return render_template("batch.html", **data)


@app.route("/network")
def network():
    conn = get_db()
    offline.sync(conn)
    st = offline.status()
    return render_template(
        "network.html", st=st,
        controlled=offline.controlled_count(conn),
        log=offline.recent(200),
        log_path=offline.log_path(),
        data_dir=db.data_dir(),
        exports=export_dir(),
        drawings=drawings_dir())


@app.post("/network/lock")
def network_lock():
    conn = get_db()
    offline.engage("locked by hand")
    db.log(conn, "offline_lock", "", "engaged by hand")
    conn.commit()
    flash("Offline lock ON. Nothing can leave this computer until you unlock it.", "ok")
    return redirect(url_for("network"))


@app.post("/network/unlock")
def network_unlock():
    """
    Unlocking takes one confirmed click, by Jeff's choice. It is still written to
    the audit log every time, because a record of who opened the door costs
    nothing to keep and is the first thing anyone will ask for afterwards.
    """
    conn = get_db()
    n = offline.controlled_count(conn)
    offline.release(why=f"released by hand with {n} controlled project(s) present")
    db.log(conn, "offline_unlock", "",
           f"released by hand; {n} controlled project(s) in the database")
    conn.commit()
    flash("Offline lock OFF for this session. It comes back on when you restart "
          "the program. Controlled projects are still refused the model and "
          "pricing regardless.", "warn")
    return redirect(url_for("network"))


@app.route("/audit")
def audit():
    conn = get_db()
    rows = conn.execute("SELECT * FROM audit ORDER BY id DESC LIMIT 500").fetchall()
    return render_template("audit.html", rows=rows)


@app.route("/healthz")
def healthz():
    return {"ok": True, "db": db.db_path(), "exports": export_dir()}


# ---------------------------------------------------------------------------
# Drawing extraction (Phase 2)
#
# Upload -> scan -> extract -> REVIEW -> apply. Nothing reaches the database
# until a person has looked at it. That review step is not ceremony: the text
# layer is reliable for parts and unreliable for pin maps, and the person
# quoting the job is the one who can tell the difference.
# ---------------------------------------------------------------------------
def drawings_dir():
    d = os.path.join(db.data_dir(), "drawings")
    os.makedirs(d, exist_ok=True)
    return d


@app.post("/harness/<int:hid>/upload")
def harness_upload(hid):
    conn = get_db()
    h = one(conn, "SELECT * FROM harness WHERE id = ?", (hid,))
    grp = one(conn, "SELECT * FROM grp WHERE id = ?", (h["group_id"],))
    p = one(conn, "SELECT * FROM project WHERE id = ?", (grp["project_id"],))

    fs = request.files.get("pdf")
    if not fs or not fs.filename:
        flash("Choose a PDF first.", "error")
        return redirect(url_for("harness", hid=hid))
    if not fs.filename.lower().endswith(".pdf"):
        flash("That is not a PDF.", "error")
        return redirect(url_for("harness", hid=hid))

    safe = "".join(c if (c.isalnum() or c in "-_. ") else "_" for c in fs.filename)
    path = os.path.join(drawings_dir(), f"{hid}_{datetime.datetime.now():%Y%m%d%H%M%S}_{safe}")
    fs.save(path)
    db.log(conn, "drawing_upload", f"harness {hid}", safe)

    want_vision = bool(request.form.get("read_pin_maps"))
    want_ocr = bool(request.form.get("read_drawing_image"))
    client, usage_note, vision_note = None, "", ""
    try:
        if want_vision:
            client = llm.Client(classification=p["classification"])
        res = extract.extract(path, allow_vision=bool(client), llm=client,
                              allow_ocr=want_ocr)
        if client:
            usage_note = client.cost_note()
    except llm.LaneViolation as exc:
        vision_note = str(exc)
        flash(str(exc), "error")
        res = extract.extract(path, allow_ocr=want_ocr)   # local tiers stay safe
    except llm.NotConfigured as exc:
        vision_note = str(exc)
        flash(str(exc), "warn")
        res = extract.extract(path, allow_ocr=want_ocr)
    except Exception as exc:
        # A model call can fail for reasons that are nobody's fault — the network
        # dropped, the key was revoked, the account hit its cap. None of that
        # should throw away a perfectly good free parts extraction.
        vision_note = (f"The pin-map pass failed: {exc}. The parts list below was "
                       f"still read from the text layer.")
        flash(vision_note, "error")
        res = extract.extract(path, allow_ocr=want_ocr)

    # the scanner's verdict governs the whole project, not just this drawing
    suggested = scanner.VERDICT_TO_CLASSIFICATION[res["scan"]["verdict"]]
    order = {"controlled": 2, "review": 1, "unclassified": 0}
    if order[suggested] > order[p["classification"]]:
        conn.execute("UPDATE project SET classification = ?, class_note = ? WHERE id = ?",
                     (suggested, f"Raised by the scanner on {safe} ({db.now()})", p["id"]))
        db.log(conn, "classification_change", p["name"],
               f"{p['classification']} -> {suggested} (scanner, {safe})")

    payload = {"meta": res["meta"], "parts": res["parts"], "wires": res["wires"],
               "notes": res["notes"], "scan": res["scan"], "blocked": res["blocked"],
               "pin_map_pages": res["pin_map_pages"],
               # so the review screen can say what actually happened, instead of
               # telling someone to tick a box they already ticked
               "vision_requested": want_vision,
               "vision_note": vision_note,
               "vision_missing": llm.missing_for(p["classification"]),
               "ocr_requested": want_ocr,
               "ocr_conf": res.get("ocr_conf", 0.0),
               "read_by_ocr": "ocr" in res["method"]}
    cur = conn.execute(
        "INSERT INTO extraction (harness_id, filename, pdf_path, verdict, method,"
        " payload, usage_note, created_at) VALUES (?,?,?,?,?,?,?,?)",
        (hid, safe, path, res["scan"]["verdict"], ",".join(res["method"]),
         json.dumps(payload), usage_note, db.now()))
    conn.commit()
    return redirect(url_for("review", eid=cur.lastrowid))


@app.route("/review/<int:eid>")
def review(eid):
    conn = get_db()
    e = one(conn, "SELECT * FROM extraction WHERE id = ?", (eid,))
    h = one(conn, "SELECT * FROM harness WHERE id = ?", (e["harness_id"],))
    grp = one(conn, "SELECT * FROM grp WHERE id = ?", (h["group_id"],))
    p = one(conn, "SELECT * FROM project WHERE id = ?", (grp["project_id"],))
    payload = json.loads(e["payload"])
    return render_template("review.html", e=e, h=h, p=p, payload=payload,
                           scan=payload["scan"], categories=db.CATEGORIES)


@app.post("/review/<int:eid>/apply")
def review_apply(eid):
    """Write the reviewed rows into the harness. Only ticked rows are applied."""
    conn = get_db()
    e = one(conn, "SELECT * FROM extraction WHERE id = ?", (eid,))
    hid = e["harness_id"]
    f = request.form

    if f.get("apply_meta"):
        conn.execute(
            "UPDATE harness SET drawing_no=?, revision=?, title=?, dwg_date=?,"
            " author=?, sheets=? WHERE id=?",
            (f.get("m_drawing_no", ""), f.get("m_revision", ""), f.get("m_title", ""),
             f.get("m_dwg_date", ""), f.get("m_author", ""),
             int(f.get("m_sheets") or 1), hid))

    if f.get("replace_parts"):
        conn.execute("DELETE FROM part WHERE harness_id = ?", (hid,))
    n_parts, skipped_qty = 0, []
    for idx in f.getlist("part_row"):
        if not f.get(f"p_keep_{idx}"):
            continue
        pn = (f.get(f"p_pn_{idx}") or "").strip().upper()
        if not pn:
            continue
        # A blank quantity used to become 0.0 silently. When the parts list came
        # off the drawing image, blank is the normal state of the QTY column and
        # 0 would go all the way into a quote as "we need none of these".
        raw_qty = (f.get(f"p_qty_{idx}") or "").strip()
        if raw_qty == "":
            skipped_qty.append(pn)
            continue
        cat = f.get(f"p_cat_{idx}") or "Connector"
        conn.execute(
            "INSERT INTO part (harness_id, category, tag, pn, mfg, description, uom,"
            " qty, scrap_pct, sort_order) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (hid, cat, f.get(f"p_item_{idx}", ""), pn, f.get(f"p_mfg_{idx}", ""),
             f.get(f"p_desc_{idx}", ""), f.get(f"p_uom_{idx}", "EA"),
             float(f.get(f"p_qty_{idx}") or 0), db.scrap_for(conn, cat), n_parts))
        db.remember_part(conn, pn, f.get(f"p_mfg_{idx}", ""),
                         f.get(f"p_desc_{idx}", ""), f.get(f"p_uom_{idx}", "EA"), cat)
        n_parts += 1

    if f.get("replace_wires"):
        conn.execute("DELETE FROM wire WHERE harness_id = ?", (hid,))
    n_wires = 0
    for idx in f.getlist("wire_row"):
        if not f.get(f"w_keep_{idx}"):
            continue
        n_wires += 1
        conn.execute(
            "INSERT INTO wire (harness_id, wire_no, signal, awg, color, cable, run_ref,"
            " from_end, from_pin, to_end, to_pin, term_source, term_dest)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (hid, n_wires, f.get(f"w_sig_{idx}", ""), f.get(f"w_awg_{idx}", ""), "-",
             (f.get(f"w_cable_{idx}") or "").strip().upper(), f.get(f"w_run_{idx}", ""),
             f.get(f"w_fe_{idx}", ""), f.get(f"w_fp_{idx}", ""),
             f.get(f"w_te_{idx}", ""), f.get(f"w_tp_{idx}", ""),
             f.get(f"w_ts_{idx}", ""), f.get(f"w_td_{idx}", "")))

    conn.execute("UPDATE extraction SET applied = 1 WHERE id = ?", (eid,))
    db.log(conn, "extraction_applied", f"harness {hid}",
           f"{n_parts} parts, {n_wires} conductors from {e['filename']}")
    conn.commit()
    flash(f"Applied {n_parts} part line(s) and {n_wires} conductor(s).", "ok")
    if skipped_qty:
        flash("Left out for having no quantity: " + ", ".join(skipped_qty[:12])
              + (f" and {len(skipped_qty) - 12} more" if len(skipped_qty) > 12 else "")
              + ". Add them on the harness screen with their quantities, or upload "
                "the drawing again and fill the quantities in on the review screen.",
              "warn")
    return redirect(url_for("harness", hid=hid))


@app.route("/projects/archived")
def projects_archived():
    conn = get_db()
    projects = conn.execute(
        "SELECT p.*,"
        " (SELECT COUNT(*) FROM grp WHERE project_id = p.id) AS n_groups,"
        " (SELECT COUNT(*) FROM harness h JOIN grp g ON g.id = h.group_id"
        "   WHERE g.project_id = p.id) AS n_harnesses,"
        " 0 AS n_high"
        " FROM project p WHERE COALESCE(p.archived_at,'') <> ''"
        " ORDER BY p.archived_at DESC").fetchall()
    return render_template("projects.html", projects=projects, archived=True, n_archived=0)


@app.post("/project/<int:pid>/archive")
def project_archive(pid):
    conn = get_db()
    p = one(conn, "SELECT * FROM project WHERE id = ?", (pid,))
    back = not (p["archived_at"] or "")
    db.set_archived(conn, pid, back)
    db.log(conn, "project_archived" if back else "project_restored", p["name"], "")
    conn.commit()
    flash(f"{p['name']} {'archived' if back else 'brought back'}.", "ok")
    return redirect(url_for("projects_archived" if back else "index"))


@app.post("/project/<int:pid>/delete")
def project_delete(pid):
    """
    Delete a project for good.

    Typing the name is the confirmation. A dialog box gets clicked through; a
    name has to be read off the screen, and on a tool where one of these holds
    forty hours of a quote that is the right amount of friction.
    """
    conn = get_db()
    p = one(conn, "SELECT * FROM project WHERE id = ?", (pid,))
    typed = (request.form.get("confirm") or "").strip()
    if typed != (p["name"] or "").strip():
        flash("That name does not match, so nothing was deleted. Type the project's "
              "name exactly as it appears.", "error")
        return redirect(url_for("project", pid=pid))
    res = db.delete_project(conn, pid, drawings=bool(request.form.get("drawings")))
    usage.record(conn, "project deleted")
    msg = (f"{res['name']} deleted — {res['harnesses']} harness(es)"
           + (f" and {res['files']} drawing file(s)" if res["files"] else "")
           + " removed.")
    if res["kept"]:
        msg += (" These files could not be removed and are still on the disk: "
                + ", ".join(res["kept"][:4]))
    flash(msg, "warn" if res["kept"] else "ok")
    return redirect(url_for("index"))


@app.route("/usage")
def usage_page():
    conn = get_db()
    usage.record(conn, "")
    return render_template("usage.html", st=usage.everyone(conn), windows=(os.name == "nt"))


@app.post("/usage/folder")
def usage_save():
    conn = get_db()
    usage.set_folder(conn, request.form.get("usage_dir") or "")
    db.log(conn, "usage_folder", "", (request.form.get("usage_dir") or "")[:200])
    conn.commit()
    where = usage.record(conn, "")
    flash(f"Saved. This copy writes to {where}." if where
          else "Saved. Reporting is off on this PC.", "ok")
    return redirect(url_for("usage_page"))


@app.route("/pricelist")
def pricelist_page():
    return render_template("pricelist.html", job=pricelist.job(),
                           preview=pricelist.staged().get("preview"),
                           ready=pricing.any_configured())


@app.post("/pricelist/upload")
def pricelist_upload():
    """
    Read the sheet and show what was found. Deliberately two steps: the column
    it picked is shown before a single lookup is spent, because a wrong column
    should cost two seconds rather than forty distributor calls.
    """
    fs = request.files.get("sheet")
    if not fs or not fs.filename:
        flash("Choose a spreadsheet first.", "error")
        return redirect(url_for("pricelist_page"))
    try:
        data = fs.read()
        rows = pricelist.read_table(data, fs.filename)
        cols = pricelist.find_columns(rows)
        entries = pricelist.collect(rows, cols)
    except pricelist.SheetError as exc:
        flash(str(exc), "error")
        return redirect(url_for("pricelist_page"))
    if not entries:
        flash("That sheet has a part-number column but no part numbers in it.", "error")
        return redirect(url_for("pricelist_page"))

    pricelist.stage(entries, os.path.splitext(fs.filename)[0][:60], {
        "how": cols["how"], "name": fs.filename,
        "total": len(entries),
        "unique": sum(1 for e in entries if not e.get("duplicate")),
        "sample": entries[:12],
        "has_qty": cols["qty"] is not None,
    })
    return redirect(url_for("pricelist_page"))


@app.post("/pricelist/run")
def pricelist_run():
    pending = pricelist.staged()
    entries = pending.get("entries") or []
    if not entries:
        flash("Upload the sheet again — the program was restarted since.", "error")
        return redirect(url_for("pricelist_page"))
    qty = request.form.get("qty", type=int) or 1
    why = pricelist.start(entries, qty=max(1, qty),
                          force=bool(request.form.get("force")),
                          name=pending.get("name") or "parts")
    if why:
        flash(why, "error")
    return redirect(url_for("pricelist_page"))


@app.route("/pricelist/download")
def pricelist_download():
    j = pricelist.job()
    if not j.get("path") or not os.path.exists(j["path"]):
        abort(404)
    return send_file(j["path"], as_attachment=True,
                     download_name=os.path.basename(j["path"]))


@app.route("/updates")
def updates_page():
    conn = get_db()
    return render_template("updates.html", st=updates.state(),
                           found=_UPDATE["info"] or {})


@app.post("/updates/check")
def updates_check():
    _UPDATE["at"] = time.time()
    _UPDATE["info"] = updates.check()
    if _UPDATE["info"]:
        flash(f"Version {_UPDATE['info']['version']} is available.", "ok")
    else:
        flash("Nothing newer. You are up to date.", "ok")
    return redirect(url_for("updates_page"))


@app.post("/updates/apply")
def updates_apply():
    """
    Apply a code pack, then stop. The program has to be restarted to pick it
    up, and restarting a running web server out from under the person reading
    this page is worse than asking them to reopen it.
    """
    conn = get_db()
    entry = _UPDATE["info"] or updates.check()
    if not entry:
        flash("There is nothing to install.", "error")
        return redirect(url_for("updates_page"))
    try:
        got = updates.apply(entry, conn)
    except updates.UpdateError as exc:
        flash(str(exc), "error")
        return redirect(url_for("updates_page"))
    updates.clear_failure()
    _UPDATE["info"] = None
    flash(f"Update {got} installed. Close the program and open it again to start using it.", "ok")
    return redirect(url_for("updates_page"))


@app.post("/updates/undo")
def updates_undo():
    conn = get_db()
    back = updates.undo(conn)
    updates.clear_failure()
    flash(f"Rolled back to {back or 'the version this program was installed with'}. "
          "Close the program and open it again.", "ok")
    return redirect(url_for("updates_page"))


@app.route("/readers")
def readers():
    """
    What can read a drawing on this machine, and a button that installs what
    cannot. This screen exists because the old message — two programs missing,
    reinstall or run brew — was a dead end for everyone it was shown to.
    """
    return render_template("readers.html", st=tools.status(),
                           routes=tools.routes(), job=tools.job())


@app.post("/readers/install")
def readers_install():
    conn = get_db()
    route = (request.form.get("route") or "").strip()
    why = tools.start(route)
    if why:
        flash(why, "error")
    else:
        db.log(conn, "readers_install", "", route)
        conn.commit()
    return redirect(url_for("readers"))


@app.route("/settings/extraction", methods=["GET", "POST"])
def settings_extraction():
    conn = get_db()
    if request.method == "POST":
        f = request.form
        where = None
        if f.get("clear_key"):
            llm.set_secret("anthropic_api_key", "")
            flash("Anthropic API key removed.", "ok")
        elif (f.get("anthropic_api_key") or "").strip():
            where = llm.set_secret("anthropic_api_key", f["anthropic_api_key"].strip())
        for name in ("bedrock_region", "bedrock_model_id", "model_id"):
            if name in f:
                llm.set_secret(name, (f.get(name) or "").strip())
        db.log(conn, "settings_extraction", "", f"stored in {where}" if where else "")
        conn.commit()
        if where:
            flash(f"Key saved to the {'OS keychain' if where == 'keychain' else 'local settings file'}.", "ok")
        return redirect(url_for("settings_extraction"))
    return render_template(
        "settings.html",
        lane_a=llm.is_configured(llm.LANE_A),
        lane_b=llm.is_configured(llm.LANE_B),
        model=llm.get_secret("model_id") or llm.DEFAULT_MODEL,
        bedrock_region=llm.get_secret("bedrock_region") or "",
        bedrock_model_id=llm.get_secret("bedrock_model_id") or "")
