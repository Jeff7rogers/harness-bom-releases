"""
exporter.py — turns database rows into workbooks.

Two exports:

    export_group(conn, group_id)      one group's harnesses -> one .xlsx
    export_master(conn, project_id)   every selected group merged -> one .xlsx

Both call the same engine (build_workbook.py, vendored from the skill). The
master is not a second format: it is the same builder handed every harness in
the project at once, which is what makes the Combined Parts tab merge across
groups that were built weeks apart by different people.
"""
import os
import datetime

from . import db, labor
from .build_workbook import build_workbook

ACCENTS = ["blue", "teal", "purple", "green"]


def _safe(name: str) -> str:
    keep = "-_. "
    out = "".join(c if (c.isalnum() or c in keep) else "_" for c in (name or "")).strip()
    return (out or "export").replace(" ", "_")


def _program(conn, project, harness_rows, scope_label):
    p = project
    bits = []
    if p["customer"]:
        bits.append(f"Customer: {p['customer']}")
    if p["rfp_number"]:
        bits.append(f"RFP {p['rfp_number']}")
    if p["cage_code"]:
        bits.append(f"CAGE {p['cage_code']}")
    bits.append(scope_label)
    if p["classification"] == "controlled":
        bits.append("EXPORT CONTROLLED — handle per DoD 5230.25")
    elif p["classification"] == "review":
        bits.append("Markings pending review")
    return {
        "title": p["name"],
        "subtitle": "  |  ".join(bits),
        "standard": p["standard"],
        "quantities": [int(p["qty_low"]), int(p["qty_high"])],
        "labor_plan": p["labor_plan"],
    }


def _harness_payload(conn, row, accent):
    s = labor.harness_summary(conn, row["id"])
    meta = [
        ("Drawing Number", row["drawing_no"] or "—"),
        ("Revision", row["revision"] or "—"),
        ("Date", row["dwg_date"] or "—"),
        ("Title", row["title"] or row["name"]),
        ("Author", row["author"] or "—"),
        ("Sheets", str(row["sheets"] or 1)),
        ("Conductors", str(s["conductor_count"])),
        ("Cable runs", str(s["cable_runs"])),
        ("Terminations", str(s["termination_count"])),
        ("Crimps", str(s["crimp_count"])),
    ]
    if row["notes"]:
        meta.append(("Notes", row["notes"]))

    parts = [(p["category"], p["tag"], p["pn"], p["mfg"], p["description"],
              p["uom"], p["qty"], p["scrap_pct"]) for p in s["parts"]]
    wires = [(w["wire_no"], w["signal"], w["awg"], w["color"], w["cable"],
              w["from_end"], w["from_pin"], w["to_end"], w["to_pin"],
              w["term_source"], w["term_dest"]) for w in s["wires"]]
    terms = [(t["term_type"], t["location"], t["qty"], t["tool"], t["die"])
             for t in s["terminations"]]

    return {
        "name": (row["drawing_no"] or row["name"])[:28],
        "accent": accent,
        "meta": meta,
        "parts": parts,
        "wires": wires,
        "terminations": terms,
        "labor_hr": s["first_unit_hr"],
    }, s


def _pricing(conn, project, harness_rows):
    """
    Build the pricing dict. None when pricing is off for the project.

    Prices come from the `quote` table where distributor lookups have put them —
    up to three sellers per part, cheapest first, which is what the workbook's
    three vendor columns are for. A part with no quote falls back to whatever is
    on the parts master, which is where hand-entered prices live.
    """
    if not int(project["include_pricing"] or 0):
        return None
    pns = set()
    for h in harness_rows:
        for p in conn.execute("SELECT pn FROM part WHERE harness_id = ?", (h["id"],)):
            pns.add((p["pn"] or "").strip().upper())

    out = {}
    for pn in sorted(pns):
        m = db.master_lookup(conn, pn)
        quotes = [q for q in db.quotes_for(conn, pn) if q["unit_price"] is not None][:3]

        if not quotes and (not m or m["last_price"] is None):
            continue

        est = bool(m["is_estimate"]) if (m and not quotes) else False
        row = {
            "uom": (m["uom"] if m else "EA") or "EA",
            "v1_name": "", "v1_price": None, "v1_url": "",
            "v2_name": "", "v2_price": None, "v2_url": "",
            "v3_name": "", "v3_price": None, "v3_url": "",
            "lead_wk": (m["lead_wk"] if m else None),
            "is_estimate": est,
            "estimate": (m["last_price"] if (est and m) else None),
            "notes": (m["notes"] if m else "") or "",
        }
        if quotes:
            notes = []
            for i, q in enumerate(quotes, start=1):
                row[f"v{i}_name"] = q["source"] or ""
                row[f"v{i}_price"] = q["unit_price"]
                row[f"v{i}_url"] = q["url"] or ""
                if q["break_qty"]:
                    notes.append(f"{q['source']} @ {int(q['break_qty'])}+")
                if q["lead_wk"] and not row["lead_wk"]:
                    row["lead_wk"] = q["lead_wk"]
            fetched = max((q["fetched_at"] or "") for q in quotes)[:10]
            notes.append(f"read {fetched}")
            row["notes"] = "; ".join(x for x in ([row["notes"]] + notes) if x)
        elif not est:
            # a hand-entered firm price
            row["v1_name"] = (m["last_source"] or "") if m else ""
            row["v1_price"] = m["last_price"] if m else None
            row["v1_url"] = (m["last_url"] or "") if m else ""
        out[pn] = row
    return out or None


def _assumptions(conn, project, harness_rows, summaries, scope_label):
    p = project
    rates = db.rates(conn)
    qty_hi = int(p["qty_high"])
    total_first_unit = sum(s["first_unit_hr"] for s in summaries)
    curve_on = float(rates.get("curve_enabled", 0)) >= 1.0
    lot_hi = labor.lot_labor(rates, total_first_unit, qty_hi)
    sched = labor.schedule(rates, lot_hi)

    cls_text = {
        "controlled": "EXPORT CONTROLLED. An affirmative export-control determination was found on at "
                      "least one drawing in this project. Handle and disseminate per DoD Directive "
                      "5230.25. This workbook inherits that control.",
        "review":     "MARKINGS PENDING REVIEW. A conditional export legend or a customer proprietary "
                      "marking was found. No determination appears on the face of the drawings. "
                      "A responsible person must clear this before the package is released.",
        "unclassified": "No export-control markings were found by the scanner. Absence of a marking is "
                        "not itself a determination — confirm against the contract.",
    }[p["classification"]]

    issues = conn.execute(
        "SELECT code, severity, category, message FROM issue"
        " WHERE project_id = ? AND resolved = 0 ORDER BY"
        " CASE severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, id",
        (p["id"],)).fetchall()

    blocks = [
        ("Export control & data handling", [
            ("Project classification", f"{p['classification'].upper()} — {cls_text}"),
            ("Reviewer note", p["class_note"] or "—"),
        ]),
        ("Quantities, standard and labor", [
            ("Build quantities", f"{int(p['qty_low'])} and {qty_hi} each."),
            ("Manufacturing standard", p["standard"]),
            ("Labor basis",
             ("Per-harness hours are FIRST-UNIT times built up from the editable cycle-time table. "
              + (f"A {rates.get('curve_rate', 0.9):.2f} learning curve IS applied to lot totals."
                 if curve_on else
                 "No learning-curve discount is applied — lot labor is first-unit hours times quantity, "
                 "which is deliberately conservative at low quantities."))),
            ("Labor plan", p["labor_plan"]),
            ("Schedule estimate",
             f"{sched['labor_hours']} labor-hours for the lot of {qty_hi} at "
             f"{sched['labor_hours_per_day']:.0f} hr/day = {sched['build_days']} production days "
             f"(~{sched['build_weeks']} weeks), plus {sched['procurement_weeks']} weeks procurement "
             f"on the critical path. Rough total {sched['total_weeks']} weeks."),
            ("Shop rate", f"${rates.get('shop_rate', 0):.2f}/hr (Settings → Rates)"),
        ]),
        ("BOM scope", [
            ("Scope", scope_label),
            ("Contacts",
             "Connectors whose part number encodes contact type (for example the P/S suffix on "
             "D38999) are treated as supplied WITH contacts, and no separate contact lines are "
             "added. Confirm with the supplier before ordering."),
            ("First article", "First-article build consumes roughly one additional harness set of "
                              "material beyond the lot. Not included above."),
        ]),
    ]

    if issues:
        blocks.append(("Open engineering questions",
                       [(f"{i['code'] or '—'}  [{i['severity']}] {i['category']}", i["message"])
                        for i in issues]))

    src = [(f"{h['drawing_no'] or h['name']} Rev {h['revision'] or '—'}",
            f"{h['title'] or h['name']}. {h['sheets'] or 1} sheet(s). "
            f"{h['dwg_date'] or 'date not recorded'}. {h['author'] or ''}".strip())
           for h in harness_rows]
    src.append(("Generated", f"Harness BOM tool, {datetime.datetime.now().strftime('%d %b %Y %H:%M')}"))
    blocks.append(("Source documents", src))
    return blocks


def _build(conn, project, harness_rows, out_path, scope_label):
    if not harness_rows:
        raise ValueError("Nothing to export — no harnesses in scope.")
    program = _program(conn, project, harness_rows, scope_label)
    payloads, summaries = [], []
    for i, row in enumerate(harness_rows):
        payload, summary = _harness_payload(conn, row, ACCENTS[i % len(ACCENTS)])
        payloads.append(payload)
        summaries.append(summary)
    program["assumptions"] = _assumptions(conn, project, harness_rows, summaries, scope_label)
    pricing = _pricing(conn, project, harness_rows)
    build_workbook(out_path, program, payloads, pricing=pricing, include_assumptions=True)
    return {
        "path": out_path,
        "harnesses": len(payloads),
        "terminations": sum(s["termination_count"] for s in summaries),
        "crimps": sum(s["crimp_count"] for s in summaries),
        "conductors": sum(s["conductor_count"] for s in summaries),
        "first_unit_hr": round(sum(s["first_unit_hr"] for s in summaries), 2),
        "priced": pricing is not None,
    }


def _harnesses_for_group(conn, group_id):
    return conn.execute(
        "SELECT * FROM harness WHERE group_id = ? ORDER BY sort_order, id", (group_id,)).fetchall()


def _harnesses_for_project(conn, project_id, group_ids=None):
    sql = ("SELECT h.* FROM harness h JOIN grp g ON g.id = h.group_id"
           " WHERE g.project_id = ?")
    args = [project_id]
    if group_ids:
        sql += " AND g.id IN (%s)" % ",".join("?" * len(group_ids))
        args += list(group_ids)
    sql += " ORDER BY g.sort_order, g.id, h.sort_order, h.id"
    return conn.execute(sql, args).fetchall()


def export_group(conn, group_id, out_dir):
    g = conn.execute("SELECT * FROM grp WHERE id = ?", (group_id,)).fetchone()
    p = conn.execute("SELECT * FROM project WHERE id = ?", (g["project_id"],)).fetchone()
    rows = _harnesses_for_group(conn, group_id)
    name = f"{_safe(p['name'])}__{_safe(g['name'])}_BOM.xlsx"
    out = os.path.join(out_dir, name)
    res = _build(conn, p, rows, out, f"Group: {g['name']}")
    db.log(conn, "export_group", f"{p['name']} / {g['name']}", out)
    conn.commit()
    return res


def export_harness(conn, harness_id, out_dir):
    """
    One harness -> one workbook.

    The same builder as a group export, handed a single harness. This exists
    because the natural moment to want a workbook is the moment a drawing has
    just been read and checked, and at that moment the person is looking at one
    harness, not at a group. Sending them back up two screens to find an export
    button is how a good workflow gets abandoned.
    """
    h = conn.execute("SELECT * FROM harness WHERE id = ?", (harness_id,)).fetchone()
    g = conn.execute("SELECT * FROM grp WHERE id = ?", (h["group_id"],)).fetchone()
    p = conn.execute("SELECT * FROM project WHERE id = ?", (g["project_id"],)).fetchone()
    label = h["drawing_no"] or h["name"]
    name = f"{_safe(p['name'])}__{_safe(label)}_BOM.xlsx"
    out = os.path.join(out_dir, name)
    res = _build(conn, p, [h], out, f"Single harness: {label}")
    db.log(conn, "export_harness", f"{p['name']} / {label}", out)
    conn.commit()
    return res


def export_master(conn, project_id, out_dir, group_ids=None):
    p = conn.execute("SELECT * FROM project WHERE id = ?", (project_id,)).fetchone()
    rows = _harnesses_for_project(conn, project_id, group_ids)
    name = f"{_safe(p['name'])}__MASTER_BOM.xlsx"
    out = os.path.join(out_dir, name)
    label = "Master consolidation — all groups" if not group_ids else \
            f"Master consolidation — {len(group_ids)} selected group(s)"
    res = _build(conn, p, rows, out, label)
    db.log(conn, "export_master", p["name"], out)
    conn.commit()
    return res
