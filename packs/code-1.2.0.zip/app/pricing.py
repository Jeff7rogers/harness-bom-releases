"""
pricing.py — distributor price lookup for the parts on a BOM.

Two providers, queried cheapest-effort first:

    DigiKey   Product Information V4      one catalogue, exact, generous quota
    Nexar     Octopart supply GraphQL     many distributors, tiny free quota

Both are stdlib-only (urllib). Nothing here adds a package to the build, which
matters because a Mac on a brand-new Python may only get the pure-Python
essentials installed.

WHAT LEAVES THE PC
------------------
One part number per request, and nothing else. No drawing, no drawing number,
no program or customer name, no quantity from the job — the quantity sent is
only used to pick a price break, and is not the job quantity unless you ask for
it. Two distributors' catalogues are public; the association between a part and
a program is the sensitive part, and that association is never transmitted.

Even so, `controlled` projects are refused outright. That is a deliberate belt
to the braces: the part list of a controlled harness can itself be revealing,
and a buyer who needs a price for one can pick up the phone.

WHAT IT IS NOT
--------------
It is not a quote. A catalogue price for a D38999 is a starting number for a
bid, not a commitment from a distributor, and MIL-spec connectors are often
absent from both catalogues entirely — a miss here means "ask a distributor",
not "this part is free". Every price is stored with the source it came from and
the date it was read, so a stale number is visible as a stale number.

QUOTA
-----
DigiKey allows 120 requests a minute and 1,000 a day on a registered app.
Nexar's evaluation app has a lifetime cap of 1,000 *part objects returned* —
not requests — so this module asks Nexar for one part at a time, only for part
numbers DigiKey could not price, and never re-asks for a part it already has a
recent quote for. A 34-line BOM should cost single digits.
"""
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

from . import db, llm, offline

TIMEOUT = 25
CACHE_DAYS = 14                 # a quote older than this is re-fetched

DIGIKEY_HOSTS = {
    "production": "https://api.digikey.com",
    "sandbox":    "https://sandbox-api.digikey.com",
}
NEXAR_TOKEN_URL = "https://identity.nexar.com/connect/token"
NEXAR_GRAPHQL_URL = "https://api.nexar.com/graphql"


class PricingError(RuntimeError):
    """A provider could not be reached or refused the request."""


class NotConfigured(RuntimeError):
    """No credentials for this provider."""


class Refused(RuntimeError):
    """The project's export classification forbids a lookup."""


# ---------------------------------------------------------------------------
# Credentials — same storage as the model keys: OS keychain, else a 0600 file
# ---------------------------------------------------------------------------
def configured(provider: str) -> bool:
    if provider == "digikey":
        return bool(llm.get_secret("digikey_client_id")
                    and llm.get_secret("digikey_client_secret"))
    if provider == "nexar":
        return bool(llm.get_secret("nexar_client_id")
                    and llm.get_secret("nexar_client_secret"))
    return False


def any_configured() -> bool:
    return configured("digikey") or configured("nexar")


def digikey_env() -> str:
    env = (llm.get_secret("digikey_env") or "production").strip().lower()
    return env if env in DIGIKEY_HOSTS else "production"


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------
def _request(url, data=None, headers=None, method=None, form=False):
    """
    One HTTP call. Returns (status, parsed_json_or_text, response_headers).
    Raises PricingError only when there is no response at all.
    """
    offline.assert_allowed("a distributor price lookup")
    body = None
    hdrs = dict(headers or {})
    if data is not None:
        if form:
            body = urllib.parse.urlencode(data).encode("utf-8")
            hdrs.setdefault("Content-Type", "application/x-www-form-urlencoded")
        else:
            body = json.dumps(data).encode("utf-8")
            hdrs.setdefault("Content-Type", "application/json")
    hdrs.setdefault("Accept", "application/json")
    req = urllib.request.Request(url, data=body, headers=hdrs,
                                 method=method or ("POST" if body else "GET"))
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            raw = resp.read().decode("utf-8", "replace")
            return resp.status, _maybe_json(raw), dict(resp.headers)
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", "replace") if exc.fp else ""
        return exc.code, _maybe_json(raw), dict(exc.headers or {})
    except urllib.error.URLError as exc:
        raise PricingError(
            f"Could not reach {urllib.parse.urlsplit(url).netloc}: {exc.reason}. "
            f"Usually no internet connection, or a company firewall.") from exc
    except OSError as exc:                       # timeouts land here too
        raise PricingError(f"{urllib.parse.urlsplit(url).netloc}: {exc}") from exc


def _maybe_json(text):
    try:
        return json.loads(text)
    except (ValueError, TypeError):
        return text


# ---------------------------------------------------------------------------
# Price-break arithmetic
# ---------------------------------------------------------------------------
def price_at(breaks, qty):
    """
    The unit price you actually pay when buying `qty`, from a list of
    (break_quantity, unit_price).

    Distributor price breaks are floors, not bands: a 1/10/100 ladder means 100
    or more gets the 100 price. So take the highest break at or below qty, and
    if qty is under every break, take the lowest break rather than nothing —
    buying below the minimum is a real situation and the smallest break is the
    honest estimate of what it costs.
    """
    clean = sorted((float(b), float(p)) for b, p in breaks
                   if b is not None and p is not None and float(p) > 0)
    if not clean:
        return None, None
    eligible = [(b, p) for b, p in clean if b <= qty]
    return (eligible[-1][1], eligible[-1][0]) if eligible else (clean[0][1], clean[0][0])


# ---------------------------------------------------------------------------
# DigiKey
# ---------------------------------------------------------------------------
_dk_token = {"value": None, "expires": 0.0}


def digikey_token(force=False):
    if not configured("digikey"):
        raise NotConfigured("DigiKey client id and secret are not set.")
    if not force and _dk_token["value"] and time.time() < _dk_token["expires"]:
        return _dk_token["value"]
    host = DIGIKEY_HOSTS[digikey_env()]
    status, body, _ = _request(
        f"{host}/v1/oauth2/token",
        data={"client_id": llm.get_secret("digikey_client_id"),
              "client_secret": llm.get_secret("digikey_client_secret"),
              "grant_type": "client_credentials"},
        form=True)
    if status != 200 or not isinstance(body, dict) or not body.get("access_token"):
        raise PricingError(f"DigiKey refused the credentials (HTTP {status}). "
                           f"{_short(body)}")
    _dk_token["value"] = body["access_token"]
    # The documented lifetime is ten minutes. Retire it early rather than
    # discovering expiry mid-BOM.
    _dk_token["expires"] = time.time() + max(30, int(body.get("expires_in") or 599) - 45)
    return _dk_token["value"]


def _dk_headers():
    return {
        "Authorization": f"Bearer {digikey_token()}",
        "X-DIGIKEY-Client-Id": llm.get_secret("digikey_client_id"),
        "X-DIGIKEY-Locale-Site": "US",
        "X-DIGIKEY-Locale-Language": "en",
        "X-DIGIKEY-Locale-Currency": "USD",
    }


def digikey_lookup(pn, qty=1):
    """
    One part number -> a quote dict, or None when DigiKey does not carry it.

    Tries the direct productdetails path first. DigiKey's own documentation says
    that path takes a manufacturer part number or a DigiKey part number, but it
    is not reliable for every MPN, so a miss falls back to keyword search and
    retries with the DigiKey part number it returns. That costs a second request
    only on the parts that need it.
    """
    host = DIGIKEY_HOSTS[digikey_env()]
    quoted = urllib.parse.quote(pn, safe="")
    status, body, headers = _request(
        f"{host}/products/v4/search/{quoted}/productdetails", headers=_dk_headers())

    if status == 429:
        raise PricingError(_rate_limited("DigiKey", headers))
    if status == 401:
        digikey_token(force=True)
        status, body, headers = _request(
            f"{host}/products/v4/search/{quoted}/productdetails", headers=_dk_headers())

    product = _dk_product(body) if status == 200 else None

    if product is None:
        dkpn = _dk_keyword_first(host, pn)
        if not dkpn:
            return None
        status, body, headers = _request(
            f"{host}/products/v4/search/{urllib.parse.quote(dkpn, safe='')}/productdetails",
            headers=_dk_headers())
        if status == 429:
            raise PricingError(_rate_limited("DigiKey", headers))
        product = _dk_product(body) if status == 200 else None
        if product is None:
            return None

    return _dk_quote(product, pn, qty)


def _dk_product(body):
    """The productdetails root. Documented as {"Product": {...}}; some responses
    are the bare product. Accept either rather than guess."""
    if not isinstance(body, dict):
        return None
    p = body.get("Product")
    if isinstance(p, dict):
        return p
    return body if body.get("ManufacturerProductNumber") else None


def _dk_keyword_first(host, pn):
    status, body, headers = _request(
        f"{host}/products/v4/search/keyword", headers=_dk_headers(),
        data={"Keywords": pn, "Limit": 5, "Offset": 0})
    if status == 429:
        raise PricingError(_rate_limited("DigiKey", headers))
    if status != 200 or not isinstance(body, dict):
        return None
    want = _norm(pn)
    products = body.get("ExactMatches") or body.get("Products") or []
    for p in products:
        if _norm(p.get("ManufacturerProductNumber", "")) == want:
            return p.get("DigiKeyProductNumber")
    return None


def _dk_quote(product, asked_pn, qty):
    # Price breaks hang off each packaging variation, not off the product, so a
    # cut-tape line and a full-reel line carry different ladders. Take the
    # cheapest unit price available at this quantity across the variations, and
    # record which one it came from.
    best = (None, None, "")
    for v in product.get("ProductVariations") or []:
        vbreaks = [(sp.get("BreakQuantity"), sp.get("UnitPrice"))
                   for sp in (v.get("StandardPricing") or [])]
        unit, at = price_at(vbreaks, qty)
        if unit is not None and (best[0] is None or unit < best[0]):
            best = (unit, at, ((v.get("PackageType") or {}).get("Name")
                               or v.get("DigiKeyProductNumber") or ""))
    unit, at, variation = best
    if unit is None:                                   # no variations priced
        unit, at = price_at([(1, product.get("UnitPrice"))], qty)
    if unit is None:
        return None

    lead = product.get("ManufacturerLeadWeeks")
    return {
        "provider": "digikey",
        "source": "DigiKey",
        "pn": asked_pn,
        "mfg": ((product.get("Manufacturer") or {}).get("Name") or "").strip(),
        "description": ((product.get("Description") or {}).get("ProductDescription")
                        or "").strip(),
        "unit_price": round(float(unit), 5),
        "currency": "USD",
        "break_qty": at,
        "moq": None,
        "stock": _int(product.get("QuantityAvailable")),
        "lead_wk": _lead_weeks(lead),
        "url": product.get("ProductUrl") or "",
        "note": " · ".join(x for x in (variation, product.get("LeadStatus") or "") if x),
    }


# ---------------------------------------------------------------------------
# Nexar (Octopart)
# ---------------------------------------------------------------------------
_nx_token = {"value": None, "expires": 0.0}

MPN_QUERY = """
query SearchMpn($mpn: String!, $limit: Int!, $country: String!, $currency: String!) {
  supSearchMpn(q: $mpn, limit: $limit, country: $country, currency: $currency) {
    hits
    results {
      part {
        mpn
        shortDescription
        totalAvail
        manufacturer { name }
        sellers {
          company { name isVerified }
          offers {
            inventoryLevel
            moq
            prices { quantity price currency convertedPrice convertedCurrency }
          }
        }
      }
    }
  }
}
"""


def nexar_token(force=False, scope="supply.domain"):
    if not configured("nexar"):
        raise NotConfigured("Nexar client id and secret are not set.")
    if not force and _nx_token["value"] and time.time() < _nx_token["expires"]:
        return _nx_token["value"]
    status, body, _ = _request(
        NEXAR_TOKEN_URL,
        data={"grant_type": "client_credentials",
              "client_id": llm.get_secret("nexar_client_id"),
              "client_secret": llm.get_secret("nexar_client_secret"),
              "scope": scope},
        form=True)
    if status != 200 and scope == "supply.domain":
        # Nexar's own docs say supply.domain; at least one working client sends
        # the bare "supply". Try that before giving up on the credentials.
        return nexar_token(force=True, scope="supply")
    if status != 200 or not isinstance(body, dict) or not body.get("access_token"):
        raise PricingError(f"Nexar refused the credentials (HTTP {status}). {_short(body)}")
    _nx_token["value"] = body["access_token"]
    _nx_token["expires"] = time.time() + max(60, int(body.get("expires_in") or 86400) - 300)
    return _nx_token["value"]


def nexar_lookup(pn, qty=1, limit=1):
    """
    One part number -> the cheapest in-stock offer as a quote dict, or None.

    `limit` is 1 on purpose. Nexar counts *part objects returned* against the
    quota, not requests, and an evaluation app has a thousand of them for its
    whole life. Asking for five near-matches to price one part number would
    burn the allowance five times as fast for no gain.
    """
    status, body, _ = _request(
        NEXAR_GRAPHQL_URL,
        headers={"Authorization": f"Bearer {nexar_token()}"},
        data={"query": MPN_QUERY,
              "variables": {"mpn": pn, "limit": limit,
                            "country": "US", "currency": "USD"}})
    if status == 401:
        nexar_token(force=True)
        status, body, _ = _request(
            NEXAR_GRAPHQL_URL,
            headers={"Authorization": f"Bearer {nexar_token()}"},
            data={"query": MPN_QUERY,
                  "variables": {"mpn": pn, "limit": limit,
                                "country": "US", "currency": "USD"}})
    if status != 200 or not isinstance(body, dict):
        raise PricingError(f"Nexar returned HTTP {status}. {_short(body)}")
    if body.get("errors"):
        msg = "; ".join(str(e.get("message", e)) for e in body["errors"][:2])
        if "part limit" in msg.lower():
            raise PricingError(
                "Nexar part limit reached — an evaluation app allows 1,000 parts for "
                "its lifetime. Prices already fetched are kept; the rest need a paid "
                "plan or DigiKey.")
        raise PricingError(f"Nexar rejected the query: {msg}")

    results = (((body.get("data") or {}).get("supSearchMpn") or {}).get("results")) or []
    return _nx_quote(results, pn, qty)


def _nx_quote(results, pn, qty):
    """
    Pick the offer to quote out of a supSearchMpn result set.

    Split out from the request so it can be tested against a canned response:
    the offer-selection rule is the part with judgement in it, and it should not
    need a live account and a spent quota to exercise.
    """
    want = _norm(pn)
    part = None
    for r in results:
        p = r.get("part") or {}
        if _norm(p.get("mpn", "")) == want:
            part = p
            break
    if part is None:
        return None

    best = None
    for seller in part.get("sellers") or []:
        name = ((seller.get("company") or {}).get("name") or "").strip()
        for offer in seller.get("offers") or []:
            breaks = [(pr.get("quantity"),
                       pr.get("convertedPrice") if pr.get("convertedCurrency") == "USD"
                       else (pr.get("price") if pr.get("currency") == "USD" else None))
                      for pr in (offer.get("prices") or [])]
            unit, at = price_at(breaks, qty)
            if unit is None:
                continue
            stock = _int(offer.get("inventoryLevel"))
            # Prefer a stocked offer over a cheaper unstocked one: a price you
            # cannot buy at is not a price.
            key = (0 if (stock or 0) > 0 else 1, unit)
            if best is None or key < best[0]:
                best = (key, {
                    "provider": "nexar",
                    "source": name or "Octopart",
                    "pn": pn,
                    "mfg": ((part.get("manufacturer") or {}).get("name") or "").strip(),
                    "description": (part.get("shortDescription") or "").strip(),
                    "unit_price": round(float(unit), 5),
                    "currency": "USD",
                    "break_qty": at,
                    "moq": _int(offer.get("moq")),
                    "stock": stock,
                    "lead_wk": None,
                    "url": "",          # no offer URL field is confirmed; do not invent one
                    "note": "via Octopart" + ("" if (stock or 0) > 0 else " · no stock shown"),
                })
    return best[1] if best else None


# ---------------------------------------------------------------------------
# The job
# ---------------------------------------------------------------------------
def assert_allowed(controlled=False):
    """
    The three reasons pricing does not happen, in the order they matter.

    Shared by the project pricing and the spreadsheet pricing, so neither can
    quietly grow a looser rule than the other - the whole value of an
    export-control gate is that there is exactly one of it.
    """
    if controlled:
        raise Refused(
            "This project carries an affirmative export-control determination. Part "
            "numbers are not sent to a distributor API for controlled work, even "
            "though a catalogue lookup is ordinarily harmless — enter prices by hand "
            "on the Parts master, or get them from a buyer.")
    if offline.engaged():
        raise Refused(
            "The offline lock is on, so no part numbers were sent anywhere. It engages "
            "by itself while any project in this database is marked controlled. "
            "Network \u203a Unlock releases it for this session; prices typed in by "
            "hand on the Parts master work with the lock on.")
    if not any_configured():
        raise NotConfigured(
            "No pricing accounts are set up yet. Settings › Pricing to add a DigiKey "
            "or Nexar/Octopart app — both are free to register. Until then, type prices "
            "in on the Parts master and they still flow into the workbook.")


def fetch_for_project(conn, project, qty=None, force=False, providers=None):
    """
    Price every distinct part number in a project.

    Returns a report dict: counts, the per-part outcome, and any provider
    failure. Never raises for a single part's sake — one part number that
    upsets a provider must not lose the other thirty-three.
    """
    assert_allowed(controlled=(project["classification"] or "") == "controlled")

    qty = int(qty or project["qty_high"] or 1)
    pns = [r["pn"] for r in conn.execute(
        "SELECT DISTINCT p.pn FROM part p"
        "  JOIN harness h ON h.id = p.harness_id"
        "  JOIN grp g     ON g.id = h.group_id"
        " WHERE g.project_id = ? AND TRIM(COALESCE(p.pn,'')) <> ''"
        " ORDER BY p.pn", (project["id"],))]
    return fetch_pns(conn, pns, qty=qty, force=force, providers=providers)


def fetch_pns(conn, pns, qty=1, force=False, providers=None, progress=None):
    """
    Price a list of part numbers. The engine under both the project pricing and
    the spreadsheet pricing, so a part number priced from a sheet is priced by
    exactly the same rules as one read off a drawing - same providers in the
    same order, same freshness window, same evidence kept.

    `progress` is called with (done, total, pn) so a long sheet can show where
    it has got to rather than appearing to hang.
    """
    use = providers or [p for p in ("digikey", "nexar") if configured(p)]
    qty = int(qty or 1)
    report = {"qty": qty, "asked": len(pns), "priced": 0, "missed": 0,
              "cached": 0, "rows": [], "error": "", "providers": list(use)}

    for i, pn in enumerate(pns, start=1):
        if progress:
            try:
                progress(i, len(pns), pn)
            except Exception:
                pass
        pn = pn.strip().upper()
        if not force and _fresh_quote(conn, pn):
            report["cached"] += 1
            report["rows"].append({"pn": pn, "outcome": "kept", "source": "already priced"})
            continue
        got = []
        for provider in use:
            try:
                q = (digikey_lookup if provider == "digikey" else nexar_lookup)(pn, qty)
            except NotConfigured:
                continue
            except PricingError as exc:
                report["error"] = str(exc)
                use = [p for p in use if p != provider]     # stop asking a dead provider
                continue
            if q:
                db.record_quote(conn, q)
                got.append(q)
            # A part DigiKey carries does not need Nexar's scarce quota spent on it.
            if got and provider == "digikey":
                break
        if got:
            cheapest = min(got, key=lambda q: q["unit_price"])
            db.apply_quote_to_master(conn, cheapest)
            report["priced"] += 1
            report["rows"].append({
                "pn": pn, "outcome": "priced", "source": cheapest["source"],
                "price": cheapest["unit_price"], "break_qty": cheapest["break_qty"],
                "stock": cheapest["stock"]})
        else:
            report["missed"] += 1
            report["rows"].append({"pn": pn, "outcome": "not found", "source": ""})
        if report["error"] and not use:
            break

    conn.commit()
    return report


def _fresh_quote(conn, pn):
    row = conn.execute(
        "SELECT MAX(fetched_at) AS t FROM quote WHERE pn = ?", (pn,)).fetchone()
    if not row or not row["t"]:
        return False
    try:
        import datetime
        age = datetime.datetime.now() - datetime.datetime.fromisoformat(row["t"])
        return age.days < CACHE_DAYS
    except (ValueError, TypeError):
        return False


# ---------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------
def _norm(s):
    return "".join(c for c in (s or "").upper() if c.isalnum())


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _lead_weeks(v):
    """DigiKey's lead field is not consistently documented; accept a number, or
    a string like '12 Weeks', and give up quietly on anything else."""
    n = _int(v)
    if n is not None:
        return n
    if isinstance(v, str):
        digits = "".join(c for c in v if c.isdigit())
        return int(digits) if digits else None
    return None


def _rate_limited(who, headers):
    retry = headers.get("Retry-After") or headers.get("retry-after") or "?"
    return (f"{who} rate limit reached (120 requests a minute, 1,000 a day). "
            f"Retry after {retry} seconds. Prices fetched so far are saved.")


def _short(body, n=180):
    text = json.dumps(body) if isinstance(body, (dict, list)) else str(body or "")
    return text[:n] + ("…" if len(text) > n else "")
