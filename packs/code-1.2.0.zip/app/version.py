"""
version.py — single source of truth for the version number.

Bump VERSION, tag the commit `v<VERSION>`, push the tag. GitHub Actions builds
the installers and publishes the release. Nothing else needs editing.
"""
import json
import os
import urllib.request

VERSION = "1.2.0"
APP_TITLE = "Harness BOM"

# The oldest installed program a code pack built from this source can run on.
#
# Bump this ONLY when a change needs something an update cannot carry: a new
# package with a binary in it, a change to run.py, anything the installer puts
# on the machine rather than the program's own Python. Every pack published
# declares it, and a PC older than this is offered the full installer instead
# of a pack that would not work on it.
#
# pypdfium2 arrived in 1.1.0, which is why this is 1.1.0 and not 1.0.0.
RUNTIME = "1.1.0"

# Set by the CI workflow so the app can point at its own releases page.
REPO = os.environ.get("HARNESSBOM_REPO", "")     # e.g. "jeff7rogers/harness-bom"

RELEASES_URL = f"https://github.com/{REPO}/releases/latest" if REPO else ""
_API = f"https://api.github.com/repos/{REPO}/releases/latest" if REPO else ""


def _parse(v: str):
    parts = []
    for chunk in (v or "").lstrip("vV").split("."):
        digits = "".join(c for c in chunk if c.isdigit())
        parts.append(int(digits) if digits else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def is_newer(candidate: str, current: str = VERSION) -> bool:
    return _parse(candidate) > _parse(current)


def check_for_update(timeout=4):
    """
    Ask GitHub whether a newer release exists.

    OFF by default, and opt-in: set HARNESSBOM_CHECK_UPDATES=1. It sends nothing
    but a plain GET for a public release listing — no drawing data, no
    identifiers. On any failure it returns None and the app carries on offline.

    The offline lock refuses it like anything else. An update check is a small
    disclosure — it tells GitHub this machine runs this program — and a lock
    that made an exception for the program's own convenience would not be a lock.

    Returns {"version", "url", "notes"} or None.
    """
    if not os.environ.get("HARNESSBOM_CHECK_UPDATES") or not _API:
        return None
    try:
        from . import offline
        offline.assert_allowed("the update check")
    except Exception:
        return None
    try:
        req = urllib.request.Request(_API, headers={
            "Accept": "application/vnd.github+json",
            "User-Agent": f"HarnessBOM/{VERSION}",
        })
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        tag = (data.get("tag_name") or "").strip()
        if tag and is_newer(tag):
            return {
                "version": tag.lstrip("vV"),
                "url": data.get("html_url") or RELEASES_URL,
                "notes": (data.get("body") or "").strip()[:400],
            }
    except Exception:
        return None
    return None
