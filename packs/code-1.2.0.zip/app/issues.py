"""
issues.py — drawing-issue checks that need no model call.

Every check here runs against structured data already in the database, so it
works in Phase 1 with manually entered BOMs and will keep working unchanged
once extraction is automatic. Checks that genuinely need to read the drawing
(AWG vs datasheet, RFP scope gaps) arrive in Phase 2.

Each check returns zero or more dicts:
    {code, severity, category, message, harness_id}
Severity: high | medium | low
"""
import re
from collections import defaultdict

# D38999 part number: D38999/<slash>F<shell><arrangement><P|S>N
#   /24 = receptacle, /26 = plug;  P = pin contacts, S = socket contacts
D38999_RE = re.compile(r"D38999/(\d{2})[A-Z]{1,2}([A-Z])(\d{2})([PS])[A-Z]?", re.I)
SHELL_STYLE = {"20": "wall mount receptacle", "24": "jam nut receptacle",
               "26": "plug", "25": "box mount receptacle"}

CONSUMABLE_CATEGORIES = {"Heat Shrink", "Lacing Tape", "Tie Wrap", "Marker", "Label", "Tape", "Solder"}


def _rows(conn, sql, args=()):
    return conn.execute(sql, args).fetchall()


def check_project(conn, project_id):
    """Run every check. Returns a list of issue dicts (not yet persisted)."""
    project = conn.execute("SELECT * FROM project WHERE id = ?", (project_id,)).fetchone()
    harnesses = _rows(conn, "SELECT h.* FROM harness h JOIN grp g ON g.id = h.group_id"
                            " WHERE g.project_id = ? ORDER BY h.id", (project_id,))
    found = []
    n = 0

    def emit(sev, cat, msg, harness_id=None):
        nonlocal n
        n += 1
        found.append({"code": f"I-{n}", "severity": sev, "category": cat,
                      "message": msg, "harness_id": harness_id})

    # ---- per-harness checks -------------------------------------------------
    for h in harnesses:
        parts = _rows(conn, "SELECT * FROM part WHERE harness_id = ?", (h["id"],))
        wires = _rows(conn, "SELECT * FROM wire WHERE harness_id = ?", (h["id"],))
        terms = _rows(conn, "SELECT * FROM termination WHERE harness_id = ?", (h["id"],))
        label = h["drawing_no"] or h["name"]

        _check_contact_gender(parts, label, h["id"], emit)
        _check_shield_hardware(parts, label, h["id"], emit)
        _check_wire_vs_terminations(wires, terms, label, h["id"], emit)
        _check_pin_collisions(wires, label, h["id"], emit)
        _check_consumables(parts, project, label, h["id"], emit)
        _check_zero_quantities(parts, label, h["id"], emit)
        if not wires:
            emit("medium", "Completeness",
                 f"{label}: no wire list entered. Termination counts and most of the labor "
                 f"estimate depend on it.", h["id"])

    # ---- project-wide checks ------------------------------------------------
    _check_pn_consistency(conn, project_id, emit)
    if int(project["include_pricing"] or 0):
        _check_unpriced(conn, project_id, emit)
    if project["classification"] == "review":
        emit("high", "Export control",
             "Project classification is REVIEW: a conditional export legend or a proprietary "
             "marking was found and has not been cleared. Clear it on the project screen, with a "
             "named reviewer, before releasing this package.")
    return found


# ---------------------------------------------------------------------------
def _check_contact_gender(parts, label, hid, emit):
    """
    Flag when every D38999 in one harness carries the same contact gender.

    This is a VERIFY, not an error. A pigtail adapter legitimately has sockets
    at both ends because both mating halves are pinned. But a plug and its own
    mating receptacle on the same harness sharing a gender will not mate, and
    that is worth one look before 40 shells are ordered.
    """
    genders = defaultdict(list)
    for p in parts:
        m = D38999_RE.search(p["pn"] or "")
        if not m:
            continue
        slash, shell, arrangement, gender = m.groups()
        genders[gender.upper()].append((p["pn"], SHELL_STYLE.get(slash, f"/{slash}")))
    if len(genders) == 1 and sum(len(v) for v in genders.values()) > 1:
        g = next(iter(genders))
        listing = ", ".join(f"{pn} ({style})" for pn, style in
                            sorted({x for v in genders.values() for x in v}))
        emit("medium", "Contact gender",
             f"{label}: every D38999 carries {'SOCKET' if g == 'S' else 'PIN'} contacts — "
             f"{listing}. Confirm each one mates against a connector of the opposite gender. "
             f"Legitimate for an adapter, wrong if a plug and receptacle here mate to each other.",
             hid)


def _check_shield_hardware(parts, label, hid, emit):
    """Connector / backshell / band-clamp quantities should agree."""
    conn_qty = sum(int(p["qty"]) for p in parts if p["category"] == "Connector")
    back_qty = sum(int(p["qty"]) for p in parts if p["category"] == "Connector Accessory"
                   and "BACKSHELL" in (p["description"] or "").upper())
    band_qty = sum(int(p["qty"]) for p in parts if p["category"] == "Shield Term")
    if conn_qty and back_qty and conn_qty != back_qty:
        emit("medium", "Quantity mismatch",
             f"{label}: {conn_qty} connectors but {back_qty} backshells. Confirm which connector "
             f"has no backshell, or correct the quantity.", hid)
    if back_qty and band_qty:
        # band clamps usually come in matched standard + micro pairs
        pairs = band_qty / 2.0
        if abs(pairs - back_qty) >= 1:
            emit("medium", "Quantity mismatch",
                 f"{label}: {back_qty} backshells but {band_qty} band clamps "
                 f"({pairs:.0f} matched sets). Identify which backshell has no shield "
                 f"termination, or correct the quantity.", hid)


def _check_wire_vs_terminations(wires, terms, label, hid, emit):
    """Every conductor should be terminated at both ends."""
    if not wires or not terms:
        return
    crimp_like = sum(int(t["qty"]) for t in terms
                     if not any(k in (t["term_type"] or "").lower()
                                for k in ("shield", "band", "cap", "stow")))
    expected = len(wires) * 2
    if crimp_like and crimp_like != expected:
        emit("high", "Termination count",
             f"{label}: {len(wires)} conductors implies {expected} end terminations, but the "
             f"termination table totals {crimp_like}. Every crimp, splice and solder joint is "
             f"labor and every one is an inspection point — reconcile before quoting.", hid)


def _check_pin_collisions(wires, label, hid, emit):
    """Two conductors landing on the same contact of the same connector."""
    seen = defaultdict(list)
    for w in wires:
        for end, pin in ((w["from_end"], w["from_pin"]), (w["to_end"], w["to_pin"])):
            end = (end or "").strip()
            pin = (pin or "").strip()
            if end and pin:
                seen[(end.upper(), pin)].append(w["signal"] or f"wire {w['wire_no']}")
    for (end, pin), sigs in sorted(seen.items()):
        if len(sigs) > 1:
            emit("high", "Pin collision",
                 f"{label}: {end} contact {pin} is used by {len(sigs)} conductors "
                 f"({', '.join(sigs[:4])}{'…' if len(sigs) > 4 else ''}). Either a transcription "
                 f"error or an intentional splice — if intentional it needs a splice line.", hid)


def _check_consumables(parts, project, label, hid, emit):
    if (project["bom_scope"] or "") == "hard_parts":
        return
    have = {p["category"] for p in parts}
    missing = sorted(c for c in ("Marker", "Tie Wrap", "Lacing Tape", "Tape")
                     if c not in have and c not in {x for x in have})
    if len(missing) >= 3:
        emit("low", "Consumables",
             f"{label}: no {', '.join(missing).lower()} lines. A Class 3 build needs them and "
             f"drawings rarely list them. Scope is '{project['bom_scope']}' — add them or switch "
             f"the project to hard-parts-only so the omission is deliberate.", hid)


def _check_zero_quantities(parts, label, hid, emit):
    bad = [p["pn"] for p in parts if float(p["qty"] or 0) <= 0]
    if bad:
        emit("medium", "Data",
             f"{label}: {len(bad)} part line(s) have zero quantity ({', '.join(bad[:5])}). "
             f"They will not appear on the combined sheet.", hid)


def _check_pn_consistency(conn, project_id, emit):
    """
    The same part number entered with different manufacturer or UoM strings.

    This is the failure that split one band clamp into three procurement lines
    during the Vast HAVEN trial.
    """
    rows = _rows(conn,
                 "SELECT p.pn, p.mfg, p.uom, COUNT(*) AS n FROM part p"
                 " JOIN harness h ON h.id = p.harness_id JOIN grp g ON g.id = h.group_id"
                 " WHERE g.project_id = ? GROUP BY UPPER(p.pn), p.mfg, p.uom", (project_id,))
    by_pn = defaultdict(set)
    for r in rows:
        by_pn[(r["pn"] or "").strip().upper()].add((r["mfg"] or "", r["uom"] or ""))
    for pn, variants in sorted(by_pn.items()):
        if len(variants) > 1:
            shown = "; ".join(f"mfg='{m}' uom='{u}'" for m, u in sorted(variants))
            emit("high", "Merge key",
                 f"{pn} is entered {len(variants)} different ways ({shown}). The combined sheet "
                 f"merges on part number, manufacturer and UoM together, so this will reach "
                 f"procurement as {len(variants)} separate lines for one part. Normalize it.")


def _check_unpriced(conn, project_id, emit):
    rows = _rows(conn,
                 "SELECT DISTINCT UPPER(p.pn) AS pn FROM part p"
                 " JOIN harness h ON h.id = p.harness_id JOIN grp g ON g.id = h.group_id"
                 " WHERE g.project_id = ?", (project_id,))
    unpriced, estimated = [], []
    for r in rows:
        m = conn.execute("SELECT last_price, is_estimate FROM partsmaster WHERE pn = ?",
                         (r["pn"],)).fetchone()
        if not m or m["last_price"] is None:
            unpriced.append(r["pn"])
        elif m["is_estimate"]:
            estimated.append(r["pn"])
    if unpriced:
        emit("high", "Pricing",
             f"{len(unpriced)} part number(s) have no price at all and will show blank: "
             f"{', '.join(sorted(unpriced)[:8])}{'…' if len(unpriced) > 8 else ''}.")
    if estimated:
        emit("medium", "Pricing",
             f"{len(estimated)} part number(s) are priced from ESTIMATES, not quotes: "
             f"{', '.join(sorted(estimated)[:8])}{'…' if len(estimated) > 8 else ''}. "
             f"Get formal RFQs before any firm-fixed-price commitment.")


def refresh(conn, project_id):
    """Re-run checks and replace the unresolved issue list for this project."""
    from . import db
    conn.execute("DELETE FROM issue WHERE project_id = ? AND resolved = 0", (project_id,))
    for i in check_project(conn, project_id):
        conn.execute(
            "INSERT INTO issue (project_id, harness_id, code, severity, category, message, created_at)"
            " VALUES (?,?,?,?,?,?,?)",
            (project_id, i["harness_id"], i["code"], i["severity"], i["category"],
             i["message"], db.now()))
    db.log(conn, "issues_refresh", f"project {project_id}")
    conn.commit()
    return conn.execute(
        "SELECT * FROM issue WHERE project_id = ? ORDER BY resolved,"
        " CASE severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, id",
        (project_id,)).fetchall()
