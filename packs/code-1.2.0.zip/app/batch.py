"""
batch.py — reading a pile of drawings in one go.

WHY THIS EXISTS
---------------
The upload flow was built for one drawing and never revisited. To do a
twelve-harness program you typed a name, clicked into the harness, uploaded,
reviewed, applied, came back out, and did it again eleven times. The reading
itself was never the slow part; the round trips were.

Now you drop twelve PDFs on the group and each becomes a harness. The work
happens on a background thread and progress is written to the database, so the
progress page is a plain query: it survives a refresh, it can be reopened
tomorrow, and the finished batch IS the summary of the program — what each
drawing gave up, and which ones need a person.

WHY A THREAD AND NOT A QUEUE
----------------------------
This is a single-user desktop app serving localhost. A job queue, a broker and a
worker process would be three more things to bundle into an installer and three
more things to go wrong on a technician's PC. One daemon thread with its own
SQLite connection is the right size of machinery for the problem.

Each drawing is read in its own try/except, so one bad PDF costs that PDF and
nothing else. A drawing that raises is recorded as an error against its row with
the message attached, and the batch carries on.

WHAT SURVIVES A RESTART
-----------------------
Nothing running. If the program is closed mid-batch the thread dies with it, and
rows stay as they were. `RUNNING` remembers which batches this process actually
owns, so a batch left at 'running' by a previous process is reported as
interrupted rather than pretending to still be working — a progress bar that
never moves is worse than an honest "this stopped".
"""
import datetime
import os
import threading

from . import db, extract, llm, offline, scanner

# Batch ids this process is actually working on. A batch marked 'running' in the
# database that is not in here belonged to a process that has since exited.
RUNNING = set()
_lock = threading.Lock()


def _now():
    return datetime.datetime.now().isoformat(timespec="seconds")


def drawings_dir():
    d = os.path.join(db.data_dir(), "drawings")
    os.makedirs(d, exist_ok=True)
    return d


def safe_name(filename: str) -> str:
    return "".join(c if (c.isalnum() or c in "-_. ") else "_" for c in (filename or "drawing.pdf"))


def start(conn, group_id: int, saved, want_ocr: bool, want_model: bool = False) -> int:
    """
    Record a batch and set a worker going.

    `saved` is a list of (original_filename, path_on_disk) already written to
    disk by the request — the request thread does the saving, because a
    Werkzeug upload stream does not outlive the request.
    """
    cur = conn.execute(
        "INSERT INTO batch (group_id, total, done, want_ocr, want_model, state, created_at)"
        " VALUES (?,?,?,?,?,?,?)",
        (group_id, len(saved), 0, 1 if want_ocr else 0, 1 if want_model else 0,
         "running", _now()))
    bid = cur.lastrowid
    for i, (filename, path) in enumerate(saved):
        conn.execute(
            "INSERT INTO batch_item (batch_id, filename, pdf_path, state, sort_order)"
            " VALUES (?,?,?,?,?)", (bid, filename, path, "queued", i))
    db.log(conn, "batch_upload", f"group {group_id}",
           f"{len(saved)} drawing(s), ocr={'yes' if want_ocr else 'no'}, "
           f"model={'yes' if want_model else 'no'}")
    conn.commit()

    with _lock:
        RUNNING.add(bid)
    threading.Thread(target=_run, args=(bid,), daemon=True,
                     name=f"harnessbom-batch-{bid}").start()
    return bid


def state_of(conn, bid: int) -> str:
    """
    The batch's state, corrected for a process that has restarted.

    A batch the database calls 'running' that this process does not own cannot
    be running: the thread that owned it is gone.
    """
    row = conn.execute("SELECT state FROM batch WHERE id = ?", (bid,)).fetchone()
    if not row:
        return "missing"
    if row["state"] != "running":
        return row["state"]
    with _lock:
        owned = bid in RUNNING
    if owned:
        return "running"
    conn.execute("UPDATE batch SET state='interrupted', finished_at=? WHERE id=?",
                 (_now(), bid))
    conn.execute("UPDATE batch_item SET state='error',"
                 " message='The program was closed before this drawing was read.'"
                 " WHERE batch_id=? AND state IN ('queued','reading')", (bid,))
    conn.commit()
    return "interrupted"


# ---------------------------------------------------------------------------
# The worker
# ---------------------------------------------------------------------------
def _run(bid: int):
    """Own connection: a sqlite3 connection belongs to the thread that made it."""
    conn = db.init()
    try:
        items = conn.execute(
            "SELECT * FROM batch_item WHERE batch_id = ? ORDER BY sort_order, id",
            (bid,)).fetchall()
        b = conn.execute("SELECT * FROM batch WHERE id = ?", (bid,)).fetchone()
        if not b:
            return
        want_ocr = bool(b["want_ocr"])
        want_model = bool(b["want_model"])
        for item in items:
            try:
                _one(conn, b, item, want_ocr, want_model)
            except Exception as exc:                  # one bad PDF, not twelve
                conn.execute(
                    "UPDATE batch_item SET state='error', message=? WHERE id=?",
                    (f"{type(exc).__name__}: {exc}"[:400], item["id"]))
            conn.execute("UPDATE batch SET done = done + 1 WHERE id = ?", (bid,))
            conn.commit()
        conn.execute("UPDATE batch SET state='finished', finished_at=? WHERE id=?",
                     (_now(), bid))
        conn.commit()
    finally:
        with _lock:
            RUNNING.discard(bid)
        try:
            conn.close()
        except Exception:
            pass


def _one(conn, b, item, want_ocr, want_model=False):
    """Read one drawing: scan, create its harness, extract, stage for review."""
    conn.execute("UPDATE batch_item SET state='reading' WHERE id=?", (item["id"],))
    conn.commit()

    path = item["pdf_path"]
    grp = conn.execute("SELECT * FROM grp WHERE id = ?", (b["group_id"],)).fetchone()
    project = conn.execute("SELECT * FROM project WHERE id = ?",
                           (grp["project_id"],)).fetchone()

    # The model tier runs in a batch only when it was asked for on the upload
    # form, and even then only for the parts list - pin maps stay a deliberate
    # per-drawing choice, because they are the expensive ones. It is also the
    # last tier: a drawing the text layer or the image reader could read never
    # reaches it, so a batch of ordinary drawings costs nothing.
    client = None
    if want_model:
        try:
            client = llm.Client(classification=project["classification"])
        except llm.NotConfigured:
            client = None
    res = extract.extract(path, allow_vision=bool(client), llm=client,
                          allow_ocr=want_ocr)

    # The scanner's verdict governs the whole project, as it does for a single
    # upload - and it is what turns the offline lock on mid-batch.
    suggested = scanner.VERDICT_TO_CLASSIFICATION[res["scan"]["verdict"]]
    order = {"controlled": 2, "review": 1, "unclassified": 0}
    if order[suggested] > order[project["classification"]]:
        conn.execute("UPDATE project SET classification=?, class_note=? WHERE id=?",
                     (suggested,
                      f"Raised by the scanner on {item['filename']} ({_now()})",
                      project["id"]))
        db.log(conn, "classification_change", project["name"],
               f"{project['classification']} -> {suggested} (batch, {item['filename']})")
        conn.commit()
        offline.sync(conn)

    hid = _make_harness(conn, b["group_id"], res["meta"], item["filename"])

    payload = {"meta": res["meta"], "parts": res["parts"], "wires": res["wires"],
               "notes": res["notes"], "scan": res["scan"], "blocked": res["blocked"],
               "pin_map_pages": res["pin_map_pages"],
               "vision_requested": bool(want_model), "vision_note": "",
               "vision_missing": llm.missing_for(project["classification"]),
               "ocr_requested": want_ocr,
               "ocr_conf": res.get("ocr_conf", 0.0),
               "read_by_ocr": "ocr" in res["method"],
               "read_by_model": "model-parts" in res["method"]}
    import json
    cur = conn.execute(
        "INSERT INTO extraction (harness_id, filename, pdf_path, verdict, method,"
        " payload, usage_note, created_at) VALUES (?,?,?,?,?,?,?,?)",
        (hid, item["filename"], path, res["scan"]["verdict"], ",".join(res["method"]),
         json.dumps(payload), "", _now()))
    eid = cur.lastrowid

    blank = sum(1 for p in res["parts"] if p.get("qty") is None)
    conn.execute(
        "UPDATE batch_item SET state='done', harness_id=?, extraction_id=?,"
        " verdict=?, method=?, n_parts=?, n_blank_qty=?, message=? WHERE id=?",
        (hid, eid, res["scan"]["verdict"], ",".join(res["method"]),
         len(res["parts"]), blank, _summary(res, blank), item["id"]))
    conn.commit()


def _summary(res, blank) -> str:
    """One line saying what this drawing actually gave up."""
    if res["blocked"] and not res["parts"]:
        return ("Export controlled, and nothing readable. Enter this one by hand.")
    bits = []
    if res["blocked"]:
        bits.append("export controlled")
    if "ocr" in res["method"]:
        bits.append(f"read off the image at {res.get('ocr_conf', 0):.0f}% confidence")
    elif res["parts"]:
        bits.append("read from the text layer")
    if not res["parts"]:
        bits.append("no parts list recognised")
    if blank:
        bits.append(f"{blank} quantity(ies) to type in")
    if res["pin_map_pages"] and not res["wires"]:
        bits.append("has a pin map, not read")
    return "; ".join(bits).capitalize() if bits else ""


def _make_harness(conn, group_id, meta, filename) -> int:
    """
    Create the harness this drawing belongs to.

    Named from its own drawing number where the title block gave one up, because
    that is what the person will recognise on the project screen - falling back
    to the filename, which is at least something they chose. Names are made
    unique within the group so two revisions of one drawing do not collide.
    """
    base = (meta.get("drawing_no") or "").strip() or os.path.splitext(filename)[0]
    base = base[:60] or "Drawing"
    name, n = base, 2
    while conn.execute("SELECT 1 FROM harness WHERE group_id=? AND name=?",
                       (group_id, name)).fetchone():
        name = f"{base} ({n})"
        n += 1
    order = conn.execute("SELECT COUNT(*) c FROM harness WHERE group_id=?",
                         (group_id,)).fetchone()["c"]
    cur = conn.execute(
        "INSERT INTO harness (group_id, name, drawing_no, revision, title, dwg_date,"
        " author, sheets, sort_order, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (group_id, name, meta.get("drawing_no", ""), meta.get("revision", ""),
         meta.get("title", ""), meta.get("dwg_date", ""), meta.get("author", ""),
         int(meta.get("sheets") or 1), order, _now()))
    return cur.lastrowid


def summary(conn, bid):
    """Everything the progress page needs, in one call."""
    b = conn.execute("SELECT * FROM batch WHERE id = ?", (bid,)).fetchone()
    if not b:
        return None
    st = state_of(conn, bid)
    items = conn.execute(
        "SELECT bi.*, h.name AS harness_name FROM batch_item bi"
        " LEFT JOIN harness h ON h.id = bi.harness_id"
        " WHERE bi.batch_id = ? ORDER BY bi.sort_order, bi.id", (bid,)).fetchall()
    grp = conn.execute("SELECT * FROM grp WHERE id = ?", (b["group_id"],)).fetchone()
    project = conn.execute("SELECT * FROM project WHERE id = ?",
                           (grp["project_id"],)).fetchone()
    return {"batch": b, "state": st, "items": items, "grp": grp, "project": project,
            "needs_eyes": [i for i in items
                           if i["state"] == "done"
                           and (i["n_parts"] == 0 or i["n_blank_qty"]
                                or i["verdict"] == "block")],
            "errors": [i for i in items if i["state"] == "error"]}
