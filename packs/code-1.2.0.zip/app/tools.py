"""
tools.py — finding, and installing, the two things this program cannot do itself.

THE PROBLEM THIS SOLVES
-----------------------
Reading a parts list off a drawing that has no text layer takes two outside
pieces: something to turn the sheet into a picture, and something to read the
letters in it. Until now both had to be installed by hand, and when they were
missing the program said so and stopped — which on a Mac meant "run brew" and
on a PC meant "reinstall", neither of which is an answer if you are trying to
quote a job this afternoon.

Two changes fix that:

* **The renderer is gone as an outside dependency.** render.py uses pypdfium2,
  a pip wheel with no system dependencies, and falls back to Poppler only if it
  happens to be there. Nothing to install on any machine.

* **Tesseract can be installed from inside the program**, from Settings ▸
  Readers, with one button and without administrator rights. Two routes, tried
  in this order:

    1. Homebrew, if the Mac already has it. One command, the ordinary way a Mac
       gets this software, and it lands somewhere every other program can use.
    2. conda-forge, if it does not. A single static `micromamba` binary is
       downloaded from its official release page, and it unpacks Tesseract into
       this program's own folder. No administrator rights, no account, nothing
       added to PATH, and nothing outside our own data directory is touched.

WHAT I HAVE AND HAVE NOT TESTED
-------------------------------
The renderer change is tested end to end: a TACOM parts list reads with pdfium
and with Poppler and the two agree word for word.

The Tesseract install is NOT tested from here, because the sandbox this was
written in blocks conda.anaconda.org and Homebrew's servers outright. The
plumbing around it is tested with a stub. What that means in practice: if the
download fails on a real machine, the page shows the command and its whole
output rather than a shrug, so the failure is diagnosable instead of silent.
"""
import os
import platform
import shutil
import stat
import subprocess
import sys
import threading
import time
import urllib.request

from . import db

MICROMAMBA = "https://github.com/mamba-org/micromamba-releases/releases/latest/download/"


def tools_dir() -> str:
    """Where anything this program installs for itself lives. One folder, inside
    the data directory, so 'copy that folder' is still the whole backup story."""
    d = os.path.join(db.data_dir(), "tools")
    os.makedirs(d, exist_ok=True)
    return d


def ocr_prefix() -> str:
    return os.path.join(tools_dir(), "ocr")


# ---------------------------------------------------------------------------
# What is here
# ---------------------------------------------------------------------------
def brew() -> str:
    """Homebrew, if this Mac has it. The two standard locations, then PATH."""
    if sys.platform != "darwin":
        return ""
    for p in ("/opt/homebrew/bin/brew", "/usr/local/bin/brew"):
        if os.path.isfile(p) and os.access(p, os.X_OK):
            return p
    return shutil.which("brew") or ""


def _version_of(exe, args=("--version",)) -> str:
    try:
        out = subprocess.run([exe, *args], capture_output=True, timeout=30)
        text = (out.stdout or out.stderr or b"").decode("utf-8", "replace")
        return text.strip().splitlines()[0] if text.strip() else ""
    except (OSError, subprocess.SubprocessError):
        return ""


def status() -> dict:
    """
    Everything the Readers screen shows. Includes the places that were searched,
    because "not found" without "here is where I looked" is what sent someone
    reinstalling the program when the file was simply somewhere else.
    """
    from . import ocr, render

    r = render.describe()
    tess = ocr.tool("tesseract")
    return {
        "renderer": {
            "ok": bool(r["backend"]),
            "backend": r["backend"],
            "pdfium": r["pdfium"],
            "poppler": r["poppler"],
        },
        "ocr": {
            "ok": bool(tess),
            "path": tess,
            "version": _version_of(tess) if tess else "",
            "searched": ocr.search_path(),
        },
        "brew": brew(),
        "frozen": bool(getattr(sys, "frozen", False)),
        "platform": f"{platform.system()} {platform.machine()}",
    }


def routes() -> list:
    """The install routes that make sense on this machine, best first."""
    from . import render

    out = []
    if not render.available() and not getattr(sys, "frozen", False):
        out.append({
            "id": "render-pip",
            "label": "Install the page renderer",
            "detail": "Adds pypdfium2 to this program's own Python. About 12 MB, a few seconds.",
        })
    b = brew()
    if b:
        out.append({
            "id": "ocr-brew",
            "label": "Install the text reader with Homebrew",
            "detail": f"Runs {b} install tesseract. The ordinary way a Mac gets this, "
                      "and other programs can use it too. About 100 MB.",
        })
    out.append({
        "id": "ocr-conda",
        "label": "Install the text reader without Homebrew"
                 if b else "Install the text reader",
        "detail": "Downloads it into this program's own folder from conda-forge. "
                  "No administrator rights and no account. About 120 MB, a few minutes.",
    })
    return out


# ---------------------------------------------------------------------------
# Doing it
# ---------------------------------------------------------------------------
_JOB = {"route": "", "state": "idle", "log": [], "started": 0.0}
_LOCK = threading.Lock()


def job() -> dict:
    with _LOCK:
        return {"route": _JOB["route"], "state": _JOB["state"],
                "log": list(_JOB["log"]), "started": _JOB["started"]}


def _say(line):
    with _LOCK:
        _JOB["log"].append(line.rstrip())


def start(route_id: str) -> str:
    """
    Begin an install. Returns '' on success, or why it will not start.

    Refused while the offline lock is engaged. That lock exists so a shop with
    controlled drawings on this machine can promise nothing leaves it, and an
    installer is still traffic leaving the machine. Unlock, install, lock again.
    """
    from . import offline

    if offline.engaged():
        return ("The offline lock is on, and installing means downloading. "
                "Unlock it on the Network screen, install, then lock it again.")
    with _LOCK:
        if _JOB["state"] == "running":
            return "An install is already running."
        _JOB.update({"route": route_id, "state": "running", "log": [], "started": time.time()})
    threading.Thread(target=_run, args=(route_id,), daemon=True).start()
    return ""


def _finish(ok, note=""):
    from . import render
    render.reset()
    if note:
        _say(note)
    with _LOCK:
        _JOB["state"] = "done" if ok else "failed"


def _run(route_id):
    try:
        if route_id == "render-pip":
            _install_renderer()
        elif route_id == "ocr-brew":
            _install_brew()
        elif route_id == "ocr-conda":
            _install_conda()
        else:
            _say(f"No such route: {route_id}")
            _finish(False)
            return
    except Exception as exc:                                  # pragma: no cover
        _say(f"Stopped on an unexpected error: {exc.__class__.__name__}: {exc}")
        _finish(False)


def _stream(cmd, timeout=1800, env=None):
    """Run a command, putting every line it prints on the page as it arrives."""
    _say("$ " + " ".join(cmd))
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                env=env, bufsize=1, universal_newlines=True)
    except OSError as exc:
        _say(f"Could not start it: {exc}")
        return 1
    deadline = time.time() + timeout
    for line in proc.stdout:
        _say(line)
        if time.time() > deadline:                            # pragma: no cover
            proc.kill()
            _say("Giving up: this has taken more than half an hour.")
            return 1
    return proc.wait()


def _install_renderer():
    rc = _stream([sys.executable, "-m", "pip", "install", "pypdfium2"], timeout=900)
    from . import render
    render.reset()
    if rc == 0 and render.available():
        _finish(True, "Done. Drawings can be turned into pictures now.")
    else:
        _finish(False, "That did not work. The output above is the whole story — send it to Claude.")


def _install_brew():
    b = brew()
    if not b:
        _finish(False, "Homebrew is not on this Mac after all.")
        return
    rc = _stream([b, "install", "tesseract"], timeout=1800)
    _verify(rc)


def _install_conda():
    """
    Fetch micromamba, then have it unpack Tesseract into our own folder.

    micromamba is one static binary with no dependencies, which is the only
    reason this is a reasonable thing to do from inside an application. The
    prefix is ours alone: uninstalling the program removes it, and nothing on
    the machine outside it is touched.
    """
    mm = _fetch_micromamba()
    if not mm:
        _finish(False)
        return
    prefix = ocr_prefix()
    env = dict(os.environ, MAMBA_ROOT_PREFIX=os.path.join(tools_dir(), "mamba"))
    rc = _stream([mm, "create", "-y", "-p", prefix, "-c", "conda-forge", "tesseract"],
                 timeout=1800, env=env)
    _verify(rc)


def _fetch_micromamba():
    """Download the right micromamba for this machine. Returns its path or ''."""
    sysname, machine = platform.system(), platform.machine().lower()
    arm = machine in ("arm64", "aarch64")
    asset = {
        ("Darwin", True): "micromamba-osx-arm64",
        ("Darwin", False): "micromamba-osx-64",
        ("Linux", True): "micromamba-linux-aarch64",
        ("Linux", False): "micromamba-linux-64",
        ("Windows", True): "micromamba-win-64.exe",
        ("Windows", False): "micromamba-win-64.exe",
    }.get((sysname, arm))
    if not asset:
        _say(f"No micromamba build for {sysname} {machine}.")
        return ""

    dest = os.path.join(tools_dir(), asset)
    if os.path.isfile(dest) and os.path.getsize(dest) > 1_000_000:
        _say(f"Already downloaded: {dest}")
        return dest

    url = MICROMAMBA + asset
    _say(f"Downloading {url}")
    try:
        with urllib.request.urlopen(url, timeout=120) as src:
            data = src.read()
    except Exception as exc:
        _say(f"The download failed: {exc}")
        _say("If this machine is behind a company proxy or a blocklist, that is the "
             "likely reason, and Homebrew will not work either. Tell whoever runs the "
             "network that github.com and conda.anaconda.org need to be reachable.")
        return ""
    if len(data) < 1_000_000:
        _say(f"That download was only {len(data)} bytes, which is not the program. Stopping.")
        return ""
    with open(dest, "wb") as fh:
        fh.write(data)
    os.chmod(dest, os.stat(dest).st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    _say(f"Got it: {len(data) // 1_000_000} MB")
    ver = _version_of(dest, ("--version",))
    if not ver:
        _say("The downloaded file will not run on this machine.")
        return ""
    _say(f"micromamba {ver}")
    return dest


def _verify(rc):
    """
    Prove it works rather than trusting the exit code.

    An installer that returns 0 and leaves nothing runnable behind is a real
    failure mode, and the whole point of this screen is that the program stops
    claiming things it has not checked.
    """
    from . import ocr
    ocr.reset()
    path = ocr.tool("tesseract")
    if rc != 0 and not path:
        _finish(False, f"It stopped with code {rc} and there is no reader afterwards.")
        return
    if not path:
        _finish(False, "It finished, but there is still no reader where one should be.")
        return
    ver = _version_of(path)
    if not ver:
        _finish(False, f"A file arrived at {path} but it will not run.")
        return
    _say(f"Found: {path}")
    _say(ver)
    langs = _version_of(path, ("--list-langs",))
    if langs and "eng" not in _all_langs(path):
        _finish(False, "It installed, but without English language data, which it cannot "
                       "read a drawing without. Send this page to Claude.")
        return
    _finish(True, "Done. Drawings whose parts list is a picture can be read now.")


def _all_langs(path) -> str:
    try:
        out = subprocess.run([path, "--list-langs"], capture_output=True, timeout=30)
        return ((out.stdout or b"") + (out.stderr or b"")).decode("utf-8", "replace")
    except (OSError, subprocess.SubprocessError):
        return ""
