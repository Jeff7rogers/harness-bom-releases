"""
updates.py — shipping a fix to six PCs without reinstalling anything.

THE PROBLEM
-----------
Every change to this program, however small, meant building an 88 MB installer,
getting it to each machine and running it. A one-line parser fix cost an
afternoon, which in practice means the fix does not get made.

HOW THIS WORKS
--------------
Almost everything we change is Python and HTML — parsers, templates, rates,
prompts. Those ship as a CODE PACK: a zip of the `app/` folder, a few hundred
kilobytes, which the running program downloads, verifies and unpacks into its
own data directory. On the next start, run.py loads that folder in place of the
one inside the installed program.

Nothing in the installed program is touched. Which means undoing an update is
not a reinstall — it is writing a different line into one small file, and that
is exactly what the Undo button does.

The exception is a change that needs a new dependency with a binary in it, like
the page renderer did. A pack declares the runtime it needs, and when this copy
of the program is older than that, the bar says so and offers the installer
instead of pretending a code pack will do.

WHAT IS TRUSTED, AND WHY
------------------------
The manifest is fetched over HTTPS from a public repository that only Jeff can
write to, and it carries the SHA-256 of the pack. The pack is checked against
that hash before a single file is written, and the zip is walked for paths that
try to escape the folder they belong in. So taking over a shop PC through this
channel means taking over the GitHub account first — the same trust the
installer already rests on.

Two further rules, both deliberate:

  * The offline lock refuses this like everything else. A lock that made an
    exception for the program's own convenience would not be a lock.
  * Nothing is ever applied without someone clicking. A tool that restarted
    itself under a person halfway through a quote would be worse than the
    reinstalling it replaced.
"""
import hashlib
import json
import os
import shutil
import time
import urllib.request
import zipfile

from . import db, version

# The public, release-only repository. Source stays private; this holds the
# manifest and the packs, so no shop PC ever needs a credential.
MANIFEST_URL = os.environ.get(
    "HARNESSBOM_MANIFEST",
    "https://raw.githubusercontent.com/Jeff7rogers/harness-bom-releases/main/manifest.json")

CHANNEL = os.environ.get("HARNESSBOM_CHANNEL", "stable")
MAX_PACK_BYTES = 40 * 1024 * 1024        # a code pack is ~0.5 MB; 40 is absurd already
KEEP_PACKS = 5


class UpdateError(RuntimeError):
    pass


# ---------------------------------------------------------------------------
# Where things live
# ---------------------------------------------------------------------------
def code_dir() -> str:
    d = os.path.join(db.data_dir(), "code")
    os.makedirs(d, exist_ok=True)
    return d


def pointer_path() -> str:
    return os.path.join(code_dir(), "current.txt")


def current_pack() -> str:
    """The version whose pack is in use, or '' for the one that was installed."""
    try:
        with open(pointer_path(), encoding="utf-8") as fh:
            name = fh.read().strip()
    except OSError:
        return ""
    return name if name and os.path.isdir(os.path.join(code_dir(), name)) else ""


def installed_packs() -> list:
    """Every pack on this machine, newest first."""
    out = []
    for name in os.listdir(code_dir()):
        path = os.path.join(code_dir(), name)
        if os.path.isdir(path) and os.path.isdir(os.path.join(path, "app")):
            out.append({"version": name, "path": path,
                        "at": os.path.getmtime(path),
                        "current": name == current_pack()})
    return sorted(out, key=lambda p: version._parse(p["version"]), reverse=True)


def running_version() -> str:
    """What the user is actually running: the pack if one is in use, else the
    version built into the program."""
    return current_pack() or version.VERSION


# ---------------------------------------------------------------------------
# Looking
# ---------------------------------------------------------------------------
def check(timeout=6) -> dict:
    """
    Ask the release repository what is current.

    Returns {} when there is nothing to offer, or:
        {"version", "kind": "code"|"installer", "url", "sha256", "notes",
         "needs_runtime", "blocked_by_runtime", "size"}

    Never raises. An update check that throws on a bad network would make the
    whole program feel broken for a reason that does not matter.
    """
    from . import offline
    if offline.engaged():
        return {}
    try:
        offline.assert_allowed("the update check")
        req = urllib.request.Request(MANIFEST_URL, headers={
            "User-Agent": f"HarnessBOM/{version.VERSION}",
            "Accept": "application/json",
        })
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read(512 * 1024).decode("utf-8", "replace"))
    except Exception:
        return {}

    entry = (data.get("channels") or {}).get(CHANNEL) or data
    want = str(entry.get("version") or "")
    if not want or not version.is_newer(want, running_version()):
        return {}

    needs = str(entry.get("needs_runtime") or "0.0.0")
    # The runtime is what the INSTALLER put on this machine. A pack that needs a
    # newer one cannot be applied over the top, however new the pack is.
    blocked = version.is_newer(needs, version.VERSION)
    return {
        "version": want,
        "kind": "installer" if (entry.get("kind") == "installer" or blocked) else "code",
        "url": str(entry.get("url") or ""),
        "sha256": str(entry.get("sha256") or "").lower(),
        "notes": str(entry.get("notes") or ""),
        "installer_url": str(entry.get("installer_url") or ""),
        "needs_runtime": needs,
        "blocked_by_runtime": blocked,
        "size": int(entry.get("size") or 0),
    }


# ---------------------------------------------------------------------------
# Applying
# ---------------------------------------------------------------------------
def _download(url, sha256, limit=MAX_PACK_BYTES) -> bytes:
    req = urllib.request.Request(url, headers={
        "User-Agent": f"HarnessBOM/{version.VERSION}"})
    with urllib.request.urlopen(req, timeout=120) as r:
        blob = r.read(limit + 1)
    if len(blob) > limit:
        raise UpdateError("That download is far larger than a code pack should be. Stopping.")
    got = hashlib.sha256(blob).hexdigest()
    if not sha256:
        raise UpdateError("The manifest did not say what this pack should hash to, so it "
                          "cannot be checked. Nothing was installed.")
    if got != sha256:
        raise UpdateError(
            "The download does not match the fingerprint in the manifest, so it is not the "
            "file it claims to be. Nothing was installed. Tell Jeff before trying again.")
    return blob


def _safe_extract(blob: bytes, dest: str):
    """
    Unpack a pack, refusing anything that tries to write outside it.

    A zip can name '../../Windows/System32/x' or carry a symlink pointing
    anywhere on the disk, and a naive extract will obey. This one does not.
    """
    os.makedirs(dest, exist_ok=True)
    import io
    with zipfile.ZipFile(io.BytesIO(blob)) as zf:
        members = zf.infolist()
        if not any(m.filename.startswith("app/") for m in members):
            raise UpdateError("That pack has no app folder in it, so it is not a code pack.")
        for m in members:
            name = m.filename
            if name.startswith("/") or ".." in name.replace("\\", "/").split("/"):
                raise UpdateError(f"The pack contains an unsafe path ({name}). Nothing installed.")
            if (m.external_attr >> 16) & 0o170000 == 0o120000:
                raise UpdateError("The pack contains a symbolic link. Nothing installed.")
            if not (name.startswith("app/") or name in ("VERSION", "manifest.json")):
                raise UpdateError(f"The pack contains a file outside app/ ({name}). "
                                  "Nothing installed.")
        zf.extractall(dest)
    if not os.path.isfile(os.path.join(dest, "app", "main.py")):
        raise UpdateError("The pack unpacked without an app/main.py, so it is not usable.")


def apply(entry: dict, conn=None) -> str:
    """
    Install a code pack and point the program at it. Returns the version.

    The pointer is written LAST, and only after the pack is on disk and has been
    sanity-checked. A failure anywhere before that leaves the program running
    exactly what it was running before.
    """
    from . import offline
    if offline.engaged():
        raise UpdateError("The offline lock is on, and updating means downloading. "
                          "Unlock it on the Network screen, update, then lock it again.")
    if entry.get("kind") != "code":
        raise UpdateError("This one needs the full installer — it changes more than the "
                          "program's own code.")
    want = entry["version"]
    staging = os.path.join(code_dir(), f".staging-{want}-{int(time.time())}")
    final = os.path.join(code_dir(), want)
    try:
        blob = _download(entry["url"], entry.get("sha256", ""))
        _safe_extract(blob, staging)
        if os.path.isdir(final):
            shutil.rmtree(final, ignore_errors=True)
        os.replace(staging, final)
    finally:
        shutil.rmtree(staging, ignore_errors=True)

    _point_at(want)
    _prune()
    if conn is not None:
        db.log(conn, "update_applied", want,
               f"code pack from {entry.get('url','')} ({entry.get('sha256','')[:12]})")
        conn.commit()
    return want


def _point_at(name: str):
    tmp = pointer_path() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(name)
    os.replace(tmp, pointer_path())


def undo(conn=None) -> str:
    """
    Step back one version. Returns what is now in use ('' = the installed one).

    This is the whole point of keeping packs in their own folders: undoing an
    update costs one line in one file, not a reinstall on every machine.
    """
    packs = installed_packs()
    now = current_pack()
    older = [p for p in packs if p["version"] != now
             and version.is_newer(now or "0.0.0", p["version"])]
    target = older[0]["version"] if older else ""
    _point_at(target)
    if conn is not None:
        db.log(conn, "update_undone", now or version.VERSION,
               f"rolled back to {target or 'the installed version'}")
        conn.commit()
    return target


def _prune():
    """Keep a handful of recent packs so Undo has somewhere to go, and no more."""
    packs = installed_packs()
    for p in packs[KEEP_PACKS:]:
        if not p["current"]:
            shutil.rmtree(p["path"], ignore_errors=True)


def last_failure() -> dict:
    """A pack that would not load. run.py writes this on its way past, having
    already fallen back, so the screen can say what happened rather than leaving
    someone wondering why the fix they were promised is not there."""
    try:
        with open(os.path.join(code_dir(), "failed.txt"), encoding="utf-8") as fh:
            name, _, why = fh.read().partition("\t")
    except OSError:
        return {}
    return {"version": name.strip(), "why": why.strip()} if name.strip() else {}


def clear_failure():
    try:
        os.remove(os.path.join(code_dir(), "failed.txt"))
    except OSError:
        pass


def state(conn=None) -> dict:
    """Everything the bar and the Updates screen need."""
    return {
        "running": running_version(),
        "installed": version.VERSION,
        "pack": current_pack(),
        "packs": installed_packs(),
        "can_undo": bool(current_pack()),
        "failed": last_failure(),
        "manifest": MANIFEST_URL,
    }
