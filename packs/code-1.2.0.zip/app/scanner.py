"""
scanner.py — export-control marking scanner.

Runs on every uploaded PDF BEFORE anything else happens. Pure text search over
the PDF text layer: no model call, no API key, no network. That is the point —
the safety gate must work on a machine with no configuration at all.

Two tiers, because the two drawing sets we tested against are genuinely
different:

  BLOCK   An affirmative determination has been made. TACOM/DLA prints carry
          "THIS DOCUMENT CONTAINS TECHNICAL DATA WHOSE EXPORT IS RESTRICTED BY
          THE ARMS EXPORT CONTROL ACT", a DISTRIBUTION STATEMENT B-F, and a
          dated determination. These force the project to 'controlled'.

  REVIEW  A conditional legend. Vast Space prints carry "THIS DRAWING MAY
          CONTAIN TECHNICAL DATA ... EXPORT MAY BE RESTRICTED BY ITAR AND/OR
          EAR" with no distribution statement and no determination. Almost every
          space/defense company stamps this on everything. A human clears it,
          and the clearing is recorded.

A BLOCK hit can never be cleared in the UI. A REVIEW hit can, by a named person,
and the decision lands in the audit log.
"""
import re

BLOCK_PATTERNS = [
    ("arms_export_control_act",
     r"EXPORT\s+IS\s+RESTRICTED\s+BY\s+THE\s+ARMS\s+EXPORT\s+CONTROL\s+ACT",
     "Affirmative export restriction under the Arms Export Control Act"),
    ("export_control_warning",
     r"EXPORT\s+CONTROL\s+WARNING",
     "Export Control Warning block present"),
    ("distribution_statement",
     r"DISTRIBUTION\s+STATEMENT\s+[B-F]\b",
     "DoD Distribution Statement B-F (not releasable to the public)"),
    ("dodd_5230_25",
     r"DOD\s*DIRECTIVE\s*5230\.?25|\b5230\.25\b",
     "Dissemination controlled per DoD Directive 5230.25"),
    ("contains_technical_data",
     r"THIS\s+DOCUMENT\s+CONTAINS\s+TECHNICAL\s+DATA",
     "Affirmative statement that the document contains controlled technical data"),
    ("secret_or_classified",
     r"\b(SECRET|CONFIDENTIAL\s+//|CLASSIFIED\s+BY)\b",
     "Possible classified marking"),
]

REVIEW_PATTERNS = [
    # Stronger than a passing ITAR reference: the drawing states outright that
    # the data IS controlled and may not leave the country without State
    # Department approval. Kept at review rather than block by Jeff's decision,
    # so that a project can still be cleared by name and priced — but the review
    # screen says which of the two legends it found, because they are not the
    # same thing and the difference decides how the material gets quoted.
    ("itar_determination",
     r"ARE\s+CONTROLLED\s+BY\s+THE\s+DEPARTMENT\s+OF\s+STATE|"
     r"CANNOT\s+BE\s+EXPORTED\s+(FROM\s+THE\s+UNITED\s+STATES|OR\s+SHARED)",
     "Affirmative ITAR statement on the face of the drawing - export requires "
     "State Department approval, not a conditional 'may contain' legend"),
    ("may_be_restricted",
     r"(MAY\s+CONTAIN\s+TECHNICAL\s+DATA|EXPORT\s+MAY\s+BE\s+RESTRICTED)",
     "Conditional export legend - no determination made on the face of the drawing"),
    ("itar_mention",
     r"\bITAR\b",
     "ITAR referenced"),
    ("ear_eccn",
     r"\bECCN\b|EXPORT\s+ADMINISTRATION\s+ACT",
     "EAR / Export Administration Act referenced"),
    ("proprietary",
     r"PROPRIETARY\s+AND\s+CONFIDENTIAL|EXCLUSIVE\s+PROPERTY\s+OF",
     "Customer proprietary / NDA marking"),
    ("destruction_notice",
     r"DESTRUCTION\s+NOTICE",
     "Destruction notice present"),
]


def _flatten(text: str) -> str:
    return " ".join((text or "").split())


def extract_text(pdf_path: str) -> str:
    """All text from a PDF, flattened. Returns '' if the file has no text layer."""
    try:
        from pypdf import PdfReader
    except ImportError:                                   # pragma: no cover
        from PyPDF2 import PdfReader                      # type: ignore
    reader = PdfReader(pdf_path)
    return _flatten(" ".join((p.extract_text() or "") for p in reader.pages))


def scan_text(text: str) -> dict:
    """
    Returns:
        {"verdict": "block"|"review"|"clear",
         "hits": [{"tier","key","why","excerpt"}],
         "has_text_layer": bool}
    """
    flat = _flatten(text)
    hits = []
    for tier, patterns in (("block", BLOCK_PATTERNS), ("review", REVIEW_PATTERNS)):
        for key, pattern, why in patterns:
            m = re.search(pattern, flat, re.I)
            if not m:
                continue
            start = max(0, m.start() - 120)
            end = min(len(flat), m.end() + 240)
            hits.append({
                "tier": tier,
                "key": key,
                "why": why,
                "excerpt": flat[start:end].strip(),
            })
    verdict = "clear"
    if any(h["tier"] == "review" for h in hits):
        verdict = "review"
    if any(h["tier"] == "block" for h in hits):
        verdict = "block"
    return {"verdict": verdict, "hits": hits, "has_text_layer": len(flat) > 40}


# Pages looked at with the image reader when the text says nothing. Markings sit
# in the border of the first sheet and, on a multi-sheet set, on the last.
LOOK_PAGES = 2
LOOK_DPI = 150


def _image_text(pdf_path: str) -> str:
    """
    OCR the first and last sheets, for the marking scan only.

    This exists because of a real miss. A four-page L3Harris parts list carried
    the full State Department ITAR statement and a proprietary notice on every
    sheet, and the scanner called it clear — because that block is drawn as
    outlined line-work, the way CAD writes text when it will not embed a font,
    and there is no text layer entry for any of it. The drawing read as
    unclassified, which permits the commercial model lane and distributor
    pricing on controlled technical data.

    Text search can only certify what the text layer contains. So a drawing is
    now never called clear until something has actually looked at a page.
    """
    from . import ocr, render                        # late: both import scanner
    if not (render.available() and ocr.tool("tesseract")):
        return ""
    try:
        from pypdf import PdfReader
        n = len(PdfReader(pdf_path).pages)
    except Exception:
        return ""
    pages = sorted({1, n})[:LOOK_PAGES] if n else []
    out = []
    for page_no in pages:
        try:
            png = render.render(pdf_path, page_no, dpi=LOOK_DPI)
            if not png:
                continue
            out.extend(w["t"] for w in ocr._tsv(png, psm=3))
        except Exception:
            continue
    return " ".join(out)


def scan_pdf(pdf_path: str, look: bool = True) -> dict:
    """
    Scan one PDF for export-control markings.

    `look` renders and reads a couple of pages when the text layer says nothing.
    It is the difference between "no marking in the text" and "no marking", and
    only the second is safe to act on. Pass look=False only where the caller has
    already established the answer another way.
    """
    text = extract_text(pdf_path)
    result = scan_text(text)
    result["path"] = pdf_path
    result["looked"] = False

    if result["verdict"] != "clear":
        return result

    if not result["has_text_layer"]:
        result["verdict"] = "review"
        result["hits"].append({
            "tier": "review",
            "key": "no_text_layer",
            "why": "No text layer found - scanned image. Markings cannot be read by text search; "
                   "a person must confirm the title block before this drawing is processed.",
            "excerpt": "",
        })
        return result

    # Nothing in the text. That is not the same as nothing on the drawing.
    seen = _image_text(pdf_path) if look else ""
    if not seen:
        result["verdict"] = "review"
        result["hits"].append({
            "tier": "review",
            "key": "not_looked_at",
            "why": "No export-control marking in the text layer, and the drawing itself was not "
                   "read - the image reader is not installed (Settings > Readers). Markings are "
                   "often drawn as line-work rather than typed, so a clear text layer does not "
                   "mean a clear drawing. A person must confirm the title block.",
            "excerpt": "",
        })
        return result

    looked = scan_text(seen)
    result["looked"] = True
    if looked["hits"]:
        result["hits"].extend(
            dict(h, why=h["why"] + " (read off the drawing image, not the text layer)")
            for h in looked["hits"])
        result["verdict"] = looked["verdict"]
    return result


VERDICT_TO_CLASSIFICATION = {
    "block":  "controlled",
    "review": "review",
    "clear":  "unclassified",
}


def classification_for(results) -> str:
    """Most restrictive verdict across a set of drawings wins."""
    order = {"controlled": 2, "review": 1, "unclassified": 0}
    best = "unclassified"
    for r in results:
        c = VERDICT_TO_CLASSIFICATION[r["verdict"]]
        if order[c] > order[best]:
            best = c
    return best
