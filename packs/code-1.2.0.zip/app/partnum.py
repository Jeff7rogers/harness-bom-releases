"""
partnum.py — recognising aerospace / MIL-spec part numbers in drawing text.

Two jobs:

  1. Find part numbers in text that a PDF has mangled. Drawing PDFs frequently
     emit kerned text, so "D38999/26FA35SN" arrives as "D38999/26F A35S N" and
     "M27500-22SR3S23" as "M27500-22S R 3S 23". Matching against a de-spaced
     copy of the line recovers them exactly.

  2. Say what a part number IS — category, unit of measure, and for the cable
     families, how many conductors one run carries. That drives the scrap
     factor, the cable-run count, and where the line lands on the BOM.

Everything here is deterministic. No model call, no network. It is the reason
a drawing with a text layer costs nothing to read.
"""
import re

# ---------------------------------------------------------------------------
# Part-number families.
#   (name, compiled pattern, category, uom)
# Order matters: the first match wins, so put specific before general.
# ---------------------------------------------------------------------------
_FAMILIES = [
    # --- circular connectors -------------------------------------------------
    ("D38999",    r"D38999/\d{2}[A-Z]{1,2}[A-Z]?\d{2}[PSAB][A-Z]?(?:-[A-Z0-9]+)?",
     "Connector", "EA"),
    ("MS27473",   r"MS27473[A-Z]?\d{2}[A-Z]\d{2}[PS][A-Z]?", "Connector", "EA"),
    ("MS27484",   r"MS27484[A-Z]?\d{2}[A-Z]\d{2}[PS][A-Z]?", "Connector", "EA"),
    ("MS27506",   r"MS27506[A-Z0-9\-]+",                      "Connector", "EA"),
    ("MS3116",    r"MS3116[A-Z]?\d+-\d+[PS]?",                "Connector", "EA"),
    ("MS3126",    r"MS3126[A-Z0-9\-]+",                       "Connector", "EA"),

    # --- backshells, clamps, accessories ------------------------------------
    # /128 is the Band-It clamping band; everything else in M85049 is a backshell
    ("M85049/128", r"M85049/128-\d+",                    "Shield Term",         "EA"),
    ("M85049",     r"M85049/\d+-\d+[A-Z]?\d*",           "Connector Accessory", "EA"),
    ("M24308",     r"M24308/[0-9\-]+",                   "Connector",           "EA"),

    # --- contacts ------------------------------------------------------------
    ("M39029",    r"M39029/\d+-\d+",                     "Contact", "EA"),

    # --- cable and wire ------------------------------------------------------
    ("M27500",    r"M27500-\s*\d{2}[A-Z]{2}\d[A-Z]\d{2}", "Cable", "IN"),
    ("M22759",    r"M22759/\d+-\d+-\d+",                  "Wire",  "IN"),
    ("M16878",    r"M16878/\d+[A-Z0-9\-]*",               "Wire",  "IN"),
    ("E-cat",     r"(?<![A-Z0-9])E\d{5}(?![0-9])",                          "Cable", "IN"),   # PIC Cat5e, e.g. E40424

    # --- Omnetics micro-D ----------------------------------------------------
    ("OMN-cable", r"A98\d{3}-\d{3}",                      "Connector",           "EA"),
    ("OMN-shell", r"A97\d{3}-\d{3}",                      "Connector Accessory", "EA"),
    ("OMN-conn",  r"A9\d{4}-\d{3}",                       "Connector",           "EA"),

    # --- sleeving and shielding ---------------------------------------------
    ("Techflex",  r"MB[SN]\s*\d\.\d{2}\s*[A-Z]{2}",       "Sleeving", "IN"),
    ("Flexo",     r"(?:PT|CNN|RSN)\d\.\d{2}[A-Z]{2}",     "Sleeving", "IN"),

    # --- consumables ---------------------------------------------------------
    ("M81531",    r"M81531/\d+[A-Z0-9\-]*",               "Marker",      "EA"),
    ("MS3367",    r"MS3367-\d+-\d+",                      "Tie Wrap",    "EA"),
    ("lacing",    r"A-A-52083[A-Z0-9\-]*",                "Lacing Tape", "IN"),
    ("M23053",    r"M23053/\d+-\d+-\d+",                  "Heat Shrink", "IN"),
    ("RNF",       r"RNF-100-[0-9/]+-[A-Z0-9\-]+",         "Heat Shrink", "IN"),
    ("solder-sl", r"S02-\d{2}-[A-Z]",                     "Shield Term", "EA"),
]

FAMILIES = [(n, re.compile(p, re.I), c, u) for n, p, c, u in _FAMILIES]

# How many conductors one physical run of a cable carries.
#   M27500-<AWG><plating><?><N><shield><jacket>  ->  N is the conductor count
_M27500_CONDUCTORS = re.compile(r"M27500-\s*\d{2}[A-Z]{2}(\d)", re.I)
_KNOWN_CONDUCTORS = {"E40424": 4, "E10424": 4, "E12424": 4, "E61424": 4}   # Cat5e, 2 pair

# D38999 slash sheets -> what the shell physically is
D38999_STYLE = {
    "20": "wall mount receptacle",
    "24": "jam nut receptacle",
    "25": "box mount receptacle",
    "26": "plug",
}


def despace(text: str) -> str:
    """Strip every space. Used only for matching, never for display."""
    return re.sub(r"\s+", "", text or "")


# Harness-drawing vocabulary. Kerned text is repaired by de-spacing a segment
# and re-cutting it on these words, longest first. A small closed vocabulary
# beats character heuristics here because the descriptions are formulaic.
VOCAB = """
ACCESSORY ADAPTER ANGLE ASSEMBLY AWG BACKSHELL BAND BANDING BLACK BOOT BRAID
CABLE CAP CIRCULAR CLAMP COAX COLOR COMPOSITE CONDUCTOR CONDUCTORS CONNECTOR
CONTACT CONTACTS COPPER COVER CRIMP DUMMY DUST ELECTRICAL ENTRY FEMALE FLYING
HARNESS HEAT IDENTIFICATION INSERT JACKET KEY LABEL LACING LEADS MALE MARKER
MICRO MIL NICKEL NUT OVAL PAIR PIN PLATED PLUG PORCH PROTECTIVE QUAD
RECEPTACLE RIGHT SEALING SHIELD SHIELDED SHIELDING SHRINK SILVER SIZE SLEEVE
SLEEVING SOCKET SOLDER SPEC STANDARD STRAIGHT STRAIN STRIP TAPE TERMINAL
THERMOFIT TIE TINNED TRIPLE TUBING TWISTED VINYL WASHER WIRE WRAP
""".split()
_VOCAB = sorted(set(VOCAB), key=len, reverse=True)
_SEG_SPLIT = re.compile(r"([,/()])")


def _recut(chunk: str) -> str:
    """Greedy longest-match segmentation of a de-spaced chunk against VOCAB."""
    if not chunk:
        return ""
    words, i, buf = [], 0, ""
    upper = chunk.upper()
    while i < len(upper):
        for w in _VOCAB:
            if upper.startswith(w, i):
                if buf:
                    words.append(buf)
                    buf = ""
                words.append(w)
                i += len(w)
                break
        else:
            buf += chunk[i]
            i += 1
    if buf:
        words.append(buf)
    return " ".join(words)


def dekern(text: str) -> str:
    """
    Repair kerned text: 'S T ANDAR D BAND-IT  C L AMP' -> 'STANDARD BAND-IT CLAMP'.

    PDF drawings often emit letter-spaced text. Each comma-delimited segment is
    de-spaced and re-cut on the domain vocabulary; anything the vocabulary does
    not cover is left as it was rather than mangled further.

    Descriptions are cosmetic — the parts master holds the authoritative one —
    so this errs towards leaving text alone.
    """
    if not text:
        return ""
    # Only intervene when the text actually looks kerned: several very short
    # alphabetic tokens. Clean text passes through untouched.
    toks = text.split()
    shorts = sum(1 for t in toks if len(t) <= 2 and t.isalpha())
    if not toks or shorts < max(2, len(toks) * 0.25):
        return re.sub(r"\s{2,}", " ", text).strip()

    out = []
    for part in _SEG_SPLIT.split(text):
        if part in ",/()":
            out.append(part)
        elif part.strip():
            # preserve hyphenated compounds (BAND-IT) while de-spacing
            pieces = [_recut(despace(p)) for p in part.split("-")]
            out.append("-".join(x for x in pieces if x))
        else:
            out.append(" ")
    joined = "".join(out)
    joined = re.sub(r"\s*,\s*", ", ", joined)
    return re.sub(r"\s{2,}", " ", joined).strip()


def find(text: str):
    """
    Every part number in `text`, de-kerned. Returns a list of dicts:
        {pn, family, category, uom}
    Matching runs against the de-spaced text so kerned part numbers still hit.
    """
    seen, hits = set(), []
    # Search the original text AND a de-spaced copy. De-spacing recovers kerned
    # part numbers but destroys the word boundaries that some patterns rely on,
    # so neither pass alone is sufficient.
    for subject in (text or "", despace(text)):
        for name, pattern, category, uom in FAMILIES:
          for m in pattern.finditer(subject):
            pn = despace(m.group(0)).upper()
            if pn in seen:
                continue
            seen.add(pn)
            hits.append({"pn": pn, "family": name, "category": category, "uom": uom})
    return hits


def first(text: str):
    """The first recognised part number in `text`, or None."""
    hits = find(text)
    return hits[0] if hits else None


def classify(pn: str):
    """Category and UoM for a known part number, or (None, None)."""
    flat = despace(pn).upper()
    for name, pattern, category, uom in FAMILIES:
        m = pattern.fullmatch(flat) or pattern.match(flat)
        if m and m.group(0) == flat:
            return category, uom
    return None, None


def conductors_per_cable(pn: str):
    """Conductors in one run of this cable, or None when we cannot tell."""
    flat = despace(pn).upper()
    if not flat:
        return None
    if flat in _KNOWN_CONDUCTORS:
        return _KNOWN_CONDUCTORS[flat]
    m = _M27500_CONDUCTORS.match(flat)
    if m:
        n = int(m.group(1))
        return n or None
    return None


def d38999_parts(pn: str):
    """
    Break a D38999 part number into what it means, or None.
        D38999/26FA35SN -> slash 26 (plug), shell A, arrangement 35, socket
    """
    m = re.match(r"D38999/(\d{2})([A-Z]{1,2})([A-Z])(\d{2})([PS])([A-Z]?)$",
                 despace(pn).upper())
    if not m:
        return None
    slash, _cls, shell, arrangement, gender, key = m.groups()
    return {
        "slash": slash,
        "style": D38999_STYLE.get(slash, f"/{slash}"),
        "shell": shell,
        "arrangement": arrangement,
        "gender": "socket" if gender == "S" else "pin",
        "key": key or "",
        # contacts are supplied with the connector; the P/S suffix says which
        "contacts_supplied": True,
    }
