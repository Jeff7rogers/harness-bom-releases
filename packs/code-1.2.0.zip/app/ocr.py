"""
ocr.py — the offline parts-list reader.

WHY THIS EXISTS
---------------
Some drawings have no parts list in their text layer at all. Not a scan — a
vector drawing whose text was converted to outlines when the PDF was produced,
which is what CAD does when it will not embed a font. The four TACOM prints
Jeff supplied are exactly this: roughly 3,700 characters of text (notes and
title block), 850 KB of vector content, zero images, and a parts list that two
independent PDF text extractors agree is simply not there as text.

No parser can read text that does not exist. What can read it is optical
character recognition on a rendered page — and critically, Tesseract runs
entirely on this machine. So this tier works on `controlled` drawings, with the
offline lock engaged, with no API key and no network call. For an ITAR shop it
is the only route to an automated parts list, and it is a better route than the
model tier would have been even if the model tier were permitted.

HOW IT READS A TABLE
--------------------
Two passes, because one is either too coarse or too slow:

  1. Render the whole sheet at a low resolution and OCR it to LOCATE the parts
     list — the header row ("PART NUMBER", "DESCRIPTION", "QTY", "CAGE").
     E-size sheets are enormous; OCR'ing one at high resolution to find a table
     occupying 3% of it is wasteful and, because the page is mostly line-work,
     also less accurate.
  2. Crop to that block, render THAT at high resolution, and OCR it again. The
     crop is what lifts accuracy: measured on 12606368 rev C, whole-page OCR
     averaged 37% word confidence and the cropped block averaged 74%.

Rows come from clustering word boxes by y. Columns come from the header's own x
positions, so a table with columns in an unexpected order still reads correctly
— the headings say where things are rather than a hard-coded order.

MIL-STD PARTS LISTS READ UPWARDS
--------------------------------
On a military drawing the parts list sits at the bottom of the sheet with its
column headings at the BOTTOM of the table, item 1 directly above them and the
numbers increasing upward. Read downward from the heading and you find nothing.
Rather than hard-code either direction, `_data_bands()` tries both and keeps
whichever yields more rows that actually parse.

WHAT THIS IS HONESTLY WORTH
---------------------------
About three words in four come back above 60% confidence. That makes this
assisted data entry, not extraction: every row needs a person's eyes, and the
ITEM and QTY columns are the worst of it because small digits sit squeezed
between the table's own rule lines, which OCR reads as ones and pipes. So every
field carries its confidence, the review screen shades the doubtful ones, and
nothing reaches the database without someone looking. A parts list that is 90%
right and flagged where it is unsure saves real time; one that is 90% right and
silent is a liability.
"""
import collections
import csv
import io
import os
import re
import shutil
import subprocess
import tempfile

from . import partnum

# The headings a parts list is recognised by, and the field each one governs.
HEADERS = {
    "item":  (r"^ITEM$", r"^FIND$", r"^NO\.?$", r"^SYM$"),
    "qty":   (r"^QTY\.?$", r"^QUANTITY$", r"^REQD?$", r"^REQ.D$", r"^UNITS?$"),
    "pn":    (r"^PART$", r"^NUMBER$", r"^PART[-/ ]?NO\.?$", r"^IDENTIFYING$"),
    "desc":  (r"^DESCRIPTION$", r"^NOMENCLATURE$", r"^TITLE$"),
    "cage":  (r"^CAGE$", r"^FSCM$", r"^CODE$", r"^MFR$", r"^VENDOR$"),
}
LOCATE_DPI = 150
READ_DPI = 400
MIN_CONF = 0            # tesseract reports -1 for non-text; keep everything and grade later


class NotAvailable(RuntimeError):
    """Tesseract or a page renderer is missing on this machine."""


MISSING = (
    "Reading a parts list off the drawing itself needs a text reader, and this "
    "machine has not got one yet. Settings ▸ Readers installs it in a couple of "
    "minutes — one button, no account and no administrator rights. Drawings whose "
    "parts list is real text are unaffected and still read normally.")


def _bundled_dir():
    """
    Where the installer puts Tesseract and Poppler: a `vendor` folder beside the
    program. Checked before PATH, because a team member who has some other
    Tesseract on PATH should still get the one this app was tested against.
    """
    import sys
    base = (os.path.dirname(sys.executable) if getattr(sys, "frozen", False)
            else os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(base, "vendor")


def search_path():
    """Every directory tool() looks in, in order. Shown on the Readers screen,
    because 'not installed' without 'and here is where I looked' is the message
    that had someone reinstalling the program to fix a path problem."""
    from . import tools
    installed = tools.ocr_prefix()
    return [
        os.path.join(_bundled_dir(), "tesseract"),
        os.path.join(_bundled_dir(), "poppler"),
        _bundled_dir(),
        os.path.join(installed, "bin"),           # conda-forge lays it out like this
        os.path.join(installed, "Library", "bin"),  # …except on Windows
        installed,
        "(then whatever is on PATH)",
    ]


_FOUND = {}


def reset():
    """Forget what was found. Called after Settings ▸ Readers installs something,
    so a reader that arrived a minute ago is used without restarting."""
    _FOUND.clear()


def tool(name):
    """Full path to a helper binary, preferring our own copies. '' if absent."""
    if name in _FOUND:
        return _FOUND[name]
    exe = name + (".exe" if os.name == "nt" else "")
    found = ""
    for d in search_path()[:-1]:
        cand = os.path.join(d, exe)
        if os.path.isfile(cand) and os.access(cand, os.X_OK):
            found = cand
            break
    found = found or shutil.which(name) or ""
    # Only a hit is remembered: a miss must stay cheap to re-ask, because the
    # answer changes the moment someone installs one.
    if found:
        _FOUND[name] = found
    return found


def available() -> bool:
    return bool(tool("tesseract")) and bool(tool("pdftoppm"))


def _tsv(png_path, psm=4):
    """OCR one image to word boxes. Returns [] rather than raising on a bad page."""
    env = dict(os.environ)
    # A Tesseract that did not come from this machine's own package manager will
    # not find its language data unless told where it is. The bundled copy keeps
    # it beside the binary; a conda-forge one keeps it in ../share.
    here = os.path.dirname(tool("tesseract") or "")
    for tessdata in (os.path.join(here, "tessdata"),
                     os.path.join(os.path.dirname(here), "share", "tessdata")):
        if os.path.isdir(tessdata):
            env["TESSDATA_PREFIX"] = tessdata
            break
    try:
        out = subprocess.run(
            [tool("tesseract"), png_path, "stdout", "--psm", str(psm), "tsv"],
            capture_output=True, timeout=300, check=True,
            env=env).stdout.decode("utf-8", "replace")
    except (FileNotFoundError, subprocess.SubprocessError):
        return []
    words = []
    for r in csv.DictReader(io.StringIO(out), delimiter="\t", quoting=csv.QUOTE_NONE):
        text = (r.get("text") or "").strip()
        if not text:
            continue
        try:
            words.append({
                "x": int(r["left"]), "y": int(r["top"]),
                "w": int(r["width"]), "h": int(r["height"]),
                "conf": float(r["conf"]), "t": text,
            })
        except (KeyError, TypeError, ValueError):
            continue
    return words


def _render(pdf_path, page_no, dpi, out_dir, box=None):
    """
    Render a page, or just a rectangle of one, to PNG.

    `box` is (x, y, w, h) in PIXELS AT `dpi`. Cropping in the renderer rather
    than afterwards is the difference between this tier being usable and not:
    an E-size sheet at 400 dpi is a 240-megapixel image that takes minutes to
    produce and longer to OCR, while the parts list on it is a few megapixels.

    The renderer itself lives in render.py, which prefers the pypdfium2 wheel
    and falls back to Poppler. This tier no longer needs anything installed on
    the machine to draw a page.
    """
    from . import render as _renderer
    return _renderer.render(pdf_path, page_no, dpi, out_dir, box)


def _bands(words, tol=None):
    """Group words into text lines by y. tol scales with the text height found."""
    if not words:
        return {}
    tol = tol or max(8, int(sorted(w["h"] for w in words)[len(words) // 2] * 0.7))
    out = collections.defaultdict(list)
    for w in words:
        out[round(w["y"] / tol)].append(w)
    return out


def find_header(words):
    """
    Locate the parts-list heading row.

    Returns {"y":…, "cols": {field: x_centre}, …} or None. Two wrinkles that cost
    real accuracy if ignored:

    * Military parts-list headings are STACKED - "ITEM" over "NO", "QTY" over
      "REQD", "CAGE" over "CODE", "PART" over "NUMBER". Matching one line of
      words finds some columns and misses the two that matter most, so each
      candidate line is merged with the lines below it before being scored.
    * "PART" alone appears in half the notes on a drawing, so a heading is not
      believed without a part-number column AND at least one other.

    More columns beats higher confidence: a heading that located QTY is worth
    more than a tidier one that did not, because an unlocated QTY column means
    every quantity has to be typed by hand.
    """
    bands = _bands(words)
    keys = sorted(bands)
    best = None
    for idx in range(len(keys)):
        for span in (1, 2, 3):
            block = []
            for kk in keys[idx:idx + span]:
                block.extend(bands[kk])
            if not block:
                continue
            cols, seen = {}, {}
            for w in block:
                tok = w["t"].upper().strip(".:,")
                for field, patterns in HEADERS.items():
                    if any(re.match(pat, tok) for pat in patterns):
                        centre = w["x"] + w["w"] / 2
                        if field not in cols or centre < cols[field]:
                            cols[field] = centre
                        seen.setdefault(field, []).append(w["conf"])
            if "pn" not in cols or not ({"desc", "qty", "cage", "item"} & set(cols)):
                continue
            conf = sum(sum(v) / len(v) for v in seen.values()) / len(seen)
            score = (len(cols), round(conf))
            if best is None or score > best["score"]:
                best = {"y": max(w["y"] + w["h"] for w in block),
                        "cols": cols, "conf": conf, "score": score,
                        "x0": min(w["x"] for w in block),
                        "x1": max(w["x"] + w["w"] for w in block)}
    return best


def _assign(word, cols):
    """Which column does this word belong to? Nearest heading centre wins."""
    centre = word["x"] + word["w"] / 2
    return min(cols, key=lambda f: abs(cols[f] - centre))


def _rows_from(words, header, direction):
    """Build candidate rows on one side of the header row."""
    cols = header["cols"]
    # a generous x window: the widest column plus a margin, since a long
    # description overruns its heading
    span = max(cols.values()) - min(cols.values())
    lo = min(cols.values()) - span * 0.35
    hi = max(cols.values()) + span * 0.60
    band = [w for w in words
            if lo <= w["x"] + w["w"] / 2 <= hi
            and ((direction < 0 and w["y"] < header["y"] - header.get("h", 0))
                 or (direction > 0 and w["y"] > header["y"] + 5))]
    out = []
    for _, row in sorted(_bands(band).items(), reverse=(direction < 0)):
        cells = collections.defaultdict(list)
        for w in sorted(row, key=lambda w: w["x"]):
            cells[_assign(w, cols)].append(w)
        out.append(cells)
    return out


def _cell_text(cells, field):
    return " ".join(w["t"] for w in cells.get(field, []))


def _cell_conf(cells, field):
    ws = cells.get(field) or []
    real = [w["conf"] for w in ws if w["conf"] >= 0]
    return round(sum(real) / len(real), 1) if real else 0.0


def _parse_row(cells):
    """One reconstructed table row -> a part dict, or None."""
    pn_raw = _cell_text(cells, "pn")
    desc = _cell_text(cells, "desc")
    if not pn_raw:
        return None

    # The OCR'd cell is the best candidate, but a part number sometimes lands
    # partly in the description column when the table has no rule between them.
    hit = partnum.first(pn_raw) or partnum.first(f"{pn_raw} {desc}")
    pn = hit["pn"] if hit else _plausible_pn(pn_raw)
    if not pn:
        return None

    qty, uom = _qty_from(_cell_text(cells, "qty"))
    item = re.sub(r"\D", "", _cell_text(cells, "item"))[:4]
    return {
        "item": item,
        "pn": pn,
        "category": hit["category"] if hit else "Other",
        "family": hit["family"] if hit else "",
        "uom": uom or (hit["uom"] if hit else "EA"),
        "qty": qty,
        "description": desc.strip(" ,;"),
        "mfg": "",
        "cage": re.sub(r"[^0-9A-Z]", "", _cell_text(cells, "cage").upper())[:5],
        "source": "ocr",
        "recognised": bool(hit),
        "conf": {f: _cell_conf(cells, f) for f in ("item", "qty", "pn", "desc", "cage")},
    }


def _plausible_pn(text):
    """
    A token that looks like a part number even though no known family matched.

    Army drawings routinely call out an 8-digit drawing number as the part
    number, which no MIL-spec family will ever match. Those are real parts and
    must not be dropped — they are marked `recognised: False` so the review
    screen can show that the tool is taking the OCR's word for it.
    """
    for tok in text.replace(",", " ").split():
        t = tok.strip(".;:")
        if len(t) < 5:
            continue
        if re.fullmatch(r"\d{7,9}", t):                       # drawing number
            return t
        if re.fullmatch(r"[0-9A-Z][0-9A-Z/\-]{4,24}", t.upper()) and any(c.isdigit() for c in t):
            return t.upper()
    return ""


def _qty_from(text):
    """
    '2' -> (2.0,'EA'); '32"' -> (32.0,'IN'); 'AR' -> (0.0,'EA').

    An unreadable cell returns None, NOT 1. The QTY column is the hardest thing
    on the sheet for OCR - small digits wedged between the table's own rule
    lines, which come through as ones and pipes - and a BOM where every quantity
    silently reads 1 is worse than no BOM, because someone will believe it.
    None means "a person has to type this", and the review screen enforces it.
    """
    raw = (text or "").strip()
    if not raw:
        return None, ""
    if "AR" in raw.upper():
        return 0.0, "EA"
    m = re.search(r"(\d+(?:\.\d+)?)", raw)
    if not m:
        return None, ""
    qty = float(m.group(1))
    if '"' in raw or re.search(r"\bIN\b", raw.upper()):
        return qty, "IN"
    return qty, "EA"


def read_parts(pdf_path, pages=None, locate_dpi=LOCATE_DPI, read_dpi=READ_DPI):
    """
    Read the parts list off the drawing itself.

    Returns {"parts": [...], "notes": [...], "pages_read": [...], "mean_conf": n}.
    Never raises for a bad page; a page that yields nothing is reported in notes.
    """
    if not available():
        raise NotAvailable(MISSING)

    result = {"parts": [], "notes": [], "pages_read": [], "mean_conf": 0.0}
    work = tempfile.mkdtemp(prefix="harnessbom-ocr-")

    page_list = pages or _page_count(pdf_path)
    confs = []
    for page_no in page_list:
        small = _render(pdf_path, page_no, locate_dpi, work)
        if not small:
            continue
        header = find_header(_tsv(small, psm=6)) or find_header(_tsv(small, psm=4))
        if not header:
            continue

        rows, used_conf = _read_cropped(pdf_path, page_no, header,
                                        locate_dpi, read_dpi, work)
        if not rows:                      # the sharper read found nothing; try the page
            words = _tsv(small, psm=4)
            h2 = find_header(words) or header
            rows = _best_rows(words, h2)
            used_conf = [r["conf"]["pn"] for r in rows]

        if rows:
            result["pages_read"].append(page_no)
            result["parts"].extend(rows)
            confs.extend(used_conf)

    seen, deduped = set(), []
    for r in result["parts"]:
        key = (r["pn"], r["item"])
        if key in seen:
            continue
        seen.add(key)
        deduped.append(r)
    result["parts"] = deduped
    result["mean_conf"] = round(sum(confs) / len(confs), 1) if confs else 0.0

    if not result["parts"]:
        result["notes"].append(
            "No parts list could be read off the drawing image either. Enter the "
            "parts by hand on the harness screen.")
    else:
        weak = [r for r in result["parts"] if min(r["conf"].values()) < 60]
        noqty = [r for r in result["parts"] if r["qty"] is None]
        result["notes"].append(
            f"{len(result['parts'])} parts line(s) read from the drawing image by OCR, "
            f"on this PC with no network call. Average confidence on the part numbers "
            f"is {result['mean_conf']:.0f}%."
            + (f" {len(weak)} line(s) have at least one field the reader was unsure of "
               f"— those are shaded below. Check every one against the drawing."
               if weak else "")
            + (f" {len(noqty)} line(s) have NO quantity: the reader could not make out "
               f"the QTY column, which is normal on a military parts list where the "
               f"digits sit between the table rules. Type those in — they are left "
               f"blank rather than guessed at 1."
               if noqty else ""))
    return result


def _read_cropped(pdf_path, page_no, header, locate_dpi, read_dpi, work):
    """
    Re-read just the parts-list block at high resolution.

    The header row's own geometry gives the block: its full width plus a margin,
    and enough height either side to hold the table whichever way it runs. The
    rectangle is converted from locate-pass pixels into read-pass pixels and
    handed to the renderer, so only that rectangle is ever rasterised.
    """
    k = read_dpi / float(locate_dpi)
    pad_x = max(40.0, (header["x1"] - header["x0"]) * 0.30)
    x0 = (header["x0"] - pad_x) * k
    w = ((header["x1"] - header["x0"]) + pad_x * 2.4) * k
    # a parts list is taller above its heading than below, on a military drawing
    up, down = 900.0, 260.0
    y0 = (header["y"] - up) * k
    h = (up + down) * k
    crop = _render(pdf_path, page_no, read_dpi, work, box=(x0, y0, w, h))
    if not crop:
        return [], []
    words = _tsv(crop, psm=4)
    h2 = find_header(words)
    if not h2:
        return [], []
    rows = _best_rows(words, h2)
    return rows, [r["conf"]["pn"] for r in rows]


def _best_rows(words, header):
    """
    Parse both upward and downward from the header and keep the better side.

    Military parts lists run upward from a heading at the foot of the table;
    commercial ones run downward. Detecting it beats assuming it.
    """
    best = []
    for direction in (-1, 1):
        rows = []
        for cells in _rows_from(words, header, direction):
            row = _parse_row(cells)
            if row:
                rows.append(row)
            elif rows:
                # a blank line after data means the table has ended
                break
        if len(rows) > len(best):
            best = rows
    return best


def _page_count(pdf_path):
    try:
        from pypdf import PdfReader
        return list(range(1, len(PdfReader(pdf_path).pages) + 1))
    except Exception:
        return [1]
