"""
llm.py — the model tier, and the lane gate that governs it.

Only pin maps need a model. Parts, quantities and drawing metadata all come out
of the text layer for free (extract.py), so this module is reached for one job:
reading contact numbers off a rendered sheet, which the text layer mangles.

THE GATE
--------
Two lanes, and the gate is enforced here in code rather than in the UI, because
a UI check is one refactor away from being bypassed:

    unclassified / review  ->  LANE A, commercial Claude API
    controlled             ->  LANE B, Claude via Bedrock in AWS GovCloud

`guard()` raises LaneViolation on any attempt to send a controlled project's
drawing to a commercial endpoint. Every call path goes through it. Until a Lane
B profile is configured, controlled projects simply cannot be extracted — which
is the correct behaviour, not a limitation to work around.

KEYS
----
Stored in the OS keychain when `keyring` is available (Windows Credential
Manager, macOS Keychain), otherwise in a 0600 file beside the database. Never
in the repository, never in the database, never logged.
"""
import base64
import json
import os
import re

from . import db, extract, offline, partnum

SERVICE = "HarnessBOM"

LANE_A = "anthropic"      # commercial API
LANE_B = "bedrock"        # GovCloud

# Which lanes each classification may use.
ALLOWED_LANES = {
    "unclassified": {LANE_A, LANE_B},
    "review":       {LANE_A, LANE_B},
    "controlled":   {LANE_B},
}

DEFAULT_MODEL = "claude-sonnet-4-5"


class LaneViolation(RuntimeError):
    """Raised when a project's classification forbids the configured lane."""


class NotConfigured(RuntimeError):
    """Raised when extraction is requested with no usable credentials."""


# ---------------------------------------------------------------------------
# Credential storage
# ---------------------------------------------------------------------------
def _fallback_path():
    return os.path.join(db.data_dir(), "credentials.json")


def _read_fallback():
    try:
        with open(_fallback_path(), "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def _write_fallback(data):
    path = _fallback_path()
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def set_secret(name: str, value: str):
    """Store a credential. Empty value deletes it."""
    try:
        import keyring
        if value:
            keyring.set_password(SERVICE, name, value)
        else:
            try:
                keyring.delete_password(SERVICE, name)
            except Exception:
                pass
        return "keychain"
    except Exception:
        data = _read_fallback()
        if value:
            data[name] = value
        else:
            data.pop(name, None)
        _write_fallback(data)
        return "file"


def get_secret(name: str):
    env = os.environ.get(f"HARNESSBOM_{name.upper()}")
    if env:
        return env
    try:
        import keyring
        val = keyring.get_password(SERVICE, name)
        if val:
            return val
    except Exception:
        pass
    return _read_fallback().get(name)


def is_configured(lane: str = LANE_A) -> bool:
    if lane == LANE_A:
        return bool(get_secret("anthropic_api_key"))
    return bool(get_secret("bedrock_region") and get_secret("bedrock_model_id"))


# ---------------------------------------------------------------------------
# The gate
# ---------------------------------------------------------------------------
def guard(classification: str, lane: str):
    """Raise unless this classification is allowed to use this lane."""
    allowed = ALLOWED_LANES.get(classification or "review", {LANE_B})
    if lane not in allowed:
        raise LaneViolation(
            f"A project classified '{classification}' may not be sent to the "
            f"'{lane}' endpoint. Controlled technical data can only be processed "
            f"via Claude on AWS Bedrock in GovCloud. Configure a Lane B profile, "
            f"or enter this harness by hand.")
    return True


def lane_for(classification: str) -> str:
    """
    The lane a project must use.

    Controlled work has exactly one lawful lane and that is not negotiable by
    what happens to be configured. Everything else belongs on Lane A.

    This used to fall through to Lane B when Lane A had no key, on the theory
    that "try the other one" was helpful. It was not: an unclassified project
    with no API key ended up reporting "Lane B is not configured, controlled
    drawings need Bedrock in GovCloud", which is a true sentence about the
    wrong problem. The problem was a missing API key, and that is what the
    person needs to be told.
    """
    return LANE_B if classification == "controlled" else LANE_A


def missing_for(classification: str) -> str:
    """
    What is stopping a vision pass on this classification, in plain words.
    Empty string means nothing is: the lane is ready.
    """
    lane = lane_for(classification)
    if lane == LANE_A:
        if not is_configured(LANE_A):
            return ("Having Claude read a drawing needs an Anthropic API key, and none is "
                    "stored on this PC. Settings › Extraction to add one. Everything else — "
                    "the text-layer parts list, the title block, the image reader, the "
                    "export-control scan — is free and already working without it.")
        try:
            import anthropic          # noqa: F401
        except ImportError:
            return ("The 'anthropic' package is missing from this copy of the program, so "
                    "Claude cannot be used no matter what key is stored. On a Mac, delete "
                    "the hidden .venv folder beside the launcher and double-click it "
                    "again; on Windows, reinstall.")
        if not extract.renderer_available():
            return extract.RENDERER_MISSING
        return ""
    if not is_configured(LANE_B):
        return ("This project is export controlled, so a drawing can only be read by "
                "Claude on AWS Bedrock in GovCloud, and that lane is not configured. Use "
                "the image reader, which runs on this PC and is permitted, or set the "
                "Bedrock region and model id in Settings › Extraction.")
    try:
        import boto3                  # noqa: F401
    except ImportError:
        return "The 'boto3' package is not installed in this copy of the program."
    return ""


# ---------------------------------------------------------------------------
# Prompting
# ---------------------------------------------------------------------------
PIN_MAP_PROMPT = """\
This is one sheet of an aerospace wire-harness drawing showing a PIN TO PIN MAPPING.

Read every conductor and return JSON only - no prose, no markdown fence:

{"wires":[{"signal":"","awg":"","cable":"","run_ref":"","from_end":"","from_pin":"",
           "to_end":"","to_pin":"","note":""}]}

Rules:
- One object per CONDUCTOR, not per cable. A twisted pair carrying two signals is
  two objects; a twisted triple is three.
- from_end / to_end are the reference designators exactly as printed
  (for example VCU_3.P7, INHIBIT_1.J1, TREDUO_B.P1).
- from_pin / to_pin are contact numbers exactly as printed. Read them from the
  drawing, digit by digit. Adjacent numbers must NOT be run together - if one box
  shows 16 and the next shows 3, those are two contacts, not 163.
- cable is the cable part number called out on that run (M27500-..., E40424, ...).
- run_ref: if the drawing labels the physical run or twisted pair (TP1, P2, ...),
  put it here; otherwise leave it empty.
- note: put anything conditional here - cap and stow, spare, NC, splice.
- Do not invent conductors. If a value is genuinely unreadable, use "" rather
  than a guess, and say so in note.
"""


PARTS_PROMPT = """\
This is one sheet of an engineering drawing or parts list for a wire harness or
cable assembly. Read its PARTS LIST / BILL OF MATERIALS.

Return JSON only - no prose, no markdown fence:

{"parts":[{"item":"","pn":"","qty":"","uom":"","description":"","cage":"","mfg":"","note":""}],
 "no_parts_list":false}

Rules:
- If this sheet has no parts list on it, return {"parts":[],"no_parts_list":true}.
  Do not read a notes list, a revision block or a table of dash numbers as parts.
- One object per ROW of the table, in the order printed.
- pn is the PART OR IDENTIFYING NUMBER exactly as printed. Where a row shows
  both a drawing number and a part number, the part number is the one to use.
- qty: the number as printed. If the row says AR, REF or NONE, put that word.
  If the quantity cell is genuinely unreadable, use "" - never guess a 1.
- uom: EA, IN, FT, or whatever the UM column says. Where a length is given in
  inches with a " mark, uom is IN.
- description is the nomenclature column, not your own wording.
- cage is the CAGE/FSCM code for that row if there is a column for it.
- Military parts lists are often printed with the column headings at the BOTTOM
  of the table and item 1 directly above them, numbering upward. Read the
  headings first and follow them, whichever way the table runs.
- Read what is printed. Do not complete a partial part number from your own
  knowledge of the standard, and do not add a row that is not in the table.
"""


def _qty_and_uom(qty_raw, uom_raw):
    """
    A quantity from the model -> (number or None, unit).

    None, never 1. A quantity the reader could not make out has to arrive at the
    review screen blank so that someone fills it in; a silent 1 is a part that
    gets ordered short, and nobody would ever know to check it.
    """
    uom = (str(uom_raw or "").strip().upper() or "")
    text = str(qty_raw if qty_raw is not None else "").strip()
    if not text:
        return None, uom
    if text.upper() in ("AR", "A/R", "AS REQUIRED"):
        return 0.0, uom or "EA"
    if text.upper() in ("REF", "NONE", "-", "N/A"):
        return None, uom
    m = re.match(r'^(\d+(?:\.\d+)?)\s*(")?', text)
    if not m:
        return None, uom
    qty = float(m.group(1))
    if m.group(2) == '"':
        return qty, "IN"
    if text.lower().rstrip().endswith("mm"):
        return round(qty / 25.4, 3), "IN"
    return qty, uom


def _json_from(text: str):
    """Pull the first JSON object out of a model reply."""
    if not text:
        return {}
    text = re.sub(r"^\s*```(?:json)?|```\s*$", "", text.strip(), flags=re.M)
    start = text.find("{")
    if start < 0:
        return {}
    depth, in_str, esc = 0, False, False
    for i, ch in enumerate(text[start:], start):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start:i + 1])
                except ValueError:
                    return {}
    return {}


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------
class Client:
    """
    Reads pin maps. Construct with the project's classification so the gate
    applies to every call this object makes.
    """

    def __init__(self, classification="review", lane=None, model=None, dpi=150):
        self.classification = classification or "review"
        self.lane = lane or lane_for(self.classification)
        guard(self.classification, self.lane)
        # Fail here, not at the wire. Constructing a client whose lane has no
        # credentials meant the upload ran, rendered pages, and only then
        # reported the problem — after the person had already waited.
        missing = missing_for(self.classification)
        if missing:
            raise NotConfigured(missing)
        self.model = model or get_secret("model_id") or DEFAULT_MODEL
        self.dpi = dpi
        self.usage = {"calls": 0, "input_tokens": 0, "output_tokens": 0, "pages": 0}

    # -- transport ----------------------------------------------------------
    def _send(self, image_png: bytes, prompt: str) -> str:
        guard(self.classification, self.lane)          # again, at the wire
        offline.assert_allowed("reading a pin map with the model")
        b64 = base64.standard_b64encode(image_png).decode("ascii")
        content = [
            {"type": "image",
             "source": {"type": "base64", "media_type": "image/png", "data": b64}},
            {"type": "text", "text": prompt},
        ]
        if self.lane == LANE_A:
            return self._send_anthropic(content)
        return self._send_bedrock(content)

    def _send_anthropic(self, content):
        key = get_secret("anthropic_api_key")
        if not key:
            raise NotConfigured(
                "No Anthropic API key. Settings -> Extraction to add one, or enter "
                "this harness by hand.")
        try:
            import anthropic
        except ImportError:
            raise NotConfigured(
                "The 'anthropic' package is not installed in this build. "
                "Run: pip install anthropic")
        client = anthropic.Anthropic(api_key=key)
        resp = client.messages.create(
            model=self.model, max_tokens=8000,
            messages=[{"role": "user", "content": content}])
        self.usage["calls"] += 1
        self.usage["input_tokens"] += getattr(resp.usage, "input_tokens", 0) or 0
        self.usage["output_tokens"] += getattr(resp.usage, "output_tokens", 0) or 0
        return "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")

    def _send_bedrock(self, content):
        region = get_secret("bedrock_region")
        model_id = get_secret("bedrock_model_id")
        if not (region and model_id):
            raise NotConfigured(
                "Lane B is not configured. Controlled drawings need Claude via "
                "Bedrock in AWS GovCloud - set the region and model id in "
                "Settings -> Extraction. Until then, enter controlled harnesses "
                "by hand.")
        try:
            import boto3
        except ImportError:
            raise NotConfigured("The 'boto3' package is not installed in this build.")
        body = {"anthropic_version": "bedrock-2023-05-31", "max_tokens": 8000,
                "messages": [{"role": "user", "content": content}]}
        client = boto3.client("bedrock-runtime", region_name=region)
        resp = client.invoke_model(modelId=model_id, body=json.dumps(body))
        payload = json.loads(resp["body"].read())
        self.usage["calls"] += 1
        usage = payload.get("usage", {})
        self.usage["input_tokens"] += usage.get("input_tokens", 0)
        self.usage["output_tokens"] += usage.get("output_tokens", 0)
        return "".join(b.get("text", "") for b in payload.get("content", []))

    # -- the one job --------------------------------------------------------
    def read_pin_maps(self, pdf_path, pages, meta=None):
        """
        Read the wire list off the given sheets. Returns a list of wire dicts,
        each carrying `source` so the review table can show what came from the
        model versus what a person typed.
        """
        if not extract.renderer_available():
            raise NotConfigured(extract.RENDERER_MISSING)
        wires = []
        for page_no in pages:
            png_path = extract.render_page(pdf_path, page_no, dpi=self.dpi)
            if not png_path:
                continue
            with open(png_path, "rb") as fh:
                png = fh.read()
            self.usage["pages"] += 1
            data = _json_from(self._send(png, PIN_MAP_PROMPT))
            for w in data.get("wires", []):
                if not (w.get("from_end") or w.get("to_end")):
                    continue
                wires.append({
                    "signal":   (w.get("signal") or "").strip(),
                    "awg":      str(w.get("awg") or "").strip(),
                    "color":    "-",
                    "cable":    (w.get("cable") or "").strip().upper(),
                    "run_ref":  (w.get("run_ref") or "").strip(),
                    "from_end": (w.get("from_end") or "").strip(),
                    "from_pin": str(w.get("from_pin") or "").strip(),
                    "to_end":   (w.get("to_end") or "").strip(),
                    "to_pin":   str(w.get("to_pin") or "").strip(),
                    "term_source": "", "term_dest": "",
                    "note":     (w.get("note") or "").strip(),
                    "sheet":    page_no,
                    "source":   f"model:{self.lane}",
                })
        # renumber in reading order
        for i, w in enumerate(wires, start=1):
            w["wire_no"] = i
        return wires

    def read_parts(self, pdf_path, pages, meta=None):
        """
        Read the parts list off the given sheets.

        This is the tier that makes the program's reach match what a person gets
        by handing the drawing to Claude directly. The text-layer parser only
        knows the table shapes it has been taught, and there are as many shapes
        as there are primes; the local image reader is free but reads about three
        words in four. This reads what is on the page.

        It is the LAST tier for a reason: it costs money per sheet, and the two
        free passes above it are right most of the time. It never runs on a
        controlled project — the lane gate in _send refuses that outright.
        """
        from . import render as _renderer
        if not _renderer.available():
            raise NotConfigured(extract.RENDERER_MISSING)
        parts, sheets_read = [], []
        for page_no in pages:
            png_path = extract.render_page(pdf_path, page_no, dpi=self.dpi)
            if not png_path:
                continue
            with open(png_path, "rb") as fh:
                png = fh.read()
            self.usage["pages"] += 1
            data = _json_from(self._send(png, PARTS_PROMPT))
            if data.get("no_parts_list"):
                continue
            rows = data.get("parts") or []
            if rows:
                sheets_read.append(page_no)
            for r in rows:
                pn = (r.get("pn") or "").strip()
                if not pn:
                    continue
                qty, uom = _qty_and_uom(r.get("qty"), r.get("uom"))
                category, std_uom = partnum.classify(pn)
                parts.append({
                    "item": str(r.get("item") or "").strip(),
                    "pn": pn,
                    "category": category or "Other",
                    "uom": uom or std_uom or "EA",
                    "qty": qty,
                    "description": (r.get("description") or "").strip(),
                    "mfg": (r.get("mfg") or "").strip(),
                    "cage": (r.get("cage") or "").strip(),
                    "family": "",
                    "note": (r.get("note") or "").strip(),
                    "sheet": page_no,
                    "source": f"model:{self.lane}",
                })
        return {"parts": parts, "sheets": sheets_read}

    def cost_note(self):
        u = self.usage
        return (f"{u['calls']} model call(s), {u['pages']} page(s), "
                f"{u['input_tokens']} in / {u['output_tokens']} out tokens "
                f"via {self.lane}")
