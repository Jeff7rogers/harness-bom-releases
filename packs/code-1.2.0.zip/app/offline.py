"""
offline.py — the network kill switch.

WHY THIS IS NOT A FLAG
----------------------
A checkbox that call sites are supposed to consult is worth nothing: it
protects only the paths someone remembered to guard, and it stops protecting
the day a library starts making its own request. So the enforcement here is at
the socket layer. When the lock is engaged, `socket.socket.connect` refuses
every address that is not loopback, and `socket.getaddrinfo` refuses to resolve
any name that is not local — so the program cannot even ask a DNS server what
a hostname is, which is itself a disclosure.

That covers everything in the process by construction: urllib, the anthropic
SDK's httpx, boto3's urllib3, and anything added later by anyone.

The named call sites still check `assert_allowed()` first. Not for safety — the
socket layer is the safety — but so a blocked action explains itself in a
sentence instead of surfacing as a connection error.

WHAT IT DOES NOT COVER
----------------------
This governs one program. It does not govern the computer. A drawing you put in
a folder that OneDrive, iCloud, Dropbox or a backup agent syncs will leave the
machine no matter what this module does, and so will an exported workbook you
email. The lock is one control among the ones you already have; it is not a
substitute for where the files live.

WHEN IT ENGAGES
---------------
Automatically, whenever any project in the database is classified `controlled`.
It re-engages on every start: a release lasts for the run of the program and is
not remembered, because the safe state should be the one you get by default and
the unsafe one should cost a deliberate act every time.

Independently of the lock, `controlled` projects are refused the model tier and
the distributor lookups, always, lock or no lock. The lock is the belt; that
refusal is the braces.
"""
import datetime
import ipaddress
import os
import socket
import threading

APP = "HarnessBOM"

_lock = threading.RLock()
_state = {
    "engaged": False,
    "why": "",
    "since": None,
    "released_by_user": False,     # cleared on restart, never persisted
    "blocked": 0,
    "allowed": 0,
}

# Captured once, at import, before anything has a chance to wrap them.
_real_connect = socket.socket.connect
_real_connect_ex = socket.socket.connect_ex
_real_getaddrinfo = socket.getaddrinfo
_installed = False


class EgressBlocked(OSError):
    """An outbound connection was refused because the offline lock is on."""


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------
def engaged() -> bool:
    return _state["engaged"]


def status() -> dict:
    return dict(_state)


def engage(why="", user=""):
    with _lock:
        if not _state["engaged"]:
            _state["engaged"] = True
            _state["since"] = datetime.datetime.now().isoformat(timespec="seconds")
            _record("—", 0, f"LOCK ENGAGED: {why}", None, user)
        _state["why"] = why or _state["why"]


def release(user="", why=""):
    with _lock:
        if _state["engaged"]:
            _record("—", 0, f"LOCK RELEASED: {why or 'no reason given'}", None, user)
        _state["engaged"] = False
        _state["released_by_user"] = True
        _state["why"] = ""
        _state["since"] = None


def sync(conn, force_check=True):
    """
    Engage the lock if the database holds any controlled project.

    Called on every request. Cheap: one indexed count. A project that turns
    controlled mid-session — which is exactly what happens when the scanner
    finds a determination on an uploaded drawing — locks the program on the very
    next page load, without anyone having to notice.
    """
    try:
        n = conn.execute(
            "SELECT COUNT(*) AS n FROM project WHERE classification = 'controlled'"
        ).fetchone()["n"]
    except Exception:
        return engaged()
    if n and not _state["released_by_user"]:
        engage(f"{n} controlled project(s) in this database")
    elif not n and not _state["released_by_user"]:
        # No controlled work left; nothing to hold the lock for.
        with _lock:
            _state["engaged"] = False
            _state["why"] = ""
            _state["since"] = None
    return engaged()


def controlled_count(conn) -> int:
    try:
        return conn.execute(
            "SELECT COUNT(*) AS n FROM project WHERE classification = 'controlled'"
        ).fetchone()["n"]
    except Exception:
        return 0


def assert_allowed(purpose: str):
    """
    Called at the top of every deliberate outbound action, so a refusal reads as
    a sentence rather than as a socket error.
    """
    if _state["engaged"]:
        # Record it here as well as at the socket. A refusal caught this early
        # never reaches a socket, so without this line the log would show only
        # the attempts that got further — and an empty log would read as "it
        # never tried" when the truth is "it was stopped at the door".
        _state["blocked"] += 1
        _record("—", 0, f"refused: {purpose}", False)
        raise EgressBlocked(
            f"The offline lock is on, so {purpose} did not happen and nothing left "
            f"this computer. The lock engages by itself while any project is marked "
            f"controlled. Network › Unlock to turn it off for this session.")


# ---------------------------------------------------------------------------
# The record
# ---------------------------------------------------------------------------
def log_path():
    base = (os.environ.get("HARNESSBOM_DATA")
            or os.path.dirname(os.environ.get("HARNESSBOM_DB", "") or "")
            or _default_dir())
    os.makedirs(base, exist_ok=True)
    return os.path.join(base, "egress.log")


def _default_dir():
    if os.name == "nt":
        root = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    else:
        root = (os.environ.get("XDG_DATA_HOME")
                or os.path.join(os.path.expanduser("~"), ".local", "share"))
    return os.path.join(root, APP)


def _record(host, port, purpose, allowed, user=""):
    """
    Append one line to the egress log.

    A plain text file rather than a database table, deliberately: this is
    written from inside a socket call, and re-entering sqlite from there is a
    good way to deadlock a program. A flat file is append-only, survives a
    crash, and an auditor can read it without the app.
    """
    mark = {True: "ALLOWED", False: "BLOCKED", None: "-"}[allowed]
    line = (f"{datetime.datetime.now().isoformat(timespec='seconds')}\t{mark}\t"
            f"{host}:{port}\t{purpose}\t{user or os.environ.get('USERNAME') or os.environ.get('USER') or ''}\n")
    try:
        with open(log_path(), "a", encoding="utf-8") as fh:
            fh.write(line)
    except OSError:
        pass          # never let logging break the thing being logged


def recent(n=200):
    try:
        with open(log_path(), "r", encoding="utf-8") as fh:
            lines = fh.readlines()
    except OSError:
        return []
    out = []
    for raw in lines[-n:]:
        bits = raw.rstrip("\n").split("\t")
        while len(bits) < 5:
            bits.append("")
        out.append({"ts": bits[0], "verdict": bits[1], "where": bits[2],
                    "purpose": bits[3], "user": bits[4]})
    out.reverse()
    return out


# ---------------------------------------------------------------------------
# Enforcement
# ---------------------------------------------------------------------------
def _is_local(host) -> bool:
    if host is None:
        return True
    if isinstance(host, bytes):
        host = host.decode("utf-8", "replace")
    if not isinstance(host, str):
        return False
    h = host.strip().strip("[]").lower()
    if h in ("", "localhost", "localhost.localdomain", "ip6-localhost"):
        return True
    try:
        return ipaddress.ip_address(h).is_loopback
    except ValueError:
        return False


def _hostport(address):
    if isinstance(address, (tuple, list)) and address:
        return address[0], (address[1] if len(address) > 1 else 0)
    return str(address), 0          # AF_UNIX path, and other odd families


def install():
    """
    Wrap the socket primitives. Done once, at import, whatever the lock state —
    so there is no window in which the program is running unpatched, and turning
    the lock on is a flag flip rather than a race against live connections.
    """
    global _installed
    if _installed:
        return

    def guarded_connect(self, address, *a, **kw):
        host, port = _hostport(address)
        if not _is_local(host):
            if _state["engaged"]:
                _state["blocked"] += 1
                _record(host, port, "connect", False)
                raise EgressBlocked(
                    f"Offline lock: refused a connection to {host}:{port}. "
                    f"Nothing left this computer.")
            _state["allowed"] += 1
            _record(host, port, "connect", True)
        return _real_connect(self, address, *a, **kw)

    def guarded_connect_ex(self, address, *a, **kw):
        host, port = _hostport(address)
        if not _is_local(host) and _state["engaged"]:
            _state["blocked"] += 1
            _record(host, port, "connect_ex", False)
            return 13               # EACCES, the answer a firewall would give
        return _real_connect_ex(self, address, *a, **kw)

    def guarded_getaddrinfo(host, port, *a, **kw):
        # Resolving a name tells a DNS server what you are looking up. Under the
        # lock that is itself a disclosure, so it is refused too.
        if not _is_local(host) and _state["engaged"]:
            _state["blocked"] += 1
            _record(host, port or 0, "dns", False)
            raise EgressBlocked(
                f"Offline lock: refused to look up {host}. Not even the name was sent.")
        return _real_getaddrinfo(host, port, *a, **kw)

    socket.socket.connect = guarded_connect
    socket.socket.connect_ex = guarded_connect_ex
    socket.getaddrinfo = guarded_getaddrinfo
    _installed = True


install()
