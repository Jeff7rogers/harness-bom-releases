"""
render.py — turning a page, or a rectangle of one, into a picture.

WHY THIS EXISTS SEPARATELY
--------------------------
Rendering used to mean shelling out to `pdftoppm` from Poppler, and Poppler is
not installed on a Mac and was not installed on several PCs. When it was absent
the OCR tier and the pin-map reader simply produced nothing, which is the worst
failure mode this program has: a BOM that is quietly short.

So rendering now prefers **pypdfium2**, a pip wheel that carries Chrome's PDF
engine inside it. It has no system dependencies at all, installs on every
machine the program runs on, renders in-process rather than through a
subprocess, and is roughly ten times faster on the pages we care about. Poppler
is kept as a fallback for machines that already have it.

The practical effect: half the "two free programs are missing" problem is gone.
Only Tesseract is still an outside dependency, and tools.py installs that.

CROPPING
--------
`box` is (x, y, w, h) in PIXELS AT `dpi`, origin top-left — Poppler's
convention, because that is what the callers were written against. pdfium wants
points cut off each edge instead, so the conversion lives here and nowhere else.

Cropping in the renderer rather than afterwards is what makes the OCR tier
usable: an E-size sheet at 400 dpi is a 240-megapixel image, and the parts list
on it is a few megapixels.
"""
import os
import struct
import subprocess
import tempfile
import zlib

# Resolved once. Both are cheap to check and neither can change while running.
_STATE = {"pdfium": None, "poppler": None}


def _pdfium():
    """The pypdfium2 module, or None. Import failure is not an error here."""
    if _STATE["pdfium"] is None:
        try:
            import pypdfium2                                  # noqa: F401
            _STATE["pdfium"] = pypdfium2
        except Exception:                                     # pragma: no cover
            _STATE["pdfium"] = False
    return _STATE["pdfium"] or None


def _poppler():
    """Path to pdftoppm, or ''. Imported late: ocr imports this module."""
    if _STATE["poppler"] is None:
        from . import ocr
        _STATE["poppler"] = ocr.tool("pdftoppm")
    return _STATE["poppler"]


def backend() -> str:
    """Which renderer will be used: 'pdfium', 'poppler', or '' for none."""
    if _pdfium():
        return "pdfium"
    return "poppler" if _poppler() else ""


def available() -> bool:
    return bool(backend())


def describe() -> dict:
    """What is here, for the Readers screen. Never raises."""
    out = {"backend": backend(), "pdfium": "", "poppler": _poppler()}
    mod = _pdfium()
    if mod:
        try:
            from importlib.metadata import version
            out["pdfium"] = version("pypdfium2")
        except Exception:                                     # pragma: no cover
            out["pdfium"] = "present"
    return out


def reset():
    """Forget what was found. Called after installing something."""
    _STATE["pdfium"] = None
    _STATE["poppler"] = None


# ---------------------------------------------------------------------------
def render(pdf_path, page_no, dpi=150, out_dir=None, box=None):
    """
    Render page `page_no` (1-based) to a PNG and return its path, or None.

    None means no renderer at all, or a page that would not render. Callers
    must check and say so rather than reporting an empty result.
    """
    out_dir = out_dir or tempfile.mkdtemp(prefix="harnessbom-render-")
    os.makedirs(out_dir, exist_ok=True)
    if _pdfium():
        png = _render_pdfium(pdf_path, page_no, dpi, out_dir, box)
        if png:
            return png
        # A page pdfium cannot draw is worth one attempt with the other engine.
    return _render_poppler(pdf_path, page_no, dpi, out_dir, box) if _poppler() else None


def _write_grey_png(buf, width, height, stride, path):
    """
    Write an 8-bit greyscale PNG without Pillow.

    Pillow is deliberately not a dependency: the frozen build excludes it, and
    adding an imaging library to write a file format that is thirty lines of
    zlib would be a poor trade. Greyscale because that is what OCR reads, and
    it is a third of the bytes of RGB.
    """
    raw = bytearray()
    for y in range(height):
        row = bytes(buf[y * stride:y * stride + width])
        raw.append(0)                                   # filter type 0: none
        raw += row

    def chunk(tag, data):
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    png = (b"\x89PNG\r\n\x1a\n"
           + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 0, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(bytes(raw), 6))
           + chunk(b"IEND", b""))
    with open(path, "wb") as fh:
        fh.write(png)
    return path


def _render_pdfium(pdf_path, page_no, dpi, out_dir, box):
    pdfium = _pdfium()
    scale = dpi / 72.0
    try:
        doc = pdfium.PdfDocument(pdf_path)
        try:
            if not (1 <= page_no <= len(doc)):
                return None
            page = doc[page_no - 1]
            w_pt, h_pt = page.get_size()
            crop = (0, 0, 0, 0)
            if box:
                x, y, w, h = (max(0.0, float(v)) for v in box)
                left = x / scale
                top = y / scale
                right = max(0.0, w_pt - (x + w) / scale)
                bottom = max(0.0, h_pt - (y + h) / scale)
                # A crop that meets or crosses itself renders nothing; ignoring
                # it and rendering the whole page is better than returning None,
                # because the caller can still read something.
                if left + right < w_pt - 1 and top + bottom < h_pt - 1:
                    crop = (left, bottom, right, top)
            png = os.path.join(out_dir, f"p{page_no}_{dpi}" + ("_crop" if box else "") + ".png")
            bmp = page.render(scale=scale, crop=crop, grayscale=True)
            try:
                _write_grey_png(bmp.buffer, bmp.width, bmp.height, bmp.stride, png)
            finally:
                bmp.close()
            return png if os.path.exists(png) else None
        finally:
            doc.close()
    except Exception:
        return None


def _render_poppler(pdf_path, page_no, dpi, out_dir, box):
    stem = os.path.join(out_dir, f"pp{page_no}_{dpi}" + ("_crop" if box else ""))
    cmd = [_poppler(), "-r", str(dpi), "-f", str(page_no), "-l", str(page_no), "-png"]
    if box:
        x, y, w, h = (max(0, int(v)) for v in box)
        cmd += ["-x", str(x), "-y", str(y), "-W", str(w), "-H", str(h)]
    cmd += [pdf_path, stem]
    try:
        subprocess.run(cmd, check=True, capture_output=True, timeout=180)
    except (FileNotFoundError, subprocess.SubprocessError):
        return None
    for suffix in (f"-{page_no}.png", f"-{page_no:02d}.png", f"-{page_no:03d}.png", ".png"):
        if os.path.exists(stem + suffix):
            return stem + suffix
    return None
