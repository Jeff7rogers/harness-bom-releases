"""
extract.py — read a harness drawing PDF into structured data.

Three tiers, cheapest first, and each one reports what it actually managed:

  1. SCAN      export-control markings (scanner.py). Always runs first. If the
               drawing carries an affirmative determination, extraction stops
               here regardless of what else is configured.
  2. TEXT      the PDF's own text layer. Title block and the bill-of-materials
               table parse deterministically — no model, no key, no network.
               On the Vast HAVEN drawings this recovers the entire BOM.
  3. VISION    rendered pages through a model, for pin maps. The text layer
               collapses adjacent contact numbers (16 and 3 extract as "163"),
               so wire lists are NOT safe to read from text and this tier is
               the only honest way to get them.

Tier 3 is optional and is the only part that costs anything. Everything the
app needs to be useful — parts, quantities, drawing metadata — comes out of
tier 2 for free.
"""
import os
import re
import subprocess
import shutil
import tempfile

from . import partnum, scanner, ocr

# ---------------------------------------------------------------------------
# Title block
# ---------------------------------------------------------------------------
_DRAWING_NO = re.compile(r"(?<!\d)(\d{7,9})(?!\d)")
_DESCRIPTOR = re.compile(r"DESCRIPTOR\s*:?\s*(.+?)(?=\s{2,}|AUTHOR|DESIGNER|REVISION|$)", re.I)
_LOCATION   = re.compile(r"LOCATION\s*:?\s*(.+?)(?=\s{2,}|DESCRIPTOR|$)", re.I)
_AUTHOR     = re.compile(r"(?:AUTHOR|DESIGNER|DRAWN\s+BY)\s*:?\s*([A-Z][A-Za-z.\s]{1,28}?)(?=\s{2,}|DATE|HARNESS|$)", re.I)
_DATE       = re.compile(r"DATE\s*:?\s*(\d{1,4}[/-]\d{1,2}[/-]\d{1,4})", re.I)
_PAGES      = re.compile(r"PAGE\s*(\d+)\s*/\s*(\d+)", re.I)
_REV_WORD   = re.compile(r"\bREV(?:ISION)?\b", re.I)

# ---------------------------------------------------------------------------
# Bill of materials
# ---------------------------------------------------------------------------
_BOM_HEADING = re.compile(
    r"BILL\s+OF\s+MATERIALS|(?:ALTERED\s+ITEM\s+)?PARTS\s+LIST|PARTS\s+LIST", re.I)
_COLUMN_ROW = re.compile(
    r"ITEM\s*NUMBER|FIND\s*NO|PART\s*NUMBER.*DESCRIPTION", re.I)
# a quantity token: 1 | 12 | 32" | 106" | 2.5 | 462mm | AR
_QTY = re.compile(r'^(\d+(?:\.\d+)?)\s*(")?(?:mm|MM)?$')


def _is_name_token(tok: str) -> bool:
    """Part of a trailing manufacturer name (kerning makes these 1-2 chars)."""
    return bool(tok) and tok.replace(".", "").replace("-", "").isalpha()


def _parse_qty(tok: str):
    """'177\"' -> (177.0, 'IN'); '6' -> (6.0, 'EA'); 'AR' -> (0.0, 'EA')."""
    tok = tok.strip()
    if tok.upper() == "AR":                      # as required
        return 0.0, "EA"
    m = _QTY.match(tok)
    if not m:
        return None, None
    qty = float(m.group(1))
    if m.group(2) == '"':
        return qty, "IN"
    if tok.lower().endswith("mm"):
        return round(qty / 25.4, 3), "IN"
    return qty, "EA"


def parse_bom_row(line: str):
    """
    One BOM table row -> dict, or None if the line is not a row.

    Read right to left: the manufacturer is the trailing run of alphabetic
    tokens, the quantity is the first numeric token inside it, and whatever
    remains on the left holds the item number, part number and description.
    That order matters — reading left to right breaks on 'SIZE 9 6 Multiple',
    where a size in the description looks exactly like a quantity.
    """
    toks = (line or "").split()
    if len(toks) < 4:
        return None
    if not toks[0].rstrip(".").isdigit():
        return None
    item = toks[0].rstrip(".")
    rest = toks[1:]

    i = len(rest) - 1
    mfg = []
    while i >= 0 and _is_name_token(rest[i]):
        mfg.insert(0, rest[i])
        i -= 1
    if i < 0:
        return None
    qty, uom = _parse_qty(rest[i])
    if qty is None:
        return None

    body = " ".join(rest[:i])
    hit = partnum.first(body)
    if not hit:
        return None

    # description = body minus the part number, however it was spelled
    flat_body = partnum.despace(body)
    pos = flat_body.find(hit["pn"])
    desc_flat = flat_body[pos + len(hit["pn"]):] if pos >= 0 else flat_body
    # recover a readable description from the original token run
    desc_raw = body
    for cut in (hit["pn"], hit["pn"].lower()):
        idx = desc_raw.replace(" ", "").find(cut)
        if idx >= 0:
            break
    desc = partnum.dekern(_strip_leading_pn(desc_raw, hit["pn"]))

    return {
        "item": item,
        "pn": hit["pn"],
        "category": hit["category"],
        "uom": uom if uom != "EA" or hit["uom"] == "EA" else hit["uom"],
        "qty": qty,
        "description": desc or "",
        "mfg": partnum.dekern(" ".join(mfg)),
        "family": hit["family"],
        "source": "text-layer",
    }


def _strip_leading_pn(body: str, pn: str) -> str:
    """Drop the part number from the front of a row body, kerned or not."""
    flat, out, consumed = partnum.despace(pn), [], 0
    for tok in body.split():
        if consumed < len(flat):
            chunk = partnum.despace(tok)
            if flat[consumed:consumed + len(chunk)] == chunk:
                consumed += len(chunk)
                continue
        out.append(tok)
    return " ".join(out)


# ---------------------------------------------------------------------------
# PDF plumbing
# ---------------------------------------------------------------------------
def page_texts(pdf_path: str):
    try:
        from pypdf import PdfReader
    except ImportError:                                      # pragma: no cover
        from PyPDF2 import PdfReader                         # type: ignore
    return [(p.extract_text() or "") for p in PdfReader(pdf_path).pages]


def renderer_available() -> bool:
    """Is a page renderer on this machine? Not cached: Settings ▸ Readers can
    install one while the program is running, and a stale 'no' there would send
    someone back to hand entry for the rest of the session."""
    from . import render as _renderer
    return _renderer.available()


_RENDERER = {"checked": None}

RENDERER_MISSING = (
    "No page renderer on this PC. Reading a pin map means turning the sheet into "
    "a picture first, and nothing on this machine can do that. Settings ▸ Readers "
    "installs it. Until then the wire list has to be entered by hand — the parts "
    "list and title block do not need it and are unaffected.")


def render_page(pdf_path: str, page_no: int, dpi: int = 150, out_dir: str = None):
    """
    Render one page to PNG. Returns the path, or None when no renderer exists.

    A None return used to be swallowed by the caller, which then reported zero
    conductors with no explanation - the same silent-failure shape as the missing
    API key. Callers must now check renderer_available() and say so.
    """
    from . import render as _renderer
    return _renderer.render(pdf_path, page_no, dpi, out_dir)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def extract_title_block(pages):
    """Drawing metadata from page 1. Anything not found is left blank for the
    review table rather than guessed."""
    first = pages[0] if pages else ""
    flat = " ".join(first.split())
    meta = {"drawing_no": "", "revision": "", "title": "", "location": "",
            "author": "", "dwg_date": "", "sheets": len(pages)}

    nums = _DRAWING_NO.findall(flat)
    if nums:
        # the drawing number repeats on every sheet; the most frequent 7-9
        # digit run across the whole document is a far better bet than the first
        allnums = _DRAWING_NO.findall(" ".join(" ".join(p.split()) for p in pages))
        meta["drawing_no"] = max(set(allnums), key=allnums.count)

    for key, rx in (("title", _DESCRIPTOR), ("location", _LOCATION), ("author", _AUTHOR)):
        m = rx.search(flat)
        if m:
            value = partnum.dekern(m.group(1)).strip(" ,-")
            # These fields print on the workbook cover, so a miss must stay
            # blank rather than carry half a page of notes into it. One drawing
            # put 1,900 characters of vacuum-bakeout instructions in "location"
            # because the word appeared in a sentence and there was nothing to
            # stop the capture.
            if len(value) <= 60 and ". " not in value:
                meta[key] = value
    m = _DATE.search(flat)
    if m:
        meta["dwg_date"] = m.group(1)
    m = _PAGES.search(flat)
    if m:
        meta["sheets"] = int(m.group(2))

    # revision: a lone capital letter or '--' sitting near the word REVISION
    rm = _REV_WORD.search(flat)
    if rm:
        tail = flat[rm.end():rm.end() + 40]
        rv = re.match(r"\s*([A-Z]{1,2}|--|-)\b", tail)
        if rv:
            meta["revision"] = rv.group(1)

    # The drawing number is often glued to the end of the descriptor, sometimes
    # with the revision letter in between ("...ADAPTERA 001262004"). Strip the
    # number always; strip a trailing letter ONLY when it matches the revision
    # we detected - otherwise "VCU_3, LSB" loses its B.
    if meta["drawing_no"] and meta["title"]:
        t = re.sub(r"\s*" + re.escape(meta["drawing_no"]) + r"\s*$", "", meta["title"]).strip()
        rev = meta.get("revision", "")
        if rev and len(rev) == 1 and t.endswith(rev) and len(t) > 1:
            t = t[:-1]
        meta["title"] = t.strip(" ,-")
    return meta


# ---------------------------------------------------------------------------
# The MIL-STD-100 tabulated parts list
# ---------------------------------------------------------------------------
# A second table shape entirely, and common: a separate PL document, one page
# per dash number, columns running
#
#   FIND NO | QTY REQD | UM | CAGE NO | DRAWING OR DOCUMENT NO | PART OR
#   IDENTIFYING NUMBER | NOMENCLATURE OR DESCRIPTION | REF DES | NOTES
#
# Rows come out of the text layer like this, with the unit of measure and the
# CAGE code run together because they are adjacent columns with no gap:
#
#   1 1 EA38JE7 8279258 8279258-1 FLEX CABLE, FPM, DHA S
#
# The quantity is second from the left here, where the other format has it
# second from the right. Reading one with the other's rules finds nothing, which
# is exactly what happened: three drawings with flawless text layers returning
# zero parts, and someone reasonably concluding the program was broken.
#
# This pass only runs on a page whose heading says it is one of these, so no
# drawing that reads correctly today is touched by it.
_TAB_HEADING = re.compile(r"FIND\s*NO.*QTY\s*REQD|TABULATED\s*PARTS\s*LIST", re.I | re.S)
_TAB_UM_CAGE = re.compile(r"^(EA|IN|FT|LB|OZ|PR|SE|SH|YD|RL|AR|CM|MM|MR|GA)([0-9A-Z]{5})?$", re.I)


def parse_tabulated_row(line: str):
    """One row of a tabulated parts list -> dict, or None."""
    toks = (line or "").split()
    if len(toks) < 4:
        return None
    if not toks[0].rstrip(".").isdigit():
        return None
    item = toks[0].rstrip(".")

    qty, uom = _parse_qty(toks[1])
    if qty is None:
        return None

    rest = toks[2:]
    m = _TAB_UM_CAGE.match(rest[0]) if rest else None
    if m:
        uom = m.group(1).upper()
        rest = rest[1:]
    # Anything that is not a recognised unit here means this is not one of these
    # rows — better to read nothing than to read a note as a part.
    elif rest and rest[0].upper() not in ("EA", "IN", "FT", "AR"):
        return None

    body = " ".join(rest)

    # The part number is whichever of the leading identifier tokens is the more
    # specific: these rows carry the drawing number first and the part number
    # after it, and on a prime's own drawing the two differ only by the dash
    # suffix. A MIL-spec number, where there is one, still wins outright.
    hit = partnum.first(body)
    if hit:
        pn, family, category = hit["pn"], hit["family"], hit["category"]
        uom = uom or hit["uom"]
        tail = _strip_leading_pn(body, pn)
    else:
        ids, i = [], 0
        while i < len(rest) and _looks_like_identifier(rest[i]):
            ids.append(rest[i])
            i += 1
        if not ids:
            return None
        pn = ids[-1]
        family, category = "", (partnum.classify(pn)[0] or "Other")
        tail = " ".join(rest[i:])

    # A trailing single letter is a note reference ("S"), not part of the name.
    desc = re.sub(r"\s+[A-Z]$", "", partnum.dekern(tail).strip())

    return {
        "item": item,
        "pn": pn,
        "category": category,
        "uom": uom or "EA",
        "qty": qty,
        "description": desc or "",
        "mfg": "",
        "family": family,
        "source": "text-layer",
    }


def _looks_like_identifier(tok: str) -> bool:
    """A drawing or part number in an identifier column: digits, upper case and
    dashes only, and long enough not to be a note marker or a column of ones."""
    t = tok.strip().rstrip(",")
    return (len(t) >= 5 and any(c.isdigit() for c in t)
            and all(c.isdigit() or c.isupper() or c in "-/." for c in t))


def extract_parts(pages):
    """Every BOM row found anywhere in the document, in either table shape."""
    rows, seen = [], set()

    def keep(row):
        key = (row["pn"], row["item"])
        if key in seen:
            return
        seen.add(key)
        rows.append(row)

    for text in pages:
        lines = text.split("\n")
        in_table = False
        found_here = False
        for ln in lines:
            if _BOM_HEADING.search(ln):
                in_table = True
                continue
            if _COLUMN_ROW.search(ln):
                in_table = True
                continue
            if not in_table:
                continue
            row = parse_bom_row(ln)
            if row:
                found_here = True
                keep(row)

        # Only when the usual reading found nothing on this page, and only on a
        # page that announces itself as a tabulated parts list.
        if not found_here and _TAB_HEADING.search(text):
            for ln in lines:
                row = parse_tabulated_row(ln)
                if row:
                    keep(row)
    return rows


MAX_MODEL_SHEETS = 4

_PARTS_HINT = re.compile(
    r"PARTS\s*LIST|BILL\s+OF\s+MATERIAL|FIND\s*\n?\s*NO|ITEM\s*\n?\s*NO|QTY\s*\n?\s*REQD",
    re.I)


def parts_list_pages(pages, cap=MAX_MODEL_SHEETS):
    """
    Which sheets to pay to have read, best first.

    A sheet whose text mentions a parts list is the obvious candidate even when
    the table itself is line-work — the heading is often typed and the rows are
    not. Failing that, the first and last sheets, which is where every drawing
    standard puts one. Capped, because this is the tier that costs money and a
    24-sheet set would otherwise quietly become a 24-sheet bill.
    """
    hinted = [i for i, text in enumerate(pages, start=1) if _PARTS_HINT.search(text or "")]
    if hinted:
        return hinted[:cap]
    n = len(pages)
    if n <= cap:
        return list(range(1, n + 1))
    return sorted({1, 2, n - 1, n})[:cap]


def extract(pdf_path: str, allow_vision: bool = False, llm=None, allow_ocr: bool = False):
    """
    Read a drawing.

    Returns:
        {scan, blocked, meta, parts, wires, pin_map_pages, notes, method}

    `blocked` is True when the export-control scanner found an affirmative
    determination. That refuses the MODEL tier outright and for good — no
    argument, no override, regardless of what the caller passed.

    It does not refuse the text-layer pass. That pass opens a file and reads
    strings out of it on this machine; it makes no network call and has nothing
    to send anywhere. Stopping it was over-caution on my part, and it cost the
    one thing an ITAR shop most wants automated: the parts list off its own
    controlled drawings. The controlled data never moves either way, so the
    honest line is at the network, not at the parser.
    """
    # meta always carries the full key set, even on the blocked path, so
    # callers never have to guard every field access.
    result = {"path": pdf_path, "scan": None, "blocked": False,
              "meta": {"drawing_no": "", "revision": "", "title": "", "location": "",
                       "author": "", "dwg_date": "", "sheets": 0},
              "parts": [], "wires": [], "pin_map_pages": [], "notes": [],
              "method": [], "ocr_conf": 0.0}

    result["scan"] = scanner.scan_pdf(pdf_path)
    if result["scan"]["verdict"] == "block":
        result["blocked"] = True
        allow_vision, llm = False, None          # not negotiable, whatever was asked
        result["notes"].append(
            "Export-control determination found on this drawing. The parts list and "
            "title block below were read on this PC, offline — no network call was "
            "made and nothing was sent anywhere. The model pass and distributor "
            "pricing are refused for this project and cannot be enabled.")

    pages = page_texts(pdf_path)
    result["method"].append("text-layer")
    result["meta"] = extract_title_block(pages)
    result["parts"] = extract_parts(pages)


    # which sheets carry a pin map — those are the ones vision has to read
    for i, text in enumerate(pages, start=1):
        if re.search(r"PIN\s*TO\s*PIN|WIRE\s*RUN|CONNECTION\s*(LIST|DIAGRAM)", text, re.I):
            result["pin_map_pages"].append(i)
    if result["pin_map_pages"]:
        result["notes"].append(
            f"Pin-to-pin mapping found on sheet(s) {', '.join(map(str, result['pin_map_pages']))}. "
            "Contact numbers cannot be read reliably from the text layer — adjacent "
            "numbers run together — so the wire list needs the drawing read visually.")

    # --- tier 2b: read the parts list off the drawing image, on this PC -------
    # Runs when the text layer found no parts, or when asked for outright. It is
    # permitted on controlled drawings precisely because it is local: Tesseract
    # makes no network call, so there is nothing for the lane gate to refuse.
    if allow_ocr and not result["parts"]:
        if not ocr.available():
            result["notes"].append(ocr.MISSING)
        else:
            try:
                got = ocr.read_parts(pdf_path)
            except Exception as exc:                 # a bad page must not lose the rest
                result["notes"].append(f"The drawing-image read failed: {exc}")
            else:
                result["parts"] = got["parts"]
                result["notes"].extend(got["notes"])
                result["ocr_conf"] = got["mean_conf"]
                if got["parts"]:
                    result["method"].append("ocr")

    # --- tier 3: have the model read the parts list --------------------------
    # Last, and only when both free passes came back with nothing. Costs money
    # per sheet, so it reads the sheets most likely to carry the table rather
    # than the whole document, and says in the notes what it spent it on. The
    # lane gate inside the client refuses this outright on a controlled project.
    if allow_vision and llm is not None and not result["parts"]:
        pages_to_read = parts_list_pages(pages)
        try:
            got = llm.read_parts(pdf_path, pages_to_read, result["meta"])
        except Exception as exc:
            result["notes"].append(f"The model pass over the parts list failed: {exc}")
        else:
            result["parts"] = got["parts"]
            if got["parts"]:
                result["method"].append("model-parts")
                result["notes"].append(
                    f"The parts list was read by the model off sheet(s) "
                    f"{', '.join(map(str, got['sheets']))}, because neither the text layer "
                    f"nor the image reader found a table. Check every row against the "
                    f"drawing — this is the one pass with nothing free underneath it to "
                    f"cross-check against.")
            else:
                result["notes"].append(
                    f"The model read sheet(s) {', '.join(map(str, pages_to_read))} and found "
                    f"no parts list on them. If the table is on another sheet, or in a "
                    f"separate PL document, that is the file to upload.")

    # Said once, at the end, and only if nothing found anything. It used to be
    # said the moment the text layer came up empty, which left a drawing the
    # model went on to read correctly carrying a note telling the reviewer to
    # type it in by hand.
    if not result["parts"]:
        result["notes"].append(
            "No parts list was recognised. Either its table is in a layout nothing here "
            "knows yet, or this sheet genuinely has no parts list on it — on many programs "
            "the bill of materials is a separate PL document, and that is the file to "
            "upload. Enter the parts by hand, or send the drawing over so it can be taught.")

    if allow_vision and llm is not None and result["pin_map_pages"]:
        result["wires"] = llm.read_pin_maps(pdf_path, result["pin_map_pages"], result["meta"])
        result["method"].append("vision")

    return result
