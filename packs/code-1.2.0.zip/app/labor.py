"""
labor.py — termination counting, labor build-up and schedule.

Everything here reads its numbers from the `rate` table, so the shop tunes the
model from the Settings screen as real hours come in. Nothing is hard-coded.
"""
import math
import re
from collections import defaultdict

# Which rate key each termination type bills at. Matching is case-insensitive
# substring, first hit wins, so "Crimp, #22D socket contact" bills at op_crimp.
TERM_RATE_MAP = [
    ("d-sub",        "op_crimp_dsub"),
    ("dsub",         "op_crimp_dsub"),
    ("rj45",         "op_rj45"),
    ("usb",          "op_usb_solder"),
    ("ring lug",     "op_ring_lug"),
    ("ring-lug",     "op_ring_lug"),
    ("solder sleeve","op_solder_sleeve"),
    ("solder-sleeve","op_solder_sleeve"),
    ("lap splice",   "op_lap_splice"),
    ("splice",       "op_lap_splice"),
    ("cap & stow",   "op_cap_stow"),
    ("cap and stow", "op_cap_stow"),
    ("shield term",  "op_band_shield"),
    ("band",         "op_band_shield"),
    ("crimp",        "op_crimp"),
]

# Termination types that represent an actual crimp (for the headline crimp count).
CRIMP_TYPES = ("crimp",)

CABLE_CATEGORIES = ("Cable", "Wire")
CONNECTOR_CATEGORIES = ("Connector",)


def rate_key_for(term_type: str) -> str:
    t = (term_type or "").lower()
    for needle, key in TERM_RATE_MAP:
        if needle in t:
            return key
    return "op_crimp"


def termination_total(terminations) -> int:
    return sum(int(t["qty"]) for t in terminations)


def crimp_total(terminations) -> int:
    return sum(int(t["qty"]) for t in terminations
               if any(c in (t["term_type"] or "").lower() for c in CRIMP_TYPES))


def first_unit_minutes(rates, parts, wires, terminations, sheets=1):
    """
    Build up first-article minutes for one harness from the cycle-time table.

    Returns (total_minutes, breakdown) where breakdown is a list of
    (operation label, quantity, unit_minutes, minutes).
    """
    r = lambda k, d=0.0: float(rates.get(k, d))
    rows = []

    def add(label, qty, key):
        if qty <= 0:
            return
        unit = r(key)
        rows.append((label, qty, unit, round(qty * unit, 2)))

    n_wires = len(wires)
    n_ends = n_wires * 2
    # distinct cable part numbers actually referenced by the wire list
    cables = {(w["cable"] or "").strip().upper() for w in wires if (w["cable"] or "").strip()}
    n_cable_runs = _cable_run_count(wires)
    n_shields = n_cable_runs
    n_connectors = sum(int(p["qty"]) for p in parts if p["category"] in CONNECTOR_CATEGORIES)
    n_labels = sum(int(p["qty"]) for p in parts if p["category"] in ("Label", "Marker"))
    n_ties = sum(int(p["qty"]) for p in parts if p["category"] == "Tie Wrap")
    n_sleeve_sections = max(1, n_cable_runs // 2) if any(p["category"] == "Sleeving" for p in parts) else 0

    add("Work order, kit verification, drawing review", 1, "op_work_order")
    add("Cut & label wire from cut list", n_cable_runs, "op_cut_label")
    add("Inner-conductor break-out", n_cable_runs, "op_breakout")
    add("Strip & prep conductor ends", n_ends, "op_strip_prep")
    add("Shield prep", n_shields, "op_shield_prep")

    # terminations, billed by type
    for t in terminations:
        key = rate_key_for(t["term_type"])
        label = f"{t['term_type']} — {t['location']}" if t["location"] else t["term_type"]
        add(label, int(t["qty"]), key)

    # contacts still have to be inserted into the shell after crimping
    add("Insert contacts into connector bodies", crimp_total(terminations), "op_insert_contact")

    add("Install protective sleeving", n_sleeve_sections, "op_sleeving")
    add("Install ID labels", n_labels, "op_label")
    add("Backshell assembly + tape build-up", n_connectors, "op_backshell")
    add("Lacing / cable ties at transitions", n_ties, "op_tie")
    add("Continuity test (all conductors)", 1, "op_continuity")
    add("Hi-pot on power circuits", 1, "op_hipot")
    add("Class 3 visual inspection (100%)", 1, "op_visual")
    add("Serialize, log, bag & tag, ESD pack", 1, "op_pack")

    total = round(sum(x[3] for x in rows), 2)
    return total, rows


# M27500 encodes its conductor count in the part number:
#   M27500 - <AWG><plating><?><N><shield><jacket>     e.g. M27500-22SR2S23 -> 2 conductors
#                                     ^ N                  M27500-22SR3S23 -> 3 conductors
M27500_RE = re.compile(r"M27500-\s*\d{2}[A-Z]{2}(\d)", re.I)
# Cable families whose conductor count is not in the part number.
KNOWN_CONDUCTORS = {"E40424": 4, "E10424": 4, "E12424": 4, "E61424": 4}   # Cat5e 2-pair


def conductors_per_cable(pn: str):
    """
    How many conductors one physical run of this cable carries, or None if we
    cannot tell. Returning None is honest: the caller then treats the group as
    a single run rather than inventing a number.
    """
    pn = (pn or "").strip().upper()
    if not pn:
        return None
    if pn in KNOWN_CONDUCTORS:
        return KNOWN_CONDUCTORS[pn]
    m = M27500_RE.match(pn)
    if m:
        n = int(m.group(1))
        return n if n > 0 else None
    return None


def _cable_run_count(wires):
    """
    Number of physical cable runs. A twisted pair or triple is cut, broken out
    and shielded ONCE regardless of how many conductors it carries, so counting
    conductors here would over-bill break-out and shield prep — and grouping
    only by endpoints under-bills it, because six separate twisted pairs
    between the same two connectors are six cuts, not one.

    Precedence:
      1. an explicit run_ref on the wire (set by the tech or by extraction)
      2. the conductor count encoded in the cable part number
      3. one run per (cable, from_end, to_end) group
    """
    explicit = set()
    groups = defaultdict(list)
    loose = 0
    for w in wires:
        cable = (w["cable"] or "").strip().upper()
        run_ref = (_get(w, "run_ref") or "").strip()
        if run_ref:
            explicit.add((cable, run_ref))
            continue
        if not cable:
            loose += 1
            continue
        groups[(cable, (w["from_end"] or "").strip(), (w["to_end"] or "").strip())].append(w)

    total = len(explicit) + loose
    for (cable, _a, _b), members in groups.items():
        per = conductors_per_cable(cable)
        total += math.ceil(len(members) / per) if per else 1
    return total


def _get(row, key, default=None):
    """sqlite3.Row has no .get(); tolerate rows written before a column existed."""
    try:
        return row[key]
    except (IndexError, KeyError):
        return default


def curve_factor(qty: int, rate: float = 0.90) -> float:
    """
    Wright cumulative-average factor for a lot of `qty` at the given curve.
    qty=1 -> 1.0. A 90% curve gives ~0.78 at qty 5, ~0.65 at 50, ~0.58 at 100.
    """
    if qty <= 1:
        return 1.0
    b = math.log(rate) / math.log(2.0)
    return qty ** b


def lot_labor(rates, first_unit_hr, qty):
    """Total labor hours for a lot, with the learning curve if enabled."""
    if qty <= 0:
        return 0.0
    if float(rates.get("curve_enabled", 0)) >= 1.0:
        f = curve_factor(qty, float(rates.get("curve_rate", 0.90)))
    else:
        f = 1.0
    return round(first_unit_hr * qty * f, 2)


def schedule(rates, total_lot_hours, procurement_weeks=6):
    """Rough calendar. Procurement of MIL-spec parts is normally critical path."""
    techs = max(1.0, float(rates.get("techs", 2)))
    shift = max(1.0, float(rates.get("shift_hours", 8)))
    per_day = techs * shift
    build_days = math.ceil(total_lot_hours / per_day) if per_day else 0
    build_weeks = math.ceil(build_days / 5) if build_days else 0
    return {
        "labor_hours": round(total_lot_hours, 1),
        "labor_hours_per_day": per_day,
        "build_days": build_days,
        "build_weeks": build_weeks,
        "procurement_weeks": procurement_weeks,
        # procurement runs in parallel with kitting but gates the build start
        "total_weeks": procurement_weeks + build_weeks + 1,
    }


def harness_summary(conn, harness_id):
    """Everything the UI and the exporter need about one harness's labor."""
    from . import db
    rates = db.rates(conn)
    parts = conn.execute("SELECT * FROM part WHERE harness_id = ? ORDER BY sort_order, id",
                         (harness_id,)).fetchall()
    wires = conn.execute("SELECT * FROM wire WHERE harness_id = ? ORDER BY wire_no, id",
                         (harness_id,)).fetchall()
    terms = conn.execute("SELECT * FROM termination WHERE harness_id = ? ORDER BY id",
                         (harness_id,)).fetchall()
    minutes, rows = first_unit_minutes(rates, parts, wires, terms)
    return {
        "parts": parts,
        "wires": wires,
        "terminations": terms,
        "termination_count": termination_total(terms),
        "crimp_count": crimp_total(terms),
        "conductor_count": len(wires),
        "cable_runs": _cable_run_count(wires),
        "first_unit_min": minutes,
        "first_unit_hr": round(minutes / 60.0, 2),
        "breakdown": rows,
    }
